/*
	permut.c - permutation generator

	for use with Cracker Jack and other library-based
	password crackers that support stdin mode (well, can
	be dumped to file, then treated as library but.. size!)

General syntax of permut is:

	permut.exe -k <k> [-n <n>]

Where:   k=number of characters in password (permutation length)
	 n=size of source set (no. of chars to use, look at str table)

When omitted, n is set to 27 (standard characters set).

Usage with CrackerJack (MS-DOS):

    permut.exe -k <k> -n <n> | jack.exe -P:<your_passwdfile> -ST

Best way is to put into batch-file loop increasing k while n stays still
the same.

n:
Knowing (suspecting) characters used in password (only chars < chars&capitals
< chars&capitals&numbers < all,with slashes, hyphens etc.) determines n.

		    -------------------------
		    Set n for character sets:

            small letters+space: n=27
            +capitals          : n=53
            +digits 0-9        : n=63
            all                : n=96
            -------------------------

k:
If you know *for sure* the password is e.g 3 chars long (possibly in dreams..)
you set k=3. If you don't know - you usually start from k=1,2 and increase
up to 8 (unix system limit).
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* pre-defined array which stores current variation */
#define MAX_LENGTH 8 /* max unix password length */

int limit;
int lngth;

/* CHARSET DEFINITION BELOW */
char *str="\
abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVXYZ1234567890`-=\\<>?,./:\";\'{}[]~!@#$%^&*()_+|";

unsigned int arr[MAX_LENGTH];
int flag;

int incr(int j)
{
 if(arr[j]>=limit)
  {
   arr[j]=0;
   return(1);
  }
 else
  {
   arr[j]+=1;
   return(0);
  }
}

int nextcmb(int n)
{
 int flag,i=0;
 flag=incr(n);
 while(i<lngth && arr[i]==limit)
    i++;
 if(i==lngth)
    return(0);
 if(flag)
    nextcmb(n+1);
 return(1);
}

void initarr(void)
{
int i;
for(i=0;i<lngth;i++)
 arr[i]=0;
 }

void gener(void)
{int i;
 do
 {  for(i=0;i<lngth;i++) {
                    fprintf(stdout,"%c",*(str+arr[i]) );
                        }
  fprintf(stdout,"\n");
 }
 while(nextcmb(0)); 
// printf("%c%c%c%c\n",*(str+arr[0]),*(str+arr[1]),*(str+arr[2]),*(str+arr[3]) );
  for(i=0;i<lngth;i++) {
                    fprintf(stdout,"%c",*(str+arr[i]) );
                        }
  fprintf(stdout,"\n");
i=0;
}

void HelpD(void)
{
    printf("\n[Permut] by kravietZ. Permutation generator.\n\n");
    printf("syntax: permut.exe -k <k> make permutations k chars long\n");
    printf("                          (with default charset = 26)\n\n");
    printf("        permut.exe -k <n> -n <set> make permutations k chars long\n");
    printf("                                   of set of n chars\n\n");
    printf("        permut.exe [-h|-?] display this list of commands\n\n");
    printf("Charset:              n=\n");
    printf("[a-z] + space         27\n");
    printf("+ [A-Z]               53\n");
    printf("+ [0-9]               63\n");
    printf("all printable ascii   96\n\n");
}

/* MAiN */

void main(argc, argv)
char **argv[];
{

if(argc==1)
{
    HelpD();
    exit(0);
};

if(argc==4) exit(1);
if( (argc==3 || argc==5) && strstr(argv[1],"-k"))
{            limit=27;
             sscanf(argv[2],"%d",&lngth);
}
else
{
    HelpD();
    exit(1);
};


if(argc==5 && strstr(argv[3],"-n")) sscanf(argv[4],"%d",&limit);

limit-=1; /* pointery zaczynaja sie od 0! */
// printf("\n\n\n");
 gener();
 exit(0);
}
