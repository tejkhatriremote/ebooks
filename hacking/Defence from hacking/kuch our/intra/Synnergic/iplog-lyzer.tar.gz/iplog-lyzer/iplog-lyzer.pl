#!/usr/bin/perl
# *** Synnergy Networks

# * Description:
#
# A iplog log parser.
# Parses the entris of the log file (depending on the options you choose)
# and outputs them to a web page.

# * Author:
#
# pestilence (pestilence@synnergy.net)
# Synnergy Networks (c) 1999,  http://www.synnergy.net
# *** Synnergy Networks

# $Id: Iplog Analyzer, v 1.0.0 1999/12/14 12:40:13

# Edit this to point to your logfile
$log_file = "/var/log/iplog";

require 5.002;

use vars qw($opt_a $opt_h $opt_c $opt_t $opt_u $opt_s $opt_i);
use Getopt::Std;
use Sys::Hostname;

getopts('ahctusi');

$COPYRIGHT='Iplog Analyzer : 1.0.0, Copyright 1999 Kostas Petrakis aka Pestilence.
Iplog Analyzer comes with ABSOLUTELY NO WARRANTY. It is free software, and you are welcome to redistribute it under certain conditions. See source for details.
Iplog-Analyzer Homepage: http://www.synnergy.gr/software/pestilence';

$USAGE='Usage: ' . $0 . ' [switches] > /path/to/output.html

Reports:
-a	all	(extacts all reports available,
		-a equals -t -u -i -s)
-t	tcp	Report TCP log entrys
-u	udp	Report UDP log entrys
-i	icmp	Report ICMP log entrys
-s	scans	Report Scans detected (both TCP and UDP)
';

print ($USAGE, "\n") if ($opt_h);
print ($COPYRIGHT, "\n") if ($opt_c);
exit 0 if (($opt_h) or ($opt_c));

if ($opt_a) {
	$opt_t = 1;
	$opt_u = 1;
	$opt_s = 1;
	$opt_i = 1;
 }

# Initialize Variables
$month = $day = $time = $proto = $counter = $tcp_scans_counter = $tcp_counter = $tcp_host = $tcp_port = $udp_counter = $udp_host = $udp_port = $udp_scans_counter = $icmp_counter = $icmp_type = $icmp_host = $scans_counter = $scan_host = $scan_type = $ingore_counter = 0;

open(LOG, "$log_file") or die("$0: can't open $log_file for reading: $!\n");
foreach $line (<LOG>){
	chomp $line;
	$counter++;
	if ($line =~ m#iplog started# || $line =~ m#already running# || $line =~ m#line repeated#){
		$ignore_counter++;
		next;
	}
	@data = split(' ', $line);
	$month = $data[0];
	$day = $data[1];
	$time = $data[2];
	$proto = $data[3];
	$proto =~ s#:$##;
	if ($proto eq 'TCP') {
		$tcp_counter++;
		if ($data[6] eq 'detected') {
			$hash_scan_type = $hash_scan_host = $hash_host_type_count = 0 unless defined;
			$scans_counter++;
			$tcp_scans_counter++;
			$scan_type = $data[4];
			$scan_host = $data[8];
			$hash_scan_type{$scan_type} +=1;
			$hash_scan_host{$scan_host} +=1;
			$hash_host_type_count{$scan_host}{$scan_type}++;
		} elsif ($data[5] eq 'connection') {
			$tcp_host_request = $tcp_port_request = $tcp_port_request_count = 0 unless defined;
			$tcp_port = $data[4];
			$tcp_host = $data[8];
			$tcp_host =~ s/:\d*$//;
			$tcp_host_request{$tcp_host} += 1;
			$tcp_port_request{$tcp_port} += 1;
			$tcp_host_port_count{$tcp_host}{$tcp_port}++;
		} elsif ($data[4] eq 'port') {
			$tcp_host_request = $tcp_port_request = $tcp_port_request_count = 0 unless defined;
			$tcp_port = $data[5];
			$tcp_host = $data[9];
			$tcp_host =~ s/:\d*$//;
			$tcp_host_request{$tcp_host} += 1;
			$tcp_port_request{$tcp_port} += 1;
			$tcp_host_port_count{$tcp_host}{$tcp_port}++;
		}
	}
	if ($proto eq 'UDP') {
		$udp_counter++;
		if ($data[5] eq 'detected') {
			$hash_udp_scan_type = $hash_udp_scan_host = $hash_udp_host_type_count = 0 unless defined;
			$scans_counter++;
			$udp_scans_counter++;
			$udp_scan_type = $data[4];
			$udp_scan_host = $data[7];
			$hash_udp_scan_type{$udp_scan_type} +=1;
			$hash_udp_scan_host{$udp_scan_host} +=1;
			$hash_udp_host_type_count{$udp_scan_host}{$udp_scan_type}++;
		} elsif ($data[4] eq 'dgram' && $data[6] eq 'port') {
			$udp_host_send = $udp_port_send = $udp_host_port_count = 0 unless defined;
			$udp_host = $data[9];
			$udp_host =~ s/:\d*$//;
			$udp_port = $data[7];
			$udp_host_send{$udp_host} += 1;
			$udp_port_send{$udp_port} += 1;
			$udp_host_port_count{$udp_host}{$udp_port}++;
		} elsif ($data[4] eq 'dgram' && $data[6] ne 'port') {
			$udp_host_send = $udp_port_send = $udp_host_port_count = 0 unless defined;
			$udp_host = $data[8];
			$udp_host =~ s/:\d*$//;
			$udp_port = $data[6];
			$udp_host_send{$udp_host} += 1;
			$udp_port_send{$udp_port} += 1;
			$udp_host_port_count{$udp_host}{$udp_port}++;
		} elsif ($data[4] eq 'traceroute') {
			$icmp_counter++;
			$hash_icmp_host_send = $hash_icmp_type = $hash_icmp_host_type = 0 unless defined;
			$icmp_type = $data[4];
			$icmp_host = $data[6];
			$hash_icmp_type{$icmp_type} +=1;
			$hash_icmp_host_send{$icmp_host} +=1;
			$hash_icmp_host_type{$icmp_host}{$icmp_type}++;
		}
	}
	if ($proto eq 'ICMP'){
		$icmp_counter++;
		if ($data[5] eq 'reply') {
			$hash_icmp_host_send = $hash_icmp_type = $hash_icmp_host_type = 0 unless defined;
			$icmp_type = $data[4] ." ". $data[5];
			$icmp_host = $data[7];
			$hash_icmp_type{$icmp_type} +=1;
			$hash_icmp_host_send{$icmp_host} +=1;
			$hash_icmp_host_type{$icmp_host}{$icmp_type}++;
		} elsif ($data[5] eq 'from') {
			$hash_icmp_host_send = $hash_icmp_type = $hash_icmp_host_type = 0 unless defined;
			$icmp_type = "ping";
			$icmp_host = $data[6];
			$hash_icmp_type{$icmp_type} +=1;
			$hash_icmp_host_send{$icmp_host} +=1;
			$hash_icmp_host_type{$icmp_host}{$icmp_type}++;
		}
		
	}

}
 $hostname = hostname() . ' ';
 print ("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\" \"http://www.w3.org/TR/REC-html40/loose.dtd\">
 <HTML>
 <HEAD>
 <TITLE>$hostname Iplog Report</TITLE>
 <META NAME=\"generator\" content=\"Iplog - Analyzer/" . '$Revision: 1.0.0 $' . "\">
 </HEAD>
 <BODY BGCOLOR=\"#000000\" TEXT=\"#FFFFFF\">\n");
 # ------------- Output Starts Here ----------- #
 outref ("Summary", 1);
 outref ("Icoming TCP Connections", 2) if ($opt_t);
 outref ("Icoming UDP Datagrams", 3) if ($opt_u);
 outref ("Icoming SCANS (TCP/UDP)", 4) if ($opt_s);
 outref ("Icoming ICMP Datagrams", 4) if ($opt_i);
 print "<br>\n";
 print "<br>\n";

 	outtitle("Summary for $hostname", 1);
	print "<br><b>lines parsed:</b> $counter\n";
	print "<br><b>lines ignored:</b> $ignore_counter\n";
	print "<br><b>TCP Entrys found:</b> $tcp_counter\n" if ($opt_t);
	print "<br><b>UDP Entrys found:</b> $udp_counter\n" if ($opt_u);
	print "<br><b>ICMP Entrys found:</b> $icmp_counter\n" if ($opt_i);
	print "<br><b>Scans found total -- (TCP/UDP):</b> $scans_counter -- ($tcp_scans_counter/$udp_scans_counter)\n" if ($opt_s);
	print "<br>\n";
	print "<br>\n";
 if ($opt_t) {
	# --- Web TCP Connections Report Starts Here ----------#
	outtitle("Incoming TCP Connections ---- Report", 2);
	print "<table bgcolor=\"black\" border=1 WIDTH=\"90%\">\n";
	print "<TR>\n";
	print "<TD>Host/Port</TD>\n";
	foreach $port (keys(%tcp_port_request)){
			print "<TD><font color=\"red\">$port</font></TD>\n";
	}
	print "</TR>\n";
	print "<TR>\n";
		foreach $host (keys(%tcp_host_request)){
			print "<TR>\n";
			print "<TD><font color=\"green\">$host</font></TD>\n";
				foreach $port (keys(%tcp_port_request)){
					print "<TD>&nbsp;$tcp_host_port_count{$host}{$port}</TD>\n";
				}
			print "</TR>\n";
		}
	print "</table>\n";
	# --- Web TCP Connections Report Ends Here ----------#
 } 

 if ($opt_u) {
 	# --- Web UDP Connections Report Ends Here ----------#
	outtitle("UDP Datagrams ---- Report", 3);
	print "<table bgcolor=\"black\" border=1 WIDTH=\"90\">\n";
	print "<TR>\n";
	print "<TD>Host/Port</TD>\n";
        foreach $port (keys(%udp_port_send)){
	                        print "<TD><font color=\"red\">$port</font></TD>\n";
	}
	print "</TR>\n";
	print "<TR>\n";
	foreach $host (keys(%udp_host_send)){
		 print "<TR>\n";
		 print "<TD><font color=\"green\">$host</font></TD>\n";
		  foreach $port (keys(%udp_port_send)){
		   print "<TD>&nbsp;$udp_host_port_count{$host}{$port}</TD>\n";
		   }
		   print "</TR>\n";
	}
	print "</table>\n";
 }

 if ($opt_s) {
	# ---- Incoming SCANS to the System ----#
	outtitle("Incoming SCANS TCP/UDP ---- Report", 3);
	print "<table bgcolor=\"black\" border=1 WIDTH=\"90\">\n";
	print "<TR>\n";
	print "<TD>Host/Port</TD>\n";
        foreach $type (keys(%hash_scan_type)){
	                        print "<TD><font color=\"red\">$type</font></TD>\n";
	}
	print "</TR>\n";
	print "<TR>\n";
	foreach $host (keys(%hash_scan_host)){
		 print "<TR>\n";
		 print "<TD><font color=\"green\">$host</font></TD>\n";
		  foreach $type (keys(%hash_scan_type)){
		   print "<TD>&nbsp;$hash_host_type_count{$host}{$type}</TD>\n";
		   }
		   print "</TR>\n";
	}
	print "</table>\n";
	print "<br>\n";
	print "<table bgcolor=\"black\" border=1 WIDTH=\"90\">\n";
	print "<TR>\n";
	print "<TD>Host/Port</TD>\n";
        foreach $type (keys(%hash_udp_scan_type)){
	                        print "<TD><font color=\"red\">$type</font></TD>\n";
	}
	print "</TR>\n";
	print "<TR>\n";
	foreach $host (keys(%hash_udp_scan_host)){
		 print "<TR>\n";
		 print "<TD><font color=\"green\">$host</font></TD>\n";
		  foreach $type (keys(%hash_udp_scan_type)){
		   print "<TD>&nbsp;$hash_udp_host_type_count{$host}{$type}</TD>\n";
		   }
		   print "</TR>\n";
	}
	print "</table>\n";
 }

 if ($opt_i) {
 	# --- ICMP Report Starts Here -----#
	outtitle("ICMP Datagrams ---- Report", 4);
	print "<table bgcolor=\"black\" border=1 WIDTH=\"90\">\n";
	print "<TR>\n";
	print "<TD>Host/Type</TD>\n";
        foreach $type (keys(%hash_icmp_type)){
	                        print "<TD><font color=\"red\">$type</font></TD>\n";
	}
	print "</TR>\n";
	print "<TR>\n";
	foreach $host (keys(%hash_icmp_host_send)){
		 print "<TR>\n";
		 print "<TD><font color=\"green\">$host</font></TD>\n";
		  foreach $type (keys(%hash_icmp_type)){
		   print "<TD>&nbsp;$hash_icmp_host_type{$host}{$type}</TD>\n";
		   }
		   print "</TR>\n";
	}
	print "</table>\n";
 }

 sub outref {
 	my $print = shift(@_);
	my $name = shift(@_);
	print("	<li><a href=\"#$name\">$print</a>\n");
 }
 sub outtitle {
 	my $print = shift(@_);
	my $name = shift(@_);
	print"<br>\n";
	print"<b>||--- <a name=\"$name\">$print</a></b> ---||\n";
	print"<br>\n";
	print"<br>\n";
 }
