// Guido Bakker <guidob@synnergy.net>
// Synnergy Laboratories (c) 2000

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <ncurses.h>

struct interface_info {
  char name[12];

  unsigned long int tx_bytes_old;
  unsigned long int rx_bytes_old;
  unsigned long int tx_bytes_new;
  unsigned long int rx_bytes_new;

  struct timeval tx_time_old;  
  struct timeval rx_time_old;
  struct timeval tx_time_new;
  struct timeval rx_time_new;

  float tx_time_diff;
  float rx_time_diff;
  
  float tx_rate;
  float rx_rate;
};

int main(int argc, char *argv[]) {
  FILE *devfile;

  char filename[256] = "/proc/net/dev";
  char buffer[256];
  char *buffer_pointer;

  int inum;
  int field_number;
  int total_counter;
  int sleep_time = 1;
  int first_pass = 1;

  unsigned long int conv_field;

  struct interface_info interface[16];
  struct timezone tz;

  float rx_bw_total;
  float tx_bw_total;

  if(argc == 2) if((sleep_time = atoi(argv[1])) < 1) sleep_time = 1;
  if(argc == 3) strncpy(filename, argv[2], 255);

  while(1) {
    initscr();

    move(2,0);
    clrtobot();

    attron(A_BOLD);
    printw("Bandwidth Monitor\n");
    standout();
    printw("       Iface        RX(KB/sec)   TX(KB/sec)   Total(KB/sec)\n\n");
    standend();
    attroff(A_BOLD);

    inum = -2;

    if((devfile = fopen(filename, "r")) == NULL) {
      perror("fopen");
      exit(EXIT_FAILURE);
    }

    while(fgets(buffer, 255, devfile) != NULL && inum < 16 - 1) {
      inum++;

      if(inum > 0) {
        buffer_pointer = buffer;
        buffer_pointer = strtok(buffer_pointer, " :");
        strncpy(interface[inum].name, buffer_pointer, 11);

        field_number = 0;

        while((buffer_pointer = strtok(NULL, " :")) != NULL) {
          conv_field = strtoul(buffer_pointer, NULL, 10);

          field_number++;

          switch(field_number)
          {
            case 1:
            {
              interface[inum].rx_bytes_old = interface[inum].rx_bytes_new;
              interface[inum].rx_bytes_new = conv_field;

              interface[inum].rx_time_old = interface[inum].rx_time_new;
              gettimeofday(&interface[inum].rx_time_new, &tz);

              interface[inum].rx_time_diff =

                (float) ( ((interface[inum].rx_time_new.tv_sec * 1000000)
                          + interface[inum].rx_time_new.tv_usec)
                        - ((interface[inum].rx_time_old.tv_sec * 1000000)
                          + interface[inum].rx_time_old.tv_usec) );

              interface[inum].rx_rate =

               (float) ((interface[inum].rx_bytes_new
                       - interface[inum].rx_bytes_old) / interface[inum].rx_time_diff) * 1000000;
            }
            break;

            case 9:
            {
              interface[inum].tx_bytes_old = interface[inum].tx_bytes_new;
              interface[inum].tx_bytes_new = conv_field;

              interface[inum].tx_time_old = interface[inum].tx_time_new;
              gettimeofday(&interface[inum].tx_time_new, &tz);

              interface[inum].tx_time_diff =

               (float)  ( ((interface[inum].tx_time_new.tv_sec * 1000000)
                          + interface[inum].tx_time_new.tv_usec)
                        - ((interface[inum].tx_time_old.tv_sec * 1000000)
                          + interface[inum].tx_time_old.tv_usec) );

              interface[inum].tx_rate =

               (float) ((interface[inum].tx_bytes_new
                       - interface[inum].tx_bytes_old) / interface[inum].tx_time_diff) * 1000000;
            }
            break;
          }
        }
   
        if(!first_pass) {
          printw("%12s     %12.3f %12.3f    %12.3f\n", interface[inum].name,
                 interface[inum].rx_rate / 1024, interface[inum].tx_rate / 1024,
                 (interface[inum].rx_rate + interface[inum].tx_rate) / 1024);
        }
      }
      refresh();
    }

    fclose(devfile);

    for(total_counter = 0, rx_bw_total = 0, tx_bw_total = 0; total_counter <= inum; total_counter++) {
      rx_bw_total += interface[total_counter].rx_rate;
      tx_bw_total += interface[total_counter].tx_rate;
    }

    if(inum < 1) printw("No interfaces!\n\n");

    first_pass = 0;
    sleep(sleep_time);
  }
  while(1);
  endwin();
  exit(0);
}
