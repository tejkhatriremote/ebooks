// Guido Bakker <guidob@synnergy.net>
// Synnergy Laboratories (c) 2000

#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <ncurses.h>
#include <errno.h>

#define SIZE 64
#define CONF "/etc/netmonrc"
#define PING "ping -c 1 -s 8 -q "

typedef struct group_ {
  char name[SIZE];
  char host[SIZE];
  char comment[SIZE];
  struct group_ *next;
} group;

char * get(char *, int, char, FILE *);
void aborted(const char *, int);
int exec(char *);
void load(char *, group **, group **, group **);

int main(int argc, char * argv[]) {
  char *status;
  char buf[SIZE + 20 + 25];
  char file[128];
  char ping[20 + 1] = PING;
  char ch;
  fd_set readfds;
  struct timeval timeout;
  group *head = NULL, *current = NULL, *last = NULL;
  unsigned int i;
  unsigned int up;
  unsigned int refresh = 180;

  strncat(file, CONF, 10);

  while((i = getopt(argc, argv, "f:vh?")) != -1) {
    switch(i) {
      case 'f':
        strncpy(file, optarg, 128);
        break;
      case 'v':
        printf("netmon 0.2\n");
        exit(0);
        break;
      case ':': case '?': case 'h':
        printf("usage: netmon [-f file] [-v]\n");
        exit(0);
        break;
    }
  }

  initscr();

  load(file, &current, &head, &last);

  attron(A_BOLD);
  printw("Network Monitor\n");
  standout();
  printw("%-16s  %-12s %-32s\n", "Host", "Status", "Comments");
  standend();
  attroff(A_BOLD);

  do {
    move(2, 0);

    current = head;

    do {
      strcpy(buf, ping);
      strcat(buf, current->host);
      strcat(buf, " > /dev/null 2>&1");
      if (exec(buf) == 0) { status = "UP"; up++; }
        else status = "DOWN";
      printw("%-16s  %-12s %-32s\n", current->name, status, current->comment);
      current = current->next;
    }

    while(current->next != NULL);

    refresh();

    FD_ZERO(&readfds);
    FD_SET(0, &readfds);
    timeout.tv_sec = refresh;
    timeout.tv_usec = 0;
    if (select(1, &readfds, NULL, NULL, &timeout) > 0) {
      if (read(0, &ch, 1) != 1)
        aborted("error, stdin cannot be read", 4);
      }
    }
  while(1);
  endwin();
  exit(0);
}

char * get(char *s, int n, char d, FILE *f) {
  register int c = 0;
  register char *cs;
  char *ch;

  cs = s;

  while(n-- > 0 && (c = getc(f)) != EOF && (*cs++ = c) != d);  

  if (c == d) *--cs = '\0';
    else *cs = '\0';

  if ((ch = strchr(s, '#')) != NULL) *ch = '\0';

  while (c != '\n' && c != EOF) c = getc(f);

  ch = strchr(s, '\0');
  while (*--ch == ' ' || *ch == '\t');
  *++ch = '\0';

  return (c == EOF && cs == s) ? NULL : s;
}

void aborted(const char * msg, int type) {
  endwin(); fprintf(stderr, "netmon: %s\n", msg); exit(type);
}

int exec(char *command) {
  int pid, status;
  pid = fork();
  if (pid == -1) return -1;
  if (pid == 0) {
    char * argv[4];
    argv[0] = "sh";
    argv[1] = "-c";
    argv[2] = command;
    argv[3] = NULL;
    execv("/bin/sh", argv);
    exit(127);
  }
  while(1) {
    if (waitpid(pid, &status, 0) == -1) { 
      if (errno != EINTR) return -1;
    }
    else return status;
  }
}

void load(char * file, group ** current, group ** head, group ** last) {
  char *field[3];
  char buf[SIZE];
  int i;
  FILE *cf;

  if ((*head) != NULL) {
    group * next;
    (*current) = (*head);
          do {
      next = (*current)->next;
                  free((*current));
      (*current) = next;
    } while ((*current) != NULL);
    (*head) = NULL;
  }

  if ((cf = fopen(file, "r")) == NULL) {
    strncpy(file, CONF, 128);  
    if ((cf = fopen(file, "r")) == NULL)
      aborted("error, cannot open conf file", 1);
  }

  while (!feof(cf)) {
    if (((*current) = (group *) malloc(sizeof(group))) == NULL) aborted("error, malloc() returned NULL - OOM?", 2);
    i = 0;
    field[0] = (*current)->name;
    field[1] = (*current)->host;
    field[2] = (*current)->comment;
    if ((*head) == NULL) { (*head) = (*current); (*last) = (*current); }
    (*last)->next = (*current);
    (*last) = (*current);
    (*current)->next = NULL;
    do {
      if (get(buf, SIZE - 1, '\n', cf) == NULL) break;
      if ((buf[0] != '#') && (buf[0] != '\0')) {
        strncpy(field[i], buf, SIZE);
        i++;
      }
    } while(i < 3);
  }

  fclose(cf);
}
