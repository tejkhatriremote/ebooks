//Start of HSRP.h

#include <pcap.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <arpa/inet.h>
#include <string.h>
#include <netinet/udp.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include <net/if.h>
#include <netinet/if_ether.h>
#include <netdb.h>

#define SA struct sockaddr
#define PORT 1985
#define VER "1.4"
#define MAXLINE 4096 //max text line length used in parsing CMD for pcap

//structs
struct ops {
	int sniff;
	int cripple;
	int defauth;
	int hellotime;
	char auth[8];
	struct in_addr virtualip;
	struct in_addr spoofed;
	int group;
};

struct header{
	struct iphdr ip; //ip header
	struct udphdr udp; //udp header
	char buf[20]; //hsrp header
};

extern struct ops o[];

//prototypes
void usage(char *progname);
void coup();
void hello();
void opensniff();
void cleanup(int sigio);
void sniffedcoup(struct header *headz);
void sniffedhello(struct header *headz);
unsigned short in_chksum(unsigned short *pts, int nbytes);
char *next_pcap(int *);
void open_pcap(void);
char *Sock_ntop_host(const SA *, socklen_t);
int sock_get_port(const SA *, socklen_t);
struct header *udpread();
struct header *udp_check(char *ptr, int len);

//globals
extern struct in_addr addr;
extern socklen_t destlen;
extern int datalink;
extern char *device;
extern int fddipad;
extern pcap_t *pd;
extern int rawfd;
extern int snaplen;
extern struct sockaddr_in broadcastIP;
extern struct sockaddr_in nullIP;
extern struct sockaddr_in allocatedIP;

//end of HSRP.h
