/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"
//#include "ports.h"

pthread_mutex_t fportlistlock = PTHREAD_MUTEX_INITIALIZER;
extern int vll;
extern int osstm;
extern int nmap;
extern int all;
extern int nports;

//linked list of filtered ports
//where srcip is the packets source IP eg the target we are scanning, dst ip being the ip we scanned it with
int addfport(u_short num)
{
	fport * fportpointer;

	//printf("port %d to be added with src %d.%d.%d.%d\n", num, srcip[0], srcip[1], srcip[2], srcip[3]);
	pthread_mutex_lock(&fportlistlock);
	fportpointer = fportpoint;
	if(fportpointer != NULL){ //not 1st entry
		while(fportpointer->nextport != NULL){
			if(fportpointer->num == num){
				if(v>1)printf("Opps: Filtered port already in list llport %d port %d\n",fportpointer->num, num);
				pthread_mutex_unlock(&fportlistlock);
				return(0);
			}
			
			fportpointer = (FOPT) fportpointer->nextport;
			
			if(fportpointer->num == num){
				if(v>1)printf("Opps: Filtered Port already in list llport %d port %d after ip\n", fportpointer->num, num);
				pthread_mutex_unlock(&fportlistlock);
				return(0);
			}
		}

		fportpointer->nextport = (struct fport *) malloc(sizeof(fport));
		if(fportpointer->nextport == NULL){
			printf("Opps: Malloc error not 1st\n");
			exit(1);
		}

		fportpointer = (FOPT) fportpointer->nextport;
		fportpointer->nextport = NULL;
		fportpointer->num = num;
		if(vll)printfportll();
		pthread_mutex_unlock(&fportlistlock);
		return(0);
	}
		
	else {
		
		//1st entry
		fportpoint = (FOPT) calloc(sizeof(fport), 1);
		fportpoint->nextport = NULL;
		fportpoint->num = num;
		if(vll)printfportll();
		pthread_mutex_unlock(&fportlistlock);
		return(0);
	}

	//shouldn;t reach here
	return(0);
}

int fportllcount(void)
{
	FOPT p_curr;
	int c = 0;
	p_curr = fportpoint;

	if(fportpoint == NULL) return(0);
	else {
		while(p_curr != NULL){
			c++;
			p_curr = (FOPT)p_curr->nextport;
		}
	}
	return(c);
}
			

void printfportll(void)
{
	FOPT p_curr;

	p_curr = fportpoint;

	printf("Filtered port results\n");
	
	if(fportpoint == NULL) printf("No ports filtered\n");
	else{
		while(p_curr != NULL){
			printf("port %d filtered\n", p_curr->num);
			p_curr = (FOPT) p_curr->nextport;
		}
	}
}

void freefportll(void)
{
	FOPT p_curr;
	
	if(v>2)printf("\nFreeing open ports list\n");
	while(fportpoint != NULL){
		p_curr = fportpoint;
		fportpoint = (FOPT) fportpoint->nextport;
		free(p_curr);
	}
}

