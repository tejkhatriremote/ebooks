/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

pthread_mutex_t cportlistlock = PTHREAD_MUTEX_INITIALIZER;
extern int vll;

//linked list of closed ports
//where srcip is the packets source IP eg the target we are scanning, dst ip being the ip we scanned it with
int addcport(u_short num, u_char *srcip, u_char *dstip)
{
	cport * cportpointer;
	int i;

	//printf("port %d to be added with src %d.%d.%d.%d\n", num, srcip[0], srcip[1], srcip[2], srcip[3]);
	pthread_mutex_lock(&cportlistlock);
	cportpointer = cportpoint;
	if(cportpointer != NULL){ //not 1st entry
		while(cportpointer->nextport != NULL){
			if(cportpointer->num == num){
				if(v>1)printf("Opps: Closed port already in list llport %d openport %d before %d.%d.%d.%d\n",cportpointer->num, num, dstip[0], dstip[1], dstip[2], dstip[3]);
				pthread_mutex_unlock(&cportlistlock);
				return(0);
			}
			
			cportpointer = (COPT) cportpointer->nextport;
			
			if(cportpointer->num == num){
				if(v>1)printf("Opps: Closed Port already in list llport %d openport %d after ip %d.%d.%d.%d\n", cportpointer->num, num, dstip[0], dstip[1], dstip[2], dstip[3]);
				pthread_mutex_unlock(&cportlistlock);
				return(0);
			}
		}

		cportpointer->nextport = (struct cport *) malloc(sizeof(cport));
		if(cportpointer->nextport == NULL){
			printf("Opps: Malloc error not 1st\n");
			exit(1);
		}

		cportpointer = (COPT) cportpointer->nextport;
		cportpointer->nextport = NULL;
		cportpointer->num = num;
		for(i=0;i<4;i++){
			cportpointer->ipaddr[i] = srcip[i];
		}
		for(i=0;i<4;i++){
			cportpointer->uipaddr[i] = dstip[i];
		}
		if(vll)printcportll();
		pthread_mutex_unlock(&cportlistlock);
		return(0);
	}
		
	else {
		
		//1st entry
		cportpoint = (COPT) calloc(sizeof(cport), 1);
		cportpoint->nextport = NULL;
		cportpoint->num = num;
		for(i=0;i<4;i++){
			cportpoint->ipaddr[i] = srcip[i];
		}
		for(i=0;i<4;i++){
			cportpoint->uipaddr[i] = dstip[i];
		}
		if(vll)printcportll();
		pthread_mutex_unlock(&cportlistlock);
		return(0);
	}

	//shouldn;t reach here
	return(0);
}

int cportllcount(void)
{
	COPT p_curr;
	int c = 0;
	p_curr = cportpoint;

	if(cportpoint == NULL) return(0);
	else {
		while(p_curr != NULL){
			c++;
			p_curr = (COPT)p_curr->nextport;
		}
	}
	return(c);
}
			

void printcportll(void)
{
	COPT p_curr;

	p_curr = cportpoint;

	printf("Closed port results\n");
	
	if(cportpoint == NULL) printf("No ports closed\n");
	else{
		while(p_curr != NULL){
			printf("%d.%d.%d.%d port %d closed (%d.%d.%d.%d)\n", p_curr->ipaddr[0], p_curr->ipaddr[1], p_curr->ipaddr[2], p_curr->ipaddr[3], p_curr->num, p_curr->uipaddr[0], p_curr->uipaddr[1], p_curr->uipaddr[2], p_curr->uipaddr[3]);
			p_curr = (COPT) p_curr->nextport;
		}
	}
}

void freecportll(void)
{
	COPT p_curr;
	
	if(v>2)printf("\nFreeing open ports list\n");
	while(cportpoint != NULL){
		p_curr = cportpoint;
		cportpoint = (COPT) cportpoint->nextport;
		free(p_curr);
	}
}
	
