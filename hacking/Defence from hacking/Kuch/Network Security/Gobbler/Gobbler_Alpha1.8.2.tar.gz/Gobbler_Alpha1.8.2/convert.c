/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"
//start of convert functions

unsigned int convert32(char *ptr, int anum, int bnum, int cnum, int dnum)
{
	register unsigned int num = 0;
	register unsigned char octet;

	octet = ptr[anum];
	num = (num + octet) << 8;

	num = num & 0x0000ff00;
	octet = ptr[bnum];
	num = (num + octet) << 8;

	num = num & 0x00ffff00;
	octet = ptr[cnum];
	num = (num + octet) << 8;

	num = num & 0xffffff00;
	octet = ptr[dnum];
	num = (num + octet);

	return num;
}


unsigned int convert16(char *ptr, int anum, int bnum)
{
	register unsigned int suma = 0;
	register unsigned int sumb = 0;
	register unsigned int ans = 0;
	register int q = 0;
	register int p = 0;
	for(q=128;q>0;q=q/2){
				if(q &ptr[anum])
				{
				if((q=128 &ptr[anum])) suma+=32768;
				if((q=64 &ptr[anum])) suma+=16384;
				if((q=32 &ptr[anum])) suma+=8192;
				if((q=16 &ptr[anum])) suma+=4096;
				if((q=8 &ptr[anum])) suma+=2048;
				if((q=4 &ptr[anum])) suma+=1024;
				if((q=2 &ptr[anum])) suma+=512;
				if((q=1 &ptr[anum])) suma+=256;			
				}
				}
	
	for(p=128;p>0;p=p/2){
				if(p &ptr[bnum])
				{
					sumb +=p;
				}
				}
		
		ans = (suma + sumb);
		return(ans);
}

//end of convert functions

