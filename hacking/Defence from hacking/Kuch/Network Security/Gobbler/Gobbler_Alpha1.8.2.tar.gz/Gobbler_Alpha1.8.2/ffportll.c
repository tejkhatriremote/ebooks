/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"
//#include "ports.h"

pthread_mutex_t ffportlistlock = PTHREAD_MUTEX_INITIALIZER;
extern int vll;
extern int osstm;
extern int nmap;
extern int all;
extern int nports;

//final linked list of filtered ports
//where srcip is the packets source IP eg the target we are scanning, dst ip being the ip we scanned it with
int addffport(u_short num)
{
	ffport * ffportpointer;

	//printf("port %d to be added with src %d.%d.%d.%d\n", num, srcip[0], srcip[1], srcip[2], srcip[3]);
	pthread_mutex_lock(&ffportlistlock);
	ffportpointer = ffportpoint;
	if(ffportpointer != NULL){ //not 1st entry
		while(ffportpointer->nextport != NULL){
			if(ffportpointer->num == num){
				if(v>1)printf("Opps: Final Filtered port already in list llport %d port %d\n",ffportpointer->num, num);
				pthread_mutex_unlock(&ffportlistlock);
				return(0);
			}
			
			ffportpointer = (FFOPT) ffportpointer->nextport;
			
			if(ffportpointer->num == num){
				if(v>1)printf("Opps: Final Filtered Port already in list llport %d port %d after ip\n", ffportpointer->num, num);
				pthread_mutex_unlock(&ffportlistlock);
				return(0);
			}
		}

		ffportpointer->nextport = (struct ffport *) malloc(sizeof(ffport));
		if(ffportpointer->nextport == NULL){
			printf("Opps: Malloc error not 1st\n");
			exit(1);
		}

		ffportpointer = (FFOPT) ffportpointer->nextport;
		ffportpointer->nextport = NULL;
		ffportpointer->num = num;
		if(vll)printffportll();
		pthread_mutex_unlock(&ffportlistlock);
		return(0);
	}
		
	else {
		
		//1st entry
		ffportpoint = (FFOPT) calloc(sizeof(ffport), 1);
		ffportpoint->nextport = NULL;
		ffportpoint->num = num;
		if(vll)printffportll();
		pthread_mutex_unlock(&ffportlistlock);
		return(0);
	}

	//shouldn;t reach here
	return(0);
}

int ffportllcount(void)
{
	FFOPT p_curr;
	int c = 0;
	p_curr = ffportpoint;

	if(ffportpoint == NULL) return(0);
	else {
		while(p_curr != NULL){
			c++;
			p_curr = (FFOPT)p_curr->nextport;
		}
	}
	return(c);
}
			

void printffportll(void)
{
	FFOPT p_curr;

	p_curr = ffportpoint;

	
	if(ffportpoint == NULL) {
		if(v)printf("No ports filtered\n");
	}
	else{
		printf("\nFiltered port results\n");
		while(p_curr != NULL){
			//if(p_curr->num != 0){
				printf("port %d filtered\n", p_curr->num);
			//}
			p_curr = (FFOPT) p_curr->nextport;
		}
	}
}

void freeffportll(void)
{
	FFOPT p_curr;
	
	if(v>2)printf("\nFreeing open ports list\n");
	while(ffportpoint != NULL){
		p_curr = ffportpoint;
		ffportpoint = (FFOPT) ffportpoint->nextport;
		free(p_curr);
	}
}

