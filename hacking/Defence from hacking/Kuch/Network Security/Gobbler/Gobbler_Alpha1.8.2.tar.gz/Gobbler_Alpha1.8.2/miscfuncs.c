/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//miscfuncs.c
#include "gobbler.h"
static pthread_once_t elock = PTHREAD_ONCE_INIT; //insures stats printed once 
extern int ipgobblecount;
extern int dhcpgobbling;
extern int arprecvcount;
extern int arpscanstarted;
extern int sniffer;
extern int gobblearp;
extern int nongportscan;
extern int portscan;
extern struct timeval scantime;
struct timeval endtime;
void set_rlimits(void);
extern int nports;
extern int maninthemiddlestarted;

void cleanup(int signo)
{
	void printstats(void);
	int i;
	for(i=0; i<MAXPACKHANDLER; i++){
		count += tptr[i].thread_count;
	}
	fflush(stdout);
	pthread_once(&elock, (void *)printstats);
}

void addstats(struct libnet_stats local)
{
	gs.packets_sent += local.packets_sent;
	gs.packet_errors += local.packet_errors;
	gs.bytes_written += local.bytes_written;
}


void printstats(void)
{
	extern int portllcount(void);
	extern int cportllcount(void);
	extern int fportllcount(void);
	extern int ffportllcount(void);
	void pr_cpu_time(void);
	void pr_getrlimits(void);
	struct pcap_stat stat;
	int scount;
	
	if(pcap_stats(pd, &stat)<0){
		printf("\nOpps: pcap_stats error as %s\n", pcap_geterr(pd));
		exit(1);
	}

	scount = (count) - (drop) - (stat.ps_drop);
	if(scount < 0) scount = count; //opps we dropped more packet than we handled
	
	if((gettimeofday(&endtime,NULL)) != 0){
		printf("Opps: gettimeofday error\n");
		exit(1);
	}

	printf("\n---Gobbler Stats---\n");
	printf("%d/%d packets handled from filter (using %d packet handling threads)\n",count, stat.ps_recv, MAXPACKHANDLER);
	printf("%d successfully decoded, %d packets dropped (kernel: %d gobbler: %d)\n", scount,stat.ps_drop + drop, stat.ps_drop, drop);
	if(!sniffer)printf("%ld packets sent, %ld packet errors,  %ld bytes written\n", gs.packets_sent, gs.packet_errors, gs.bytes_written);
	

	if(arpscanstarted){
		if(gobblearp) printf("%d IP addresses gobbled, ", ipgobblecount);
		printf("%d arp replies, ", arprecvcount);
		if(!gobblearp){
			printf("scanning time %ld seconds, ", (endtime.tv_sec - scantime.tv_sec));
			printf("running time %ld seconds\n", (endtime.tv_sec - inittime.tv_sec));
		}
		else {
			printf("%ld/%ld seconds (scan/run time) \n", (endtime.tv_sec - scantime.tv_sec), (endtime.tv_sec - inittime.tv_sec));
		}
	}
	else if(portscan || nongportscan){
		printf("Ports %d open, %d/%d filtered b4/after check, %d closed, %d total\n", portllcount(), fportllcount(), ffportllcount(), cportllcount(), nports);
		if(portscan)printf("%d IP addresses gobbled, ",ipgobblecount);
printf("%ld/%ld seconds scan/run time \n", (endtime.tv_sec - scantime.tv_sec), (endtime.tv_sec - inittime.tv_sec));
}
	if(sniffer){
		printf("Running time %ld seconds\n", (endtime.tv_sec - inittime.tv_sec));
	}
	if(dhcpgobbling) printf("%d IP addresses gobbled\n", ipgobblecount);
	if(maninthemiddlestarted){
		printf("Running time %ld seconds\n", (endtime.tv_sec - inittime.tv_sec));
	}
	
	printf("\n");
	//pr_cpu_time();
	//pr_getrlimits();
	
	if(nports){
		freeportll();
	}

	
	free(tptr);
	exit(0);
}

void egg()
{
	printf("\n\t\t\tShoutz\n\n"\
		"        ./ slider ryza sleepyhead andy mina welshguy\n"\
		"\t  everyone else at astalavista.net\n\n"\
		"\t\t  polotron + rootless\n"\
		"\tfor giving me a ickle job (cheers guys)\n\n"\
		"\t\tbassintro for hosting\n"\
		"\t\t   (www.clove.net)\n\n"\
		"\t\t     lee and stan\n"\
		"\t\tfor being lee and stan\n\n"\
		"\t\ttcpdump and ethereal\n\n"\
		"\t     Mike Schiffman, Doug Sung\n\n"\
		);
}
/*
void pr_cpu_time(void)
{
        double user, sys;
	struct rusage myusage, childusage;
			 
	if(getrusage(RUSAGE_SELF, &myusage) < 0){
		printf("Opps: getrusage error\n");
		exit(1);
	}
				 
	if(getrusage(RUSAGE_CHILDREN, &childusage) < 0){
		printf("Opps: getrusage error\n");
		exit(1);
	}
				 
	user = (double) myusage.ru_utime.tv_sec + myusage.ru_utime.tv_usec /1000000.0;
	user += (double) childusage.ru_utime.tv_sec + childusage.ru_utime.tv_usec /1000000.0;
						 
	sys = (double) myusage.ru_utime.tv_sec + myusage.ru_utime.tv_usec /1000000.0;
	sys += (double) childusage.ru_utime.tv_sec + childusage.ru_utime.tv_usec /1000000.0;
									 
											 
	printf("user time = %g, sys time = %g\n", user, sys);
}

void set_rlimits(void)
{
	struct rlimit rlim;
	rlim.rlim_cur = rlim.rlim_max = 1024000; //shrink core dump size
	if(setrlimit(RLIMIT_CORE, &rlim)<0){
		printf("Opps: setrlimit error\n");
		exit(1);
	}
}

void pr_getrlimits(void)
{
	struct rlimit rlim;

	if(getrlimit(RLIMIT_CORE, &rlim) < 0){
		printf("Opps: getrlimit error\n");
		exit(1);
	}

	printf("core cur %ld max %ld\n", rlim.rlim_cur, rlim.rlim_max);
}
*/
void usage(char *progname)
{
	printf( "Scanning Options\n"\
		"-a <b,g,s,w> detect IP addresses via ARP scan (b)broadcast, (g)gobbled, (w)wrong (s)specified (requires -Q)\n"\
		"-d detect DHCP service / rogue servers on network\n"\
                "-g gobble attack -  DoS DHCP server via IP exhaustion / MAC spoofing attack\n"\
		"-p <ip address> SYN scan using a gobbled IP address\n"\
		"-P <135-139,445> <ALL(a)> <OSSTM(o)> <NMAP services(n)> <Real NMAP(r)> ports to be scanned\n"\
		"-m <x> DHCP man in the middle attack x = (d) dns mitm (s)this subnet (o)other subnet\n"\
		"-N <ip address> target for none gobbled SYN scan (requires -Q)\n"\
		"-Q <IP-mac> Src IP-MAC for non gobbled SYN scan (MAC can be random(r), non spoofed(n), or 1a:2b:3c:4d:5e:6f)\n"\
		"-n <x> Number of spoofed source hosts used in -p SYN scan\n"\
		"-s start sniffer\n"\
		"\nMisc\n"\
		"-v verbose (may be used 3 times for increased debugging info)\n"\
		"-V display linked list after every update (used when gobbling a IP address)\n"\
		"-C display list of closed ports\n"\
		"-D display list of filtered ports\n"\
		"-k <port> source port number for SYN scanner (Default: random)\n"\
		"-T Tag mac addresses (each will end in 4e:50)\n"\
		"-j Jump past rescanning filtered ports (useful when scanning all ports)\n"\
		"-F Fast mode for port scanner (be careful when using this... packets will be dropped)\n"\
		"-E <x> sleep x seconds at end of scan to wait for replies (default 2)\n"\
		"-r Gobbled hosts will NOT reply to ICMP pings requests\n"\
		"-c Create a single gobbled host to test scans and things out on\n"\
		/*"-w Start a webserver (TODO)\n"\*/
		"-o / -O <port num> Open port on gobbled host o(tcp) (O)udp (fun to scan with nmap!)\n"\
		"-i <eth0> interface for sniffer and packet injector (use before -Q if non spoofed mac)\n"\
		"\nExamples\n"\
		"Gobbled SYN scan from single dynamically assigned host: %s -p 192.168.1.1 -P o\n"\
		"Gobbled SYN scan from multiple hosts: %s -p 192.168.3.1 -P21-23,25,80,137,139,445 -n 4\n"\
		"Non-gobbled syn scan: %s -i eth0 -T -N 10.0.0.1 -Q 10.0.0.50-r -Q 10.0.0.51-r -P n\n"\
		"Sniffer: %s -i eth0 -s -v		Arp scan: %s -i eth0 -a\n"\
		"Detect rogue DHCP servers: %s -d         DHCP DoS: %s -g \n\n"\
		"WARNING read README.1ST before using the Gobbler\n"\
		"If you do not understand what you are doing, do NOT use this program!\n"\
		, progname, progname, progname, progname, progname,progname, progname);
	exit(1);
}

