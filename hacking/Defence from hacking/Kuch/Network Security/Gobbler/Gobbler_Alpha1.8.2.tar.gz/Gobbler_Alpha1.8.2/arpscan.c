/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

static pthread_once_t endarpscanlock = PTHREAD_ONCE_INIT;
extern int arpscanstarted;
int acount;
extern libnet_t *l;
extern u_int endwait;
extern u_int maskcount;
extern pthread_mutex_t packetlock;
extern int gobblearp;
extern int specarp;
extern int bcastarp;
extern int wrongarp;
extern int dhcpreplyinfo;
extern int dhcpgobblestarted;
extern int dhcpgobbling;
extern int phosts;
extern struct timeval scantime;
int timeloop;
pthread_mutex_t arplock = PTHREAD_MUTEX_INITIALIZER; //lock to ensure arp scan increments by one each time

void startarpscan(void)
{
	void thread_arpscan(int);
	extern void startdhcpdiscover(void);
	extern int checkdhcp(int);
	int i, tcount;
	
	acount = 0;
	aptr = calloc(MAXARPSCANHANDLER, sizeof(athread));
	
	if(maskcount < MAXARPSCANHANDLER){
		tcount = maskcount + 1;
	}
	else tcount = MAXARPSCANHANDLER;
	
	if(gobblearp){
		printf("Trying to gobble an ip address...\n");
		dhcpreplyinfo = 1;
		dhcpgobblestarted = 1;
		dhcpgobbling = 1;
		startdhcpdiscover();
		phosts = 1;
		if(checkdhcp(0) != 0){
			printf("Opps: checkip ll error\n\n");
			exit(1);
		}
		dhcpreplyinfo = 0;
		dhcpgobblestarted = 0;
		dhcpgobbling = 0;
	}
	
	tcount = 1;
	for(i=0; i<tcount; i++){
		thread_arpscan(i);
	}
}
 
void thread_arpscan(int i)
{
	void *arpscan(void *);
	arpscanstarted = 1;
	if(pthread_create(&aptr[i].thread_tid, NULL, &arpscan, (void *) i) < 0){
		printf("Opps: pthread_create error\n");
		exit(1);
	}
	if((gettimeofday(&scantime,NULL)) != 0){
		printf("Opps: gettimeofday error\n\n");
		exit(1);
	}
}

void arpscan(void *tnum)
{
	void addstats(struct libnet_stats);
        void end_arpscan(void);
        libnet_ptag_t t;
        u_long i,j; //src + dst ip addresses
        int c;
	int d;
	int maxloop;
//	u_int32_t srcipaddr;
	PMT p_curr;
	u_char *sourceip;
        u_char enet_src[6]; 
        u_char enet_dst[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
 
	static struct timespec tv;
	//printf("maskcount %d\n", maskcount);
	if(maskcount < 257){
		//class C 
		tv.tv_sec = 1;
		tv.tv_nsec = 0;
		maxloop = 30;
	}
	else {
		//not class C
		tv.tv_sec = 0;
		tv.tv_nsec = 5;
		maxloop = 50;
	}
	
       if(pthread_detach(pthread_self()) <0){
        	printf("Opps: pthread_detach error\n");
                pthread_exit(&status);
        }
        
	if(bcastarp){
		for(d=0;d<6;d++){
			enet_src[d] = 0x00;
			
		}
		i = -1;
		printf("Detecting IP addresses via broadcast ARP scan (src IP 255.255.255.255 MAC 00:00:00:00:00:00)\n\n");
	}

	else if(wrongarp){
		for(d=0;d<6;d++){
			enet_src[d] = 0xff;
		}
		i = -1;
		printf("Detecting IP addresses via wrong ARP scan (src IP 255.255.255.255 MAC ff:ff:ff:ff:ff:ff)\n\n");
	}
	
	else if(gobblearp || specarp){
		p_curr = mtpoint;
		if(p_curr == NULL){
			printf("Opps: linked list is empty top\n");
			exit(1);
		}
	//	while(p_curr != NULL){
	//		p_curr = (PMT) p_curr->nextmt;
	//	}

	//	if(p_curr == NULL){
	//		printf("Opps: linked list is empty bottom\n");
	//		exit(1);
	//	}
		for(d=0;d<6;d++){
			enet_src[d] = p_curr->srcmac[d];
			//printf("srcmac = %d\n", enet_src[d]);
		}

		i = (u_long) p_curr->ipaddress;
		sourceip = (u_char *)&(p_curr->ipaddress);
		if(gobblearp)printf("\nDetecting IP addresses via gobbler ARP scan (src IP %d.%d.%d.%d MAC %x:%x:%x:%x:%x:%x)\n\n", sourceip[0], sourceip[1], sourceip[2], sourceip[3], p_curr->srcmac[0], p_curr->srcmac[1], p_curr->srcmac[2], p_curr->srcmac[3], p_curr->srcmac[4], p_curr->srcmac[5]);
		else if(specarp)printf("Detecting IP addresses via ARP scan (src IP %d.%d.%d.%d MAC %x:%x:%x:%x:%x:%x)\n\n", sourceip[0], sourceip[1], sourceip[2], sourceip[3], p_curr->srcmac[0], p_curr->srcmac[1], p_curr->srcmac[2], p_curr->srcmac[3], p_curr->srcmac[4], p_curr->srcmac[5]);
	}
	else {
		printf("Opps: Unknown arp scan type\n");
		exit(1);
	}
		
		
	
	if(v>2)printf("Arp scan started on thread(%ld)\n", pthread_self());
 	
	while(acount <= maskcount){
		//usleep(1);
/*		if(pthread_mutex_lock(&arplock) != 0){
			printf("Opps: pthread_mutex_lock error(arpscan)\n");
			exit(1);
		}
*/		
		if(pthread_mutex_lock(&packetlock) !=0){
			printf("Opps: pthread_mutex_lock (arpscan)\n");
			exit(1);
		}

		acount++;
	        j = (localnet + htonl(acount));
/*		if(pthread_mutex_unlock(&arplock) != 0){
			printf("Opps: pthread_mutex_lock error(arplock)\n");
			exit(1);
		}
*/      		
		
		if(acount >= maskcount){
			pthread_once(&endarpscanlock, end_arpscan);
			pthread_exit(&status);
		}
			t = libnet_build_arp(
			ARPHRD_ETHER,   //HW type
			ETHERTYPE_IP,   //Proto
		        6,              //Hsize
		        4,              //psize
	        	ARPOP_REQUEST,  //opcode
		        enet_src,       //sender HW address
		        (u_char *)&i,   //sender proto address
	        	enet_dst,       //receiver HW address
			(u_char *)&j,   //receiver proto address
		        NULL,           //payload
	        	0,              //payload size
		        l,              //libnet handle
		       	0);             //libnet id
	                                                                                                                       if(t == -1){
			printf("Opps: Can;t build ARP header as %s\n\n", libnet_geterror(l));
			libnet_clear_packet(l);
			exit(1);
		}
		t = libnet_build_ethernet(
			enet_dst,       //enet source
	        	enet_src,       //enet dest
		        ETHERTYPE_ARP,  //proto addr
			NULL,           //payload
	        	0,              //payload size
		        l,              //libnet handle
		        0);             //libnet id
	
		if(t == -1){
			printf("Opps: Can;t build ethernet header as %s\n\n", libnet_geterror(l));
	       		libnet_clear_packet(l);
		        exit(1);
		}
	
		 if((c = libnet_write(l)) == -1){
			printf("Opps: libnet_write error (arp scan) as %s\n", libnet_geterror(l));
			exit(1);
		}
	  
		libnet_stats(l, &gs);
		libnet_clear_packet(l);
		timeloop ++;
		if(timeloop == maxloop){
			nanosleep(&tv, NULL);
			timeloop = 0;
		}
		
	if(pthread_mutex_unlock(&packetlock) !=0){
			printf("Opps: pthread_mutex_unlock (arpscan)\n");
			exit(1);
		}
	}
       	pthread_once(&endarpscanlock, end_arpscan);
	pthread_exit(&status);
}
 
 
void end_arpscan(void)
{
	void cleanup(int sigio);
	if(endwait) printf("Arp scan finished... waiting for %d seconds for any more replies\n", endwait);
	else printf("Arp scan finished...\n");
	//libnet_destroy(l);
	sleep(endwait);
	cleanup(0);
}
