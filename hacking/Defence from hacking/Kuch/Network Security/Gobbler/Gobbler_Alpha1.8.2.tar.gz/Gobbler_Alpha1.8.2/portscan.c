/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"
#include "ports.h"

extern int portscanstarted;
extern int dhcpreplyinfo;
extern int dhcpgobblestarted;
extern int dhcpgobbling;
extern pthread_mutex_t listlock;
extern pthread_mutex_t plistlock;
pthread_mutex_t portcountlock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t createandsend = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t startscanning = PTHREAD_COND_INITIALIZER;
pthread_mutex_t startscanlock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t dhcpresenddiscoverlock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t dhcpresendrequestlock = PTHREAD_MUTEX_INITIALIZER;
static pthread_once_t endportscanlock = PTHREAD_ONCE_INIT;
static pthread_once_t filterportscanlock = PTHREAD_ONCE_INIT;

extern libnet_t *q, *l;
extern char* hostname;
extern char* portlist;
extern int portl;
extern int phosts;
extern u_int endwait;
extern int nongportcan;
extern int ipgobblecount;
extern int fast;
extern int arpcache;
extern int displayfiltered;
extern int displayclosed;
extern int jumpfilter;

libnet_plist_t plist, *plist_p;
u_short eport;
u_short sport;
u_int ssport;
int d;
int all;
int osstm;
int nmap;
int real;
int randmac;
extern u_int16_t srcprt;
extern int srcportoption;
extern int tag;
int nports;
extern int portscan;
extern int nongportscan;
u_char *cnongsrcmac; //converted 
extern int ng;
int ipnum;
int sipcount;
int timeloop;
extern struct timeval scantime;
extern int noprintinfo;
int portscanningstarted = 0;
int filterscan;

#ifdef LINUX
#define TLOOP 10
#define FLOOP 5
#endif

#ifdef BSDOS
#define TLOOP 10
#define FLOOP 4
#endif

void startportscan(void)
{
	void thread_portscan(int);
	void startdhcpdiscover(void);
	int portlisttopll(void);
	int getdstmac(int);
	int checkdhcp(int);
//	extern void printpll(void);
	int h,i,j,k,tcount;
	struct in_addr sa;
	int eachsrcipgetmac = 0; //0 = only 1 arp lookup per dst
	all = 0;
	osstm = 0;
	nmap = 0;
	timeloop = 0;
	filterscan = 0;
	
	pthread_cond_init(&startscanning, NULL);
	
	//check args
	if(!inet_aton(hostname, &sa)){
		printf("\nOpps: %s is a invalid ip address\n", hostname);
		exit(1);
	}

	if(strncasecmp(portlist, "ALL", sizeof(portlist)) == 0){
		all = 1;
		nports = 65535;
	}
	
	else if(strncasecmp(portlist, "a", sizeof(portlist)) == 0){
		all = 1;
		nports = 65535;
	}

	else if(strncasecmp(portlist, "o", sizeof(portlist)) == 0){
		for(nports = 0; nports < sizeof(tcpports) ; nports++){
			//printf("nports %d tcpport %d\n", nports, tcpports[nports]);
			if(tcpports[nports] == 0){
				break;
			}
		}
		if(v>1)printf("OSSTM ports to be scanned total: %d\n",nports);
		osstm = 1;
	}
	
	else if(strncasecmp(portlist, "OSSTM", sizeof(portlist)) == 0){
		for(nports = 0; nports < sizeof(tcpports) ; nports++){
			if(tcpports[nports] == 0){
				break;
			}
		}
		if(v>1)printf("OSSTM ports to be scanned total: %d\n",nports);
		osstm = 1;
	}

	else if(strncasecmp(portlist, "NMAP", sizeof(portlist)) == 0){
		for(nports = 0; nports <sizeof(nmapports); nports++){
			if(nmapports[nports] == 0){
				break;
			}
		}
		if(v>1)printf("Nmap service's ports to be scanned total: %d\n", nports);
		nmap = 1;
	}

	else if(strncasecmp(portlist, "n", sizeof(portlist)) == 0){
		for(nports = 0; nports <sizeof(nmapports); nports++){
			if(nmapports[nports] == 0){
				break;
			}
		}
		if(v>1)printf("Nmap service's ports to be scanned total: %d\n", nports);
		nmap = 1;
	}
	
	else if(strncasecmp(portlist, "REAL", sizeof(portlist)) == 0){
		for(nports = 0; nports <sizeof(rnmapports); nports++){
			if(rnmapports[nports] == 0){
				break;
			}
		}
		if(v>1)printf("Real Nmap ports to be scanned total: %d\n", nports);
		real = 1;
	}
	
	else if(strncasecmp(portlist, "r", sizeof(portlist)) == 0){
		for(nports = 0; nports <sizeof(rnmapports); nports++){
			if(rnmapports[nports] == 0){
				break;
			}
		}
		if(v>1)printf("NMAP ports to be scanned total: %d\n", nports);
		real = 1;
	}

	
	else{
		//list of ports 1-10,15,20 format
		if(portl){
			nports = portlisttopll(); //convert return number	
		}

		else {
			printf("Opps: port list error\n\n");
			exit(1);
		}
	}
	
	
	if(portscan)printf("Gobbling an IP address for use in portscanner\n");
	
	pptr = calloc(MAXPORTSCANHANDLER, sizeof(portthread));
	
	if(portscan){
		dhcpreplyinfo = 1; //printf info about dhcp server
		dhcpgobblestarted = 1; //vars for gobbling
		dhcpgobbling = 1; //vars for gobbling

		for(j=0;j<phosts;j++){
			startdhcpdiscover(); //should give us some mac n ip addresses;
			usleep(200000);
			noprintinfo = 1;
		}
		h = 0;
		while((ipgobblecount != phosts) && h != 10){
			usleep(100000);
			if((k =checkdhcp(1)) != 0){
				if(k == 1) {
					printf("Opps: checkipll error\n");
					exit(1);
				}
				if(k == 2){
					h++;
				}
				if(k == 0){
					h++; //h = 10?
				}
			}
			
			h++;
		}
		
			if(checkdhcp(0) != 0){
			printf("Opps: checkipll error\n");
			exit(1);
		}

		dhcpreplyinfo = 0; //reset gobbler args
		dhcpgobblestarted = 0;
		dhcpgobbling = 0;
	}
	
	
	
	if(phosts) sipcount = phosts;
	if(ng) sipcount = ng;
	
	if(eachsrcipgetmac){
		//TODO each ip request dest mac
		for(j=0;j<sipcount;j++){
			if(getdstmac(j) != 0){
				printf("Opps: getdstmac error\n");
				exit(1);
			}
		}
	}
	
	else {
		j = 0;
		if(getdstmac(j)!=0){
			printf("Opps: getdstmac error\n");
			exit(1);
		}
	}
	portscanstarted = 1;
	sport = 0;
	ssport = 0;
	i=0;
	if(nports < MAXPORTSCANHANDLER){
		tcount = nports + 1;
	}
	else tcount = MAXPORTSCANHANDLER;
	//printf("tcount = %d, nports %d MAX %d\n",tcount, nports, MAXPORTSCANHANDLER);
	for(i=0;i<tcount; i++){
		thread_portscan(i);
	}
	printf("Starting port scan....\n\n");
	if((gettimeofday(&scantime,NULL)) != 0){
		printf("Opps: gettimeofday error\n");
		exit(1);
	}
	pthread_cond_broadcast(&startscanning);
	//add if more than 1 scanning thread
	for(;;) sleep(1);
}


void thread_portscan(int i)
{
	void * pscan(void *);

	if(pthread_create(&pptr[i].thread_tid, NULL, &pscan, (void *)i)<0){
		printf("Opps: pthread_create error as %s\n", strerror(errno));
		exit(1);
	}
}

//g being gobble
int checkdhcp(int g)
{
	//checks ip linked list to ensure all dhcp addresses have been assigned (eg recieved ACK)
	int resenddhcprequest(int);
	int resenddhcpdiscover(int);
	extern int startDHCPrequest(u_int32_t );
	int j,k,l;
	PMT p_curr, q_curr;
	
	p_curr = mtpoint;
	j = 0;
	k = 0;
	
	if(p_curr == NULL){
		printf("Opps: Linked list empty\n");
		exit(1);
	}
	
	while(p_curr != NULL){
		if(p_curr->lastdhcptype == ACKREC){
			j++; //number of IP's assigned
		}
		else if(v>1) printf("%d dhcp type = %d\n",k, p_curr->lastdhcptype);
		k++;//number of IP's in list
		
		p_curr = (PMT) p_curr->nextmt;
	}
	if(j != phosts){
		if(v)printf("Opps: Only %d/%d dhcp assigned addresses have been created... trying to fix\n",j,phosts);
		l = 0;
		q_curr = mtpoint;
		if(q_curr == NULL){
			printf("Opps: Linked list empty\n");
			exit(1);
		}
		while(q_curr != NULL){
			if(q_curr->lastdhcptype == DISCOVERSENT){
				resenddhcpdiscover(l);
				l++;
				q_curr = (PMT) q_curr->nextmt;
			}
			else if(q_curr->lastdhcptype == OFFERREC){
				startDHCPrequest(q_curr->transid);
				l++;
				//sleep(1);
				q_curr = (PMT) q_curr->nextmt;
			}
			else if(q_curr->lastdhcptype == REQUESTSENT){
				startDHCPrequest(q_curr->transid);
				l++;
				//sleep(1);
				q_curr = (PMT) q_curr->nextmt;
			}
			else if(q_curr->lastdhcptype == ACKREC){
				l++;
				q_curr = (PMT) q_curr->nextmt;
			}
			else{
				printf("Opps: Unknown lastdhcptype\n");
				exit(1);
			}
		}
	}
	else return(0);
	if(g == 2) return(0);
	//if(!g) sleep(2);
	//else sleep(1);
	sleep(1);

		p_curr = mtpoint;
	j = 0;
	k = 0;
	if(p_curr == NULL){
		printf("Opps: Linked list empty\n");
		exit(1);
	}
	
	while(p_curr != NULL){
		if(p_curr->lastdhcptype == ACKREC){
			j++; //number of IP's assigned
		}
		else if(v>1)printf("%d dhcp type = %d\n",k, p_curr->lastdhcptype);
		k++;//number of IP's in list
		
		p_curr = (PMT) p_curr->nextmt;
	}

	if(!g){
		if(j != phosts){
			printf("Opps: The DHCP server couldn't assign enough addresses %d/%d assigned \n\n", j, phosts);
			exit(1);
		}
		else{
			return(0);
		}
	}
	else {
		if(g == 2) return(0);
		//sleep(5);
		//usleep(1000000);
		//g = 1
		p_curr = mtpoint;
		j = 0;
		k = 0;
		if(p_curr == NULL){
			printf("Opps: Linked list empty\n");
			exit(1);
		}
	
		while(p_curr != NULL){
			if(p_curr->lastdhcptype == ACKREC){
				j++; //number of IP's assigned
			}
			else if(v>1)printf("%d dhcp type = %d\n",k, p_curr->lastdhcptype);
			k++;//number of IP's in list
		
			p_curr = (PMT) p_curr->nextmt;
		}
		if(j != phosts) return(2);
		else return(0);
	}

	//shouldn't reach here
	return(1);
}

int resenddhcpdiscover(int num)
{
	void addstats(struct libnet_stats);
	libnet_ptag_t t;
	libnet_ptag_t ip;
	libnet_ptag_t udp;
	libnet_ptag_t dhcp;
	u_long options_len;
	u_char *options;
	mtnode mt;
	u_char enet_src[6];
	u_char enet_dst[6] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	PMT p_curr;
	int a,i,x,j;
	u_int32_t transid;
	
	i = 0;
	x = 0;
	a = 0;
	j = 0;
	transid = 0;

	//printf("resend dhcp discover\n");

	p_curr = mtpoint;	
	if(p_curr == NULL){
		printf("Opps: Linked list empty\n");
		exit(1);
	}
	
	//printf("j = %d, num = %d\n", j, num);
	while(p_curr != NULL && (j !=num)){
		//printf("inloop j = %d\n",j);
		j++;
		p_curr = (PMT) p_curr->nextmt;
	}

	if(p_curr == NULL){
		printf("Opps: can't find ip in ll\n");
		exit(1);
	}
	//printf("j = %d\n",j);
	
	for(x=0;x<6;x++){
		enet_src[x] = p_curr->srcmac[x];
	}
	transid = p_curr->transid;

	options = malloc(12);
        options[i++] = LIBNET_DHCP_MESSAGETYPE;
        options[i++] = 1;
        options[i++] = LIBNET_DHCP_MSGDISCOVER;
        mt.dhcptype = DHCPDISCOVER;
	 
	 
        options[i++] = LIBNET_DHCP_PARAMREQUEST;
        options[i++] = 7;
        options[i++] = 0x01;
        options[i++] = 0x1c;
        options[i++] = 0x02;
        options[i++] = 0x03;
        options[i++] = 0x0f;
        options[i++] = 0x06;
        options[i++] = 0x0c;
	 
	options_len = i;

        if(pthread_mutex_lock(&dhcpresenddiscoverlock) != 0){
                printf("Opps: pthread_mutex_lock error\n");
                exit(1);
        }

        dhcp = libnet_build_dhcpv4(
                LIBNET_DHCP_REQUEST,    //opcode
                1,                      //hardware type
                6,                      //hardware address len
                0,                      //hop count
                transid,                //transactionid
                0,                      //seconds since boot
                0x8000,                 //flag (broadcast)
                0,                      //client IP
                0,                      //your ip
                0,                      //server ip
                0,                      //gateway ip
                enet_src,               //client hardware addr
                NULL,                   //server host name
                NULL,                   //boot file
                options,                //payload
                options_len,            //payload length
                l,                      //libnet handle
                0);                     //libnet id
        if(dhcp == -1){
                printf("Opps: Couldn't build dhcp packet as %s\n", libnet_geterror(l));
                exit(1);
        }
		 
        udp = libnet_build_udp(
                68,                     //source port
                67,                     //dst port
                LIBNET_UDP_H + LIBNET_DHCPV4_H + options_len, //packetsize
                0,                      //checksum
                NULL,                   //payload
                0,                      //payload length
                l,                      //libnet handle
                0);                     //libnet id
        if(udp == -1){
		printf("Opps: Couldn't build udp packet as %s\n", libnet_geterror(l));
		exit(1);
	}
				 
	ip = libnet_build_ipv4(
	        LIBNET_IPV4_H + LIBNET_UDP_H + LIBNET_DHCPV4_H + options_len, //length
	        0x10,                   //tos
	        0,                      //IP ID
		0,                      //IP Frag
                16,                     //TTL
		IPPROTO_UDP,            //protocol
		0,                      //checksum
		0,                      //source ip 0.0.0.0
		-1,                     //inet_addr("255.255.255.255") //dest ip
		NULL,                   //payload
		0,                      //length of payload
		l,                      //libnet handle
		0);                     //libnet id
	 
	if(ip == -1){
	        printf("Opps: Couldn't build ip packet as %s\n", libnet_geterror(l));
	        exit(1);
	}
	t = libnet_build_ethernet(
		enet_dst,               //enet_dst
		enet_src,               //ethaddr.ether_addr_octet, //enet_src
		ETHERTYPE_IP,           //protocol type
		NULL,                   //payload
		0,                      //payload length
		l,                      //libnet handle
		0);                     //libnet id
	if(t == -1){
		printf("Opps: Couldn't build ethernet frame as %s\n", libnet_geterror(l));
		exit(1);
	}
			 
	a = libnet_write(l);
	if(a == -1){
		printf("Opps: libnet_write error (DHCP discover) as %s\n", libnet_geterror(l));//strerror(errno));
		exit(1);
	}
						 
	updatell(mt); //adds mac + trans to ll
	free(options);
	libnet_stats(l, &gs);
	libnet_clear_packet(l);
	if(pthread_mutex_unlock(&dhcpresenddiscoverlock) != 0){
		printf("Opps: pthread_mutex_unlock error\n");
		exit(1);
	}

	//printf("end of resend dhcp discover\n");	
	return(0);
}

int getdstmac(int j)
{
	unsigned int convert32(char *, int, int ,int, int);
	int arp_gett(arp_t *, struct arp_entry *);
	int send_arpreq(u_int32_t, u_int32_t);
	int sub;
	int b,c,i;
	struct route_entry rentry;
	struct arp_entry aentry;
	route_t *r;
	arp_t *arp;
	u_char *tmac;
	PMT p_curr;
	
	c = 0;
	b = 0;
	sub = 0;
	i = 0;
	if(v>2)printf("Getting destination mac address\n");
	r = route_open();
	if(r == NULL){
		printf("Opps: libdnet route open error\n");
		exit(1);
	}
	
	if(addr_pton(hostname, &rentry.route_dst) <0){
		printf("Opps: addr_pton error\n");
		exit(0);
	}
	
	if(route_get(r, &rentry) <0){
		sub = 1; //assume ip on subnet if route get fail
	}
	
	
	route_close(r);
	if(sub != 1){
		if(v)printf("%s uses gateway %s\n", addr_ntoa(&rentry.route_dst), addr_ntoa(&rentry.route_gw));
		aentry.arp_pa = rentry.route_gw;
	}
	else{
		if(v)printf("%s is on local subnet\n", addr_ntoa(&rentry.route_dst));
		if(addr_pton(hostname, &aentry.arp_pa) <0){
			printf("Opps: addr_pton error\n");
			exit(1);
		}
	}
		
	if((arp = arp_open()) == NULL){
		printf("Opps: libdnet arp open error\n");
		exit(1);
	}
	p_curr = mtpoint;

	if(p_curr == NULL){
		printf("Opps: Linked list empty\n");
		exit(1);
	}
	
	while((p_curr != NULL) && (c != j)){
		p_curr = (PMT) p_curr->nextmt;
		c++;
	}

	if(p_curr == NULL){
		printf("Opps: couldn't find IP address\n");
		exit(1);
	}

	while((arp_gett(arp, &aentry) <0) && b != 3){
		if(v>1)printf("Opps: arp_get error.... sending arp request packet (b = %d)\n",b);
		b++;
		tmac = (unsigned char *)&aentry.arp_pa.addr_ip;
		if(send_arpreq(p_curr->ipaddress, htonl(convert32(tmac,0,1,2,3))) != 0){
			printf("Opps: send_arpreq error\n");
			exit(1);
		}
		for(i=0;i<10;i++){
			if(arpcache == 1) return(0);
			usleep(500000);
		}
	}
			
	if(b == 3){
		printf("Opps: couldn't get mac address port scan terminating....\n");
		arp_close(arp);
		cleanup(0);
	}
		
	else {
		arp_close(arp);
		//if(v && sub)printf("\n%s at %s \n", addr_ntoa(&aentry.arp_pa), addr_ntoa(&aentry.arp_ha));
		//if(v && !sub)printf("\n%s at %x:%x:%x:%x:%x:%x \n", addr_ntoa(&aentry.arp_pa),  aentry.arp_ha.addr_data32[0], aentry.arp_ha.addr_data32[1], aentry.arp_ha.addr_data32[2], aentry.arp_ha.addr_data32[3], aentry.arp_ha.addr_data32[4], aentry.arp_ha.addr_data32[5]);
	}
	return(0);
}

//wrapper for libdnets arp_gett
int arp_gett(arp_t *arp, struct arp_entry *entry)
{
	u_int32_t convert32(char *,int, int, int, int);
	PMI p_curr;
	int a;
	int arp_getfail;
	
	arp_getfail = 0;
	if(arp_get(arp, entry) <0){
		arp_getfail = 1;
		if(v>2)printf("Opps: Arp get failed (kernel hasn;t got a copy of the dst mac)\n");
	}
		
	if(arp_getfail == 1){
		p_curr = macippoint;
		if(p_curr == NULL){
			//printf("Opps: Dest MAC IP Linked List empty\n");
			return(-1);
		}
		while((p_curr != NULL) && (entry->arp_pa.addr_ip != htonl(p_curr->ipaddr))){
			p_curr = (PMI) p_curr->nextmi;
		}

		if(p_curr == NULL){
			//printf("Opps: Can't find IP in Linked list\n");
			return(-1);
		}

		for(a=0;a<6;a++){
			entry->arp_ha.addr_data32[a] = p_curr->srcmac[a];
		}
	}
	
	else {
		//copy kernel arp entry to mac linked list
		if(addmacip(htonl(entry->arp_pa.addr_ip), (u_char *)&entry->arp_ha.addr_eth) !=0){
			printf("Opps: addmacip error\n");
			exit(1);
		}
	}	
	return(0);
}
		

void pscan(void *tnum)
{	
	void end_portscan(void);
	void startfilterscan(void);
	int send_arpreq(u_int32_t, u_int32_t);
	void cleanup(int sigio);
	u_int32_t convert32(char *,int, int, int, int);
	libnet_ptag_t t;
	int c,a;
	int endflag = 0;
	u_int32_t seq;
	PMT p_curr, p_top;
	PPT pp_curr, pp_top;
	PMI m_curr;
	FOPT f_curr;
	u_char enet_src[6];
	u_char enet_dst[6];
	struct in_addr sa;
	int cport;
	unsigned char *ip;
	int iptemp;
	u_int32_t ipaddrtemp;
	struct timespec tv;
	struct timespec tf;
	
	tv.tv_sec = 0;
	tv.tv_nsec = 99000000;
	#ifdef HAVE_BSD
		tv.tv_sec = 1
		tv.tv_nsec = 0;
	#endif
	tf.tv_sec = 0;
	tf.tv_nsec = 100;
	
	
	iptemp = 0;
	cport = 0;
	c = 0;
	a = 0;
	d = 0;
	timeloop = 0;
	
	if(v>2)printf("port scanning pthread_created %ld\n",pthread_self());
	
	if(!filterscan){
		if(pthread_detach(pthread_self()) != 0){
			printf("Opps: pthread_detach error\n");
			exit(1);
		}
	}
	
	if(!inet_aton(hostname, &sa)){
		printf("\nOpps: %s is a invalid ip address\n", hostname);
		exit(1);
	}

	//if more than 1 thread doing portscan comment out below
	//hopefully help reduce load on kernel as all threads should be created b4 scanning starts
	//only using 1 thead the moment... no need for multple threads as too quick as it is
	
	//if(!filterscan){
		//pthread_mutex_lock(&startscanlock);
	//	pthread_cond_wait(&startscanning, &startscanlock);
	//}
	portscanningstarted = 1;
	if(filterscan){
		printf("\nChecking filtered ports...\n\n");
	}
	
	//printf("starting scan\n");
	for(;;){		
		if(pthread_mutex_lock(&createandsend) != 0){
			printf("Opps: pthread_mutex_lock error\n");
			exit(1);
		}
		if(all){
			cport = ssport++;
			if(cport == 65535){
				endflag = 1;
			}
			else if(cport > 65535){
				goto END;
			}
		}

		else if(osstm){
			if(d == nports){
				goto END;
			}
			cport = tcpports[d++];
		}
	
		else if(nmap){
			if(d == nports){
				goto END;
			}
			cport = nmapports[d++];
		}

		else if(real){
			if(d == nports){
				goto END;
			}
			cport = rnmapports[d++];
		}
		
		
		else if(filterscan){
			f_curr = fportpoint;
			if(f_curr == NULL){
				if(v)printf("filter port list is empty\n");
				goto FILTEREND;
			}
			while((f_curr != NULL) && (f_curr->done == 1)){
				f_curr = (FOPT) f_curr->nextport;
			}
			if(f_curr == NULL){
				goto FILTEREND;
			}
			else {
				cport = f_curr->num;
				f_curr->done = 1;
			}
		}
				
		
		else{ //port liked list
			pp_curr =  pp_top  = ptpoint;
			if(pp_curr == NULL){
				printf("port ll is empty top %ld\n", pthread_self());
				exit(1);
			}
			while((pp_curr != NULL) && (pp_curr->done == 1)){
				pp_curr = (PPT) pp_curr->nextpt;
			}
			if(pp_curr == NULL){
				goto END;
			}
			else{
				cport = pp_curr->num;
				pp_curr->done = 1;
			}
		}	
		
		//printf("cport = %d\n", cport);

		p_curr = p_top = mtpoint;

		if(p_curr == NULL){
			printf("Opps: linked list empty\n");
			exit(1);
		}
		
		iptemp = 0;
		while(p_curr != NULL && iptemp!=ipnum){
			iptemp++;
			p_curr = (PMT) p_curr->nextmt;
			
		}
		if(p_curr == NULL){
			printf("Opps: No available ip addresses found\n");
			exit(1);
		}

		else{
			ip = (u_char *)&(p_curr->ipaddress);
			if(v)printf("Found an ip address %d.%d.%d.%d and mac %x:%x:%x:%x:%x:%x in LL thread %ld\n", (u_int8_t)ip[0], (u_int8_t)ip[1], (u_int8_t)ip[2], (u_int8_t)ip[3], p_curr->srcmac[0], p_curr->srcmac[1], p_curr->srcmac[2], p_curr->srcmac[3], p_curr->srcmac[4], p_curr->srcmac[5], pthread_self());
			for(a=0; a<6; a++){
				enet_src[a] = p_curr->srcmac[a];
			}
			ipaddrtemp = p_curr->ipaddress;

			m_curr = macippoint;
			if(m_curr == NULL){
				printf("Opps: Mac IP Linked List empty\n");
				exit(1);
			}
			
			ipnum++;
			if(ipnum == sipcount) ipnum = 0;
		}
		
		//current target mac addr
		//only one target atm
		for(a=0; a<6; a++){
			enet_dst[a] = m_curr->srcmac[a];
		}
	
		seq = libnet_get_prand(LIBNET_PRu32);
		if(!srcportoption){
			srcprt = libnet_get_prand(LIBNET_PRu16);
		}
			
		t = libnet_build_tcp(
			srcprt,		//srcport
			(u_short)cport,	//dstport
			seq,		//seq number
			0,		//ack number
			TH_SYN,		//Flags
			0, 		//window size
			0,		//checksum
			0,		//urg pointer
			LIBNET_TCP_H,	//packet size
			NULL,		//payload
			0,		//payload size
			l,		//libnet handle
			0);		//libnet id
		if(t == -1){
			printf("Opps: libnet_build_tcp error as %s\n\n", libnet_geterror(l));
			exit(1);
		}

		t = libnet_build_ipv4(
			LIBNET_TCP_H + LIBNET_IPV4_H, //length
			0,		//TOS
			0,		//id,
			0,		//IP frag
			64,		//TTL
			IPPROTO_TCP,	//protocol
			0,		//checksum
			ipaddrtemp,	//srcip
			sa.s_addr,	//dstip
			NULL,		//payload
			0,		//sizeof payload
			l,		//libnet handle
			0);		//libnet id
		if(t == -1){
			printf("Opps: libnet_build_ipv4 error as %s\n\n", libnet_geterror(l));
			exit(1);
		}
	
		t = libnet_build_ethernet(
			enet_dst, 	//dst mac
			enet_src,	//src mac
			ETHERTYPE_IP,	//proto
			NULL,		//payload
			0,		//payload size
			l,		//libnet handle
			0);		//libnet id
		if(t == -1){
			printf("Opps: libnet_build_ethernet error as %s\n\n", libnet_geterror(l));
			exit(1);
		}
		
		c = libnet_write(l);
		if(c == -1){
			printf("Opps: libnet_write error (Syn scan) as %s\n",libnet_geterror(l));
			exit(1);
		}
		
		libnet_stats(l, &gs);
		libnet_clear_packet(l);
		if(all && endflag){
			goto END;
		}
				
		timeloop++;
		//the lower the slower
		if(!filterscan){
			if(timeloop == TLOOP){
				if(!fast) nanosleep(&tv, NULL);
				else nanosleep(&tf, NULL);
				timeloop = 0;
			}
		}
		else{
			if(timeloop == FLOOP){
				if(!fast) nanosleep(&tv, NULL);
				else nanosleep(&tf, NULL);
				timeloop = 0;
			}
		}

		//printf("%d\n", (u_short)cport);
		
		if(pthread_mutex_unlock(&createandsend) !=0){
			printf("Opps: pthread_mutex_unlock error\n");
			exit(1);
		}
		
	}
	END:
	if(pthread_mutex_unlock(&createandsend) != 0){
		printf("Opps: ptherad_mutex_unlock error\n");
		exit(1);
	}
	//pthread_exit(&status);
	if(jumpfilter){
		parsefports();
		goto FILTEREND; 
	}
	else pthread_once(&endportscanlock, startfilterscan);
	
	FILTEREND:
	sleep(1);
	pthread_once(&filterportscanlock, end_portscan);
	filterscan = 0;
	pthread_exit(&status);
}

int send_arpreq(u_int32_t srcip, u_int32_t dstip)
{
	libnet_ptag_t t;
	u_char enet_src[6];
	u_char enet_dst[6] = {0xff,0xff,0xff,0xff,0xff,0xff};
	u_char enet_blank[6] = {0x00,0x00,0x00,0x00,0x00,0x00};
	u_char *sip, *dip;
	PMT p_curr, p_top;
	u_char *packet;
	u_long packet_s;
	int c, x;	
	
	if(v)printf("Sending arp request for destination mac\n");
	
	p_curr = p_top =mtpoint;
	if(p_curr == NULL){
		//printf("LL empty\n");
		return(0);
	}
        
	while((p_curr != NULL) && (p_curr->ipaddress != srcip)){
		p_curr = (PMT) p_curr->nextmt;
	}
	if(p_curr == NULL){
       		//printf("Not found in list\n");
       		return(0);
       	}
        else{
		//found
 		for(x=0; x<6; x++){
                	enet_src[x] = p_curr->srcmac[x];
		}
		
		sip = (unsigned char *)&srcip;
		dip = (unsigned char *)&dstip;
		
		t = libnet_build_arp(
			ARPHRD_ETHER,
			ETHERTYPE_IP,
			6,
			4,
			ARPOP_REQUEST,
			enet_src,
			sip,
			enet_blank,	//dst mac
			dip,		//dst ip
			NULL,
			0,
			q,
			0);
		if(t == -1){
			printf("Opps: Can;t build arp packet as %s\n",libnet_geterror(q));
			exit(1);
		}
		
		
		t = libnet_build_ethernet(
			enet_dst,
			enet_src,
			ETHERTYPE_ARP,
			NULL,
			0,
			q,
			0);
		if(t == -1){
			printf("Opps: Can;t build ethernet header as %s\n",libnet_geterror(q));
			exit(1);
		}

		c = libnet_adv_cull_packet(q, &packet, &packet_s);
		if(c == -1){
			printf("Opps: cull error\n");
			exit(1);
		}
		c = libnet_write(q);
		if(c == -1){
		        printf("Opps: libnet_write error (arp request) as %s\n", libnet_geterror(q));
                        libnet_clear_packet(q);
                }
		 
                libnet_stats(q, &gs);
                libnet_clear_packet(q);
                if(v)printf("\nsent arp request\n");
		return(0);
	}			
	return(0);
}

//libnets port list to linked list converter (returns number of ports)
int portlisttopll(void)
{
	extern int pllcount(void);
	u_short sport,eport, cport;
	u_short portpaircount;
	int flag = 0, h;
	portpaircount = 0; //init to 0
	sport = 0;
	eport = 0;
	cport = 0;
	
	
	plist_p = &plist;
	if(libnet_plist_chain_new(l, &plist_p, portlist) == -1){
		printf("Opps: Invalid port as %s\n",libnet_geterror(l));
		exit(1);
	}
	if(v)printf("Port list: %s\n", libnet_plist_chain_dump_string(plist_p));
	while(flag!=1){
		h = libnet_plist_chain_next_pair(plist_p, &sport, &eport);
		if(h != 1){
			if(h == 0){
				if(v>2)printf("No more port pairs... port pair count: %d\n\n", portpaircount);
				if(flag != 1){
					flag = 1;
				}
			}	
			if(h == -1){
				printf("Opps: libnet_plist_chain_next_pair error\n\n");
				exit(1);
			}
		}	
		else {
			portpaircount++;
			if(v>2)printf("pair %d: startport = %d endport = %d\n",portpaircount,sport, eport);
			if(v>2)printf("Warning if large port list it may take some time to build the list (Need to fix,add pointer to end node)\n");
			while(!(sport > eport) && (sport != 0)){
				cport = sport++;
				//if(cport == 0){
				//printf("port = %d\n",cport);
				//	exit(1);
				//}
				if(addpt(cport) != 0){
					printf("Opps: add port to linked list error\n\n");
					exit(1);
				}
			}
			if(sport == 0){
				printf("Opps: port == 0\n\n");
				exit(1);
			}
	
		}
	}
	if(portpaircount == 0){
		printf("Opps: portpaircount error\n\n");
		exit(1);
	}
	if(v>2)printpll();
	if(libnet_plist_chain_free(plist_p) == -1){
		printf("Opps: libnet_plist_chain_free error\n\n");
		exit(1);
	}
	return(pllcount());
}

void startfilterscan(void)
{
	void pscan(void *tnum);
	
	//printf("startfilterscan\n");
	sleep(2);
	parsefports();
	filterscan = 1;
	all = 0;
	nmap = 0;
	osstm = 0;
	real = 0;
	pscan((void *)0);
}


void parsefports(void)
{
	//loop through each port we scan
	//testing in both open and closed port lists.... if not found put in filtered list
 
        int d = 0;
	int testopen(u_short);
	int testclosed(u_short);
        int stoploop = 0;
        PPT  p_curr;
                   

	//printf("parse fports nports %d\n", nports);
        if(osstm){
               while(d < nports){
                       if(testopen(tcpports[d]) != 0){
			       if(testclosed(tcpports[d]) != 0){
				       addfport(tcpports[d]);
			       }
		       }
		       d++;
	       }
        }
        
	else if(nmap){
                while(d < nports){                                      
                        if(testopen(nmapports[d]) != 0){                
 			       if(testclosed(nmapports[d]) != 0){               
 				       addfport(nmapports[d]);          
			       }
			}                                       
 		        d++;
		}
	}
	
	else if(real){
                while(d < nports){                                      
                        if(testopen(rnmapports[d]) != 0){                
 			       if(testclosed(rnmapports[d]) != 0){               
 				       addfport(rnmapports[d]);          
			       }
			}                                       
 		        d++;
		}
	}

	else if(filterscan){
		printf("Opps: internal error filter scan should not have started yet\n");
		exit(1);
	}
	
	else if(all){
		printf("Parsing all ports into filtered list\n");
		while(d <= 65535){
			if(testopen(d)!=0){
				if(testclosed(d)!=0){
					addfport(d);
				}
			}
			d++;
		}
	}
        
	else {
        	while(!stoploop){
			p_curr = ptpoint;
			if(p_curr == NULL){
				printf("port ll is empty\n");
				exit(1);
			}
		
			while((p_curr != NULL) && (p_curr->fdone == 1)){
				p_curr = (PPT) p_curr->nextpt;
				//printf("looping\n");
			}

			if(p_curr == NULL){
				//printf("end of list\n");
				stoploop = 1;
			}

			else {
				//printf("testing p_curr->num %d fdone %d\n", p_curr->num, p_curr->fdone );
				p_curr->fdone = 1;
				if(testopen(p_curr->num) !=0){
					if(testclosed((p_curr->num) !=0)){
						//printf("adding addfort\n");
						addfport(d);
					}
				}
			}
		}
	}
}

void parseffports(void)
{
	//loop through each port we scan
	//testing in both open and closed port lists.... if not found put in filtered list
 
        int d;
	int testopen(u_short);
	int testclosed(u_short);
        COPT c_curr;
        POPT o_curr;
        FOPT f_curr;       
        d = 0;
                         
        c_curr = cportpoint;
        o_curr = portpoint;
        f_curr = fportpoint;

	//printf("parseffports\n");
	if(filterscan){
		f_curr = fportpoint;
	//	if(f_curr == NULL){
			//printf("final filter port list empty\n");
	//	}
		while((f_curr != NULL)){
			if(testclosed(f_curr->num)!=0){
				if(testopen(f_curr->num)!=0){
					addffport(f_curr->num);
				}
			}
			f_curr = (FOPT) f_curr->nextport;
		}
	}
}

int testopen(u_short port)
{
	//1 on not in list
	//0 in list
	//
	POPT p_curr;
	p_curr = portpoint;
	if(p_curr == NULL){
	//	printf("open list empty\n");
		return(1);
	}
	while((p_curr != NULL) && (p_curr->num != port)){
		p_curr = (POPT) p_curr->nextport;
	}
	if(p_curr == NULL){
	//	printf("not in open list\n");
		return(1);
	}
	else return(0);

}


int testclosed(u_short port)
{
	COPT p_curr;

	p_curr= cportpoint;
	if(p_curr == NULL){
	//	printf("closed list empty\n");
		return(1);
	}
	while(p_curr != NULL && p_curr->num != port){
		p_curr = (COPT) p_curr->nextport;
	}
	if(p_curr == NULL){
	//	printf("not in open list\n");
		return(1);
	}
	else return(0);
}

void end_portscan(void)
{
	void cleanup(int sigio);
	extern int ffportllcount(void);
	PPT p_curr;
	
	v = 0;
	if(endwait){		
		if(endwait != 2)printf("Port scan finished... waiting %d seconds for any more results\n", endwait);
		sleep(endwait);
	}
	else{
		printf("Port scan finished...\n");
		usleep(500);
	}
	
	if(!jumpfilter)	parseffports();
	printportll();
	if(displayclosed) printcportll();
	if(displayfiltered || (ffportllcount() <= FILTERDISPLAYLIMIT)) printffportll();
	//free ll
	if(!all && !nmap && !osstm && !real){
		if(v>2)printf("\nFreeing linked list of ports\n");
		while(ptpoint != NULL){
			p_curr = ptpoint;
			ptpoint = (PPT) ptpoint->nextpt;
			free(p_curr);
			//printf("freeing, "); 
		}
	}
	//freeportll();
	//freefportll();
	//freecportll();
	cleanup(0);
}

