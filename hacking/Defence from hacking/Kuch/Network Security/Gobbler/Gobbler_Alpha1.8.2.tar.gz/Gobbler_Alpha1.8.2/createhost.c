#include "gobbler.h"

extern int dhcpdetected;
extern int dhcpgobbling;
extern int dhcpgobblestarted;
extern int dhcpreplyinfo;
extern int phosts;
extern int noprintinfo;

//creates a single host... mainly for testing purposes
void startcreatehost(void)
{
	
	extern int checkdhcp(int);
	extern void startdhcpdiscover(void);
	//int dhcpreplyinfo;
	
	printf("create a single host to test out TCP/IP stack\n");
	dhcpgobblestarted = 1;
	dhcpreplyinfo = 1;
	dhcpgobbling = 1;
	startdhcpdiscover();
	//sleep(1);
	noprintinfo = 1;
	phosts = 1;
	if(checkdhcp(0) != 0){
		printf("Opps: checkdhcp error\n");
		exit(1);
	}
	
	dhcpreplyinfo = 0;
	dhcpgobblestarted = 0;
	dhcpgobbling = 0;

	if(!dhcpdetected){
		printf("Opps: DHCP service not detected\n");
		exit(1);
	}
	
	printf("\nhost created.... do what you will to it\n\n");
	printf("ctrl+c to exit\n");
	for(;;){
		sleep(1);
	}
			
		

}
