/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

pthread_mutex_t plistlock = PTHREAD_MUTEX_INITIALIZER;


//linked list for ports we need to scan
int addpt(u_short num)
{
	pt * ptpointer;
	ptpointer = ptpoint;

	
	//printf("port %d to be added\n", num);
	if(ptpointer != NULL){ //not 1st entry
		while(ptpointer->nextpt != NULL){
			ptpointer = (PPT) ptpointer->nextpt;
		}

		ptpointer->nextpt = (struct pt *)malloc(sizeof(pt));
		if(ptpointer->nextpt == NULL){
			printf("Opps: Malloc error not 1st\n");
			exit(1);
		}

		ptpointer = (PPT) ptpointer->nextpt;
		ptpointer->nextpt = NULL;
		ptpointer->num = num;
		ptpointer->done = 0;
		ptpointer->fdone = 0;
		return(0);
	}
		
	else {
		//1st entry
		ptpoint = (PPT) calloc(sizeof(pt), 1);
		ptpoint->nextpt = NULL;
		ptpoint->num = num;
		ptpoint->done = 0;
		ptpoint->fdone = 0;
		return(0);
	}

	//shouldn;t reach here
	return(0);
}

void printpll(void)
{
	PPT p_curr;

	p_curr = ptpoint;

	printf("Port linked list\n");
	
	if(ptpoint == NULL) printf("linked list is empty\n");
	else{
		while(p_curr != NULL){
			printf("%d, ", p_curr->num);
			p_curr = (PPT) p_curr->nextpt;
		}
		printf("\n");
	}
}

int pllcount(void)
{
	PPT p_curr;
	int c = 0;
	p_curr = ptpoint;
	
	if(ptpoint == NULL) return(0);
	else {
		while(p_curr != NULL){
			c++;
			p_curr = (PPT)p_curr->nextpt;
		}
	}
	return(c);
}
	
