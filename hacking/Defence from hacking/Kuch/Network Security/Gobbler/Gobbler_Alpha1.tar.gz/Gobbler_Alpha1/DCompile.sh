#!/bin/bash
gcc `libnet-config --defines --cflags` arpscan.c convert.c dhcpgobble.c dhcpdiscover.c portscan.c miscfuncs.c ll.c pll.c main.c /usr/local/lib/libdnet.a /usr/lib/libpcap.a -lpthread -Wall -D_REENTRANT -ggdb -g -o Gobbler `libnet-config --libs`
exit
