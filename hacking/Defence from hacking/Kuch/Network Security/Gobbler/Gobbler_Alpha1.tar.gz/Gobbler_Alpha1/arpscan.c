/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

static pthread_once_t endarpscanlock = PTHREAD_ONCE_INIT;
extern int arpscanstarted;
extern int acount;
extern libnet_t *l;
extern u_int sleeparg;
extern u_int endwait;
pthread_mutex_t arplock = PTHREAD_MUTEX_INITIALIZER; //lock to ensure arp scan increments by one each time

void startarpscan(void)
{
	void thread_arpscan(int);
	int i;
			 
	printf("Detecting IP addresses via spoofed broadcast ARP scan using %d threads\n\n", MAXARPSCANHANDLER);
	aptr = calloc(MAXARPSCANHANDLER, sizeof(athread));
	
	for(i=0; i<MAXARPSCANHANDLER; i++){
		thread_arpscan(i);
	}
}
 
void thread_arpscan(int i)
{
	void *arpscan(void *);
	arpscanstarted = 1;
	if(pthread_create(&aptr[i].thread_tid, NULL, &arpscan, (void *) i) < 0){
		printf("Opps: pthread_create error\n");
		exit(1);
	}
}

void arpscan(void *tnum)
{
	//scans class b in approx 70 secs with 1000 threads :)
	void addstats(struct libnet_stats);
        void end_arpscan(void);
        libnet_ptag_t t;
        u_long i,j; //src + dst ip addresses
        int c;
	int buildether;
        unsigned char *bytes;
         
        u_char enet_src[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
        u_char enet_dst[6] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
         
        if(pthread_detach(pthread_self()) <0){
        	printf("Opps: pthread_detach error\n");
                pthread_exit(&status);
        }
                                                
	if(v>2)printf("Arp scan started on thread(%ld)\n", pthread_self());
        
	buildether = 1;
	
	while(acount != addrcount){
		pthread_mutex_lock(&arplock);
		acount++;
	        pthread_mutex_unlock(&arplock);
        
		i = -1; //Source IP 255.255.255.255.... corrisponding to MAC addr ff:ff:ff:ff:ff:ff :)
	       	//change each ip
        	bytes = (unsigned char *)&localnet; 
	        if(bytes[3] == 255) bytes[2]++;
        	bytes[3] = acount;
	        if((bytes[3] == 0) &&(bytes[2]==0) && acount >1) {
		        //printf("looped around\n");
			libnet_destroy(l);
			pthread_once(&endarpscanlock, end_arpscan);
			pthread_exit(&status);
		}
		memcpy(&j, bytes, sizeof(j));
		
		t = libnet_build_arp(
			ARPHRD_ETHER,   //HW type
			ETHERTYPE_IP,   //Proto
		        6,              //Hsize
		        4,              //psize
	        	ARPOP_REQUEST,  //opcode
		        enet_src,       //sender HW address
		        (u_char *)&i,   //sender proto address
	        	enet_dst,       //receiver HW address
			(u_char *)&j,   //receiver proto address
		        NULL,           //payload
	        	0,              //payload size
		        l,              //libnet handle
		       	0);             //libnet id
		                                                                                                                                                if(t == -1){
			printf("Opps: Can;t build ARP header as %s\n\n", libnet_geterror(l));
			libnet_clear_packet(l);
			exit(1);
		}
		t = libnet_build_ethernet(
			enet_src,       //enet source
	        	enet_dst,       //enet dest
		        ETHERTYPE_ARP,  //proto addr
			NULL,           //payload
	        	0,              //payload size
		        l,              //libnet handle
		        0);             //libnet id
	
		if(t == -1){
			printf("Opps: Can;t build ethernet header as %s\n\n", libnet_geterror(l));
	       		libnet_clear_packet(l);
		        exit(1);
		}
	
		 if((c = libnet_write(l)) == -1){
			printf("Opps: libnet_write error as %s\n", libnet_geterror(l));
			libnet_clear_packet(l);
			sleep(1);
		}
	  
		libnet_stats(l, &gs);
		libnet_clear_packet(l);
		if(sleeparg) usleep(sleeparg);
		else usleep(75000);
	}
       	pthread_once(&endarpscanlock, end_arpscan);
	pthread_exit(&status);
}
 
 
void end_arpscan(void)
{
	void cleanup(int sigio);
	if(endwait) printf("Arp scan finished... waiting for %d seconds for any more replies\n", endwait);
	else printf("Arp scan finished...\n");
	sleep(endwait);
	cleanup(0);
}
