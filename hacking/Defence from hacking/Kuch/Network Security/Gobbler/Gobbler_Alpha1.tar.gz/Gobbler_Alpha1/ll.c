/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

//linked list

pthread_mutex_t listlock = PTHREAD_MUTEX_INITIALIZER;

int addmt(mtnode mactran)
{
	//mutexlock
	int i;
	mt * mtpointer;
	
	pthread_mutex_lock(&listlock);
	mtpointer = mtpoint; //mtpoint should be global

	if(mtpointer != NULL){ //not 1st entry
		while(mtpointer->nextmt != NULL){
			mtpointer = (PMT) mtpointer->nextmt;
		}
		mtpointer->nextmt = (struct mt *) malloc(sizeof(mt));
		if(mtpointer->nextmt == NULL){
			printf("Opps: malloc error in addmt\n");
			exit(1);
		}
		mtpointer = (PMT) mtpointer->nextmt;
		mtpointer->nextmt = NULL;
		for(i=0; i<6; i++){
			mtpointer->srcmac[i] = mactran.srcmac[i];
		}
		mtpointer->transid = mactran.transid;
		mtpointer->ipaddress = mactran.ipaddress;
			for(i=0; i<4; i++){
			mtpointer->serverip[i] = mactran.serverip[i];
		}
		mtpointer->lastdhcptype = mactran.dhcptype;
		pthread_mutex_unlock(&listlock);
		return 0;
	}
	
	else { //1st entry
	//	mtpoint = (struct mt *) malloc(sizeof(mt));
		mtpoint = (PMT) malloc(sizeof(mt));
		if(mtpoint->nextmt == NULL){
			printf("Opps: malloc error in addmt\n");
			exit(1);
		}
		mtpoint->nextmt = NULL;
		for(i=0; i<6; i++){
			mtpoint->srcmac[i] = mactran.srcmac[i];
		}
		mtpoint->transid = mactran.transid;
		mtpoint->ipaddress = mactran.ipaddress;
		for(i=0; i<4; i++){
			mtpoint->serverip[i] = mactran.serverip[i];
		}
		mtpoint->lastdhcptype = mactran.dhcptype;
		pthread_mutex_unlock(&listlock);
		return 0;
	}
	
	//shouldn't reach here
	pthread_mutex_unlock(&listlock);
	return(0);
	
}

int updatell(mtnode mactran)
{
	PMT p_curr, p_top;
	int i;
	
	pthread_mutex_lock(&listlock);
	p_top = p_curr = mtpoint;
	if(p_curr == NULL){
		//printf("Opps: ll empty\n");
		//printll(mtpoint);
		pthread_mutex_unlock(&listlock);
		return 0;
	}
	
	while((p_curr != NULL) && (p_curr->transid != mactran.transid)){
		p_curr = (PMT) p_curr->nextmt;
	}

	if(p_curr == NULL){
		//printf("Opps: update transid not found in ll\n");
		pthread_mutex_unlock(&listlock);
		return 0;
	}
	
	else{
		//printf("transid found....updating node in ll\n");
		//p_curr->transid = mactran.transid;
		if(p_curr->ipaddress == 0) p_curr->ipaddress = mactran.ipaddress;
		if(p_curr->serverip[0] == 0){
			for(i=0; i<4; i++){
				p_curr->serverip[i] = mactran.serverip[i];
			}
		}
		p_curr->lastdhcptype = mactran.dhcptype;
		if(vll)printll();
		pthread_mutex_unlock(&listlock);
		return 0;
	}
	//shouldn't reach here
	pthread_mutex_unlock(&listlock);
}
	

int checkll(mtnode mactran)
{
	//void printll(void);
	PMT p_curr, p_top;
	p_top = p_curr = mtpoint;

	if(mactran.dhcptype == DISCOVERSENT){
		if(p_curr == NULL){
			//printf("ll empty adding info\n");
			addmt(mactran);
			//printll();
			return 0;
		}

		while(p_curr != NULL){
			p_curr = (PMT) p_curr->nextmt;
		}

		if(p_curr == NULL){
			//printf("not found... adding\n");
			addmt(mactran);
			//printll();
			return 0;
		}
		else{
			printf("Opps.... p_curr != NULL\n");
			exit(1);
		}
	}
	
	else printf("Opps: not DHCPDISCOVER packet\n");
	return 0;
}

void printll(void)
{
	PMT p_curr; 
	unsigned char *ip;
	p_curr = mtpoint;
	printf("MAC Linked List\n");
	
	if(mtpoint == NULL) printf("Linked list is empty\n");
	else {
		while(p_curr != NULL){
			ip = (unsigned char *)&(p_curr->ipaddress);
			printf("Trans id 0x%x coupled with mac %x:%x:%x:%x:%x:%x serverip %d.%d.%d.%d offered ip %d.%d.%d.%d in state %d\n", (u_int32_t)p_curr->transid,  p_curr->srcmac[0], p_curr->srcmac[1], p_curr->srcmac[2], p_curr->srcmac[3], p_curr->srcmac[4], p_curr->srcmac[5], (u_int8_t)p_curr->serverip[0], (u_int8_t)p_curr->serverip[1], (u_int8_t)p_curr->serverip[2], (u_int8_t)p_curr->serverip[3], ip[0], ip[1], ip[2], ip[3], p_curr->lastdhcptype);
			p_curr = (PMT) p_curr->nextmt;
		}
	}
}
		
