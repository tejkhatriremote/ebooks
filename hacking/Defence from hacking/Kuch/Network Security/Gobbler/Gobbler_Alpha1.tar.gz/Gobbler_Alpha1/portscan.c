/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"
#include "ports.h"
extern int portscanstarted;
extern int dhcpreplyinfo;
extern int dhcpgobblestarted;
extern int dhcpgobbling;
extern pthread_mutex_t listlock;
extern pthread_mutex_t plistlock;
pthread_mutex_t portcountlock = PTHREAD_MUTEX_INITIALIZER;
static pthread_once_t endportscanlock = PTHREAD_ONCE_INIT;
extern libnet_t *q, *l;
extern char* hostname;
extern char* portlist;
extern int portl;
extern int phosts;
extern u_int sleeparg;
extern u_int endwait;
extern u_int arpwait;
libnet_plist_t plist, *plist_p;
u_short eport;
u_short sport;
u_int ssport;
int d;
int all;
int osstm;
extern u_int16_t srcprt;
int nports;


void startportscan(void)
{
	void thread_portscan(int);
	void startdhcpdiscover(void);
	void portlisttopll();
	int i,j;
	struct in_addr sa;
	
	all = 0;
	osstm = 0;
	
	if(!inet_aton(hostname, &sa)){
		printf("\nOpps: %s is a invalid ip address\n", hostname);
		exit(1);
	}

	if(strncmp(portlist, "ALL", sizeof(portlist)) == 0){
		//printf("All ports to be scanned\n");
		all = 1;
	}

	else if(strncmp(portlist, "OSSTM", sizeof(portlist)) == 0){
		for(nports = 0; nports < sizeof(tcpports) ; nports++){
			if(tcpports[nports] == 0){
				break;
			}
		}
		if(v>1)printf("OSSTM ports to be scanned total: %d\n",nports);
		osstm = 1;
	}
	
	else{
		if(portl){
			portlisttopll();	
		}
		else {
			printf("Opps: port list error\n\n");
			exit(1);
		}
	}
	printf("Gobbling an IP address for use in portscanner\n");
	pptr = calloc(MAXPORTSCANHANDLER, sizeof(portthread));
	
	dhcpreplyinfo = 1; //printf info about dhcp server
	dhcpgobblestarted = 1; //vars for gobbling
	dhcpgobbling = 1; //vars for gobbling

	for(j=0;j<phosts;j++){
		startdhcpdiscover(); //should give us some mac n ip addresses;
	}
	
	sleep(phosts*2);
	dhcpreplyinfo = 0; //reset gobbler args
	dhcpgobblestarted = 0;
	dhcpgobbling = 0;
	
	portscanstarted = 1;
	sport = 0;
	ssport = 0;
	printf("Starting port scan\n");
	for(i=0;i<MAXPORTSCANHANDLER; i++){
		thread_portscan(i);
	}
}

void thread_portscan(int i)
{
	void * pscan(void *);

	if(pthread_create(&pptr[i].thread_tid, NULL, &pscan, (void *)i)<0){
		printf("Opps: pthread_create error as %s\n", strerror(errno));
		exit(1);
	}
}

void pscan(void *tnum)
{	
	void end_portscan(void);
	int send_arpreq(u_int32_t, u_int32_t);
	void cleanup(int sigio);
	u_int32_t convert32(char *,int, int, int, int);
	libnet_ptag_t t;
	int c,a,b;
	int endflag = 0;
	u_int32_t seq;
	u_int16_t id;
	PMT p_curr, p_top;
	PPT pp_curr, pp_top;
	u_char enet_src[6];
	u_char *tmac;
	struct in_addr sa;
	struct route_entry entry;
	struct arp_entry aentry;
	route_t *r;
	arp_t *arp;
	int cport;
	unsigned char *ip;

	if(v>2)printf("port scanning pthread_created %ld\n",pthread_self());
	if(pthread_detach(pthread_self()) != 0){
		printf("Opps: pthread_detach error\n");
		exit(1);
	}
	
	if(!inet_aton(hostname, &sa)){
		printf("\nOpps: %s is a invalid ip address\n", hostname);
		exit(1);
	}

	p_curr = p_top = mtpoint;

	if(p_curr == NULL){
		printf("Opps: Linked list empty\n");
		exit(1);
	}
	
	while((p_curr != NULL) && (p_curr->lastdhcptype != 4) && (p_curr->type == PORTSCANNINGSOURCE)){
		p_curr = (PMT) p_curr->nextmt;
	}

	if(p_curr == NULL){
		printf("No available ip address found\n");
		exit(1);
	}
	
	else{
		pthread_mutex_lock(&listlock);
		p_curr->type = PORTSCANNINGSOURCE;
		pthread_mutex_unlock(&listlock);
		ip = (unsigned char *)&(p_curr->ipaddress);
		if(v)printf("Found an ip address %d.%d.%d.%d and mac %x:%x:%x:%x:%x:%x in LL thread %ld\n", (u_int8_t)ip[0], (u_int8_t)ip[1], (u_int8_t)ip[2], (u_int8_t)ip[3], p_curr->srcmac[0], p_curr->srcmac[1], p_curr->srcmac[2], p_curr->srcmac[3], p_curr->srcmac[4], p_curr->srcmac[5], pthread_self());
		for(a=0; a<6; a++){
			enet_src[a] = p_curr->srcmac[a];
		}
	}		
	
	count = 0;
	if(!arpwait) arpwait = 10000;
	if(tnum != 0) usleep(arpwait); //LAME wait for arp reply from 1st thread
	if((r = route_open()) == NULL){
		printf("Opps: libdnet Route open error\n\n");
		exit(1);
	}
	if(addr_aton(hostname, &entry.route_dst)<0){
		printf("Opps: addr_aton error\n");
		exit(1);
	}
	if(route_get(r, &entry) < 0){
		if(v)printf("Opps: Libdnet route_get error.... guessing IP address is on this subnet\n");
			if(addr_pton(hostname , &aentry.arp_pa)<0){
			printf("Opps: addr_pton error Invalid IP address\n");
			exit(1);
		}
	
		route_close(r);
		b = 0;
		if((arp = arp_open()) == NULL){
			printf("Opps: libdnet arp open error\n");
			exit(1);
		}
			while((arp_get(arp, &aentry) <0) && b != 3){
			printf("Opps: arp_get error sending arp request packet\n");
			b++;
			tmac = (unsigned char *)&aentry.arp_pa.addr_ip;
			if(send_arpreq(p_curr->ipaddress, htonl(convert32(tmac,0,1,2,3))) != 0){
				printf("Opps: send arpreq error\n");
				exit(1);
			}	
			sleep(3);
		}
			
		if(b == 3){
			printf("Opps: couldn't get mac address port scan terminating....\n");
			arp_close(arp);
			cleanup(0);
		}
		else {
			arp_close(arp);
			if(v)printf("%s at %s\n", addr_ntoa(&aentry.arp_pa), addr_ntoa(&aentry.arp_ha));
		}
	}
	
	else {
		//ip address not on this subnet
		route_close(r);
		b = 0;
		if(v)printf("%s gateway %s\n", addr_ntoa(&entry.route_dst), addr_ntoa(&entry.route_gw));
		aentry.arp_pa = entry.route_gw;
		
		if((arp = arp_open()) == NULL){
			printf("Opps: libdnet arp open error\n");
			exit(1);
		}
		while((arp_get(arp, &aentry) <0) && b != 3){
			printf("Opps: arp_get error sending arp request packet\n");
			b++;
			tmac = (unsigned char *)&aentry.arp_pa.addr_ip;
			if(send_arpreq(p_curr->ipaddress, htonl(convert32(tmac,0,1,2,3))) != 0){
				printf("Opps: send arpreq error\n");
				exit(1);
			}
			sleep(3);
		}
			
		if(b == 3){
			printf("Opps: couldn't get mac address port scan terminating....\n");
			arp_close(arp);
			cleanup(0);
		}
		
		else {
			arp_close(arp);
			if(v)printf("%s at %s\n", addr_ntoa(&aentry.arp_pa), addr_ntoa(&aentry.arp_ha));
		}
	}
	
	for(;;){		
		if(all){
			pthread_mutex_lock(&portcountlock);
			cport = ssport++;
			if(cport == 65535){
				//pthread_mutex_unlock(&portcountlock);
				//goto END;
				endflag = 1;
			}
			else if(cport > 65535){
				pthread_mutex_unlock(&portcountlock);
				goto END;
			}
			pthread_mutex_unlock(&portcountlock);
		}

		else if(osstm){
			pthread_mutex_lock(&portcountlock);
			if(d == nports){
				pthread_mutex_unlock(&portcountlock);
				goto END;
			}
			cport = tcpports[d++];
			pthread_mutex_unlock(&portcountlock);
		}
		else{
			pp_curr =  pp_top  = ptpoint;
			if(pp_curr == NULL){
				//printf("pll is empty top %ld\n", pthread_self());
				exit(1);
			}
			pthread_mutex_lock(&plistlock);
			while((pp_curr != NULL) && (pp_curr->done == 1)){
				//printf("loop\n");
				pp_curr = (PPT) pp_curr->nextpt;
			}
			if(pp_curr == NULL){
				//printf("pll is empty middle %ld\n", pthread_self());
				pthread_mutex_unlock(&plistlock);
				goto END;
			}
			else{
				cport = pp_curr->num;
				pp_curr->done = 1;
				pthread_mutex_unlock(&plistlock);
			}
			pthread_mutex_unlock(&plistlock);
		}	
		
		seq = libnet_get_prand(LIBNET_PRu32);
		id = libnet_get_prand(LIBNET_PRu16);
		if(!srcprt){
			srcprt = libnet_get_prand(LIBNET_PRu16);
		}
					
		t = libnet_build_tcp(
			srcprt,		//srcport
			(u_short)cport,	//dstport
			seq,		//seq number
			0,		//ack number
			TH_SYN,		//Flags
			5000, 		//window size
			0,		//checksum
			0,		//urg pointer
			LIBNET_TCP_H,	//packet size
			NULL,		//payload
			0,		//payload size
			l,		//libnet handle
			0);		//libnet id
		if(t == -1){
			printf("Opps: libnet_build_tcp error as %s\n\n", libnet_geterror(l));
			exit(1);
		}

		t = libnet_build_ipv4(
			LIBNET_TCP_H + LIBNET_IPV4_H, //length
			0,		//TOS
			id,		//id
			0,		//IP frag
			64,		//TTL
			IPPROTO_TCP,	//protocol
			0,		//checksum
			p_curr->ipaddress, //srcip
			sa.s_addr,	//dstip
			NULL,		//payload
			0,		//sizeof payload
			l,		//libnet handle
			0);		//libnet id
		if(t == -1){
			printf("Opps: libnet_build_ipv4 error as %s\n\n", libnet_geterror(l));
			exit(1);
		}
	
		t = libnet_build_ethernet(
			(u_char *)&aentry.arp_ha.addr_eth,//macdst, //enet_dst,	//dst mac
			enet_src,	//src mac
			ETHERTYPE_IP,	//proto
			NULL,		//payload
			0,		//payload size
			l,		//libnet handle
			0);		//libnet id
		if(t == -1){
			printf("Opps: libnet_build_ethernet error as %s\n\n", libnet_geterror(l));
			exit(1);
		}

		c = libnet_write(l);
		if(c == -1){
			printf("Opps: libnet_write error as %s\n",libnet_geterror(l));
			exit(1);
		}
		libnet_stats(l, &gs);
		libnet_clear_packet(l);
		if(all && endflag){
			goto END;
		}
				
		if(sleeparg) usleep(sleeparg);
		else usleep(75000);
		
	}
	END:
	pthread_once(&endportscanlock, end_portscan);
	pthread_exit(&status);
}

int send_arpreq(u_int32_t srcip, u_int32_t dstip)
{
	libnet_ptag_t t;
	u_char enet_src[6];
	u_char enet_dst[6] = {0xff,0xff,0xff,0xff,0xff,0xff};
	u_char enet_blank[6] = {0x00,0x00,0x00,0x00,0x00,0x00};
	u_char *sip, *dip;
	PMT p_curr, p_top;
	u_char *packet;
	u_long packet_s;
	int c, x;	
	
	
	p_curr = p_top =mtpoint;
	if(p_curr == NULL){
		//printf("LL empty\n");
		return(0);
	}
        
	while((p_curr != NULL) && (p_curr->ipaddress != srcip)){
		p_curr = (PMT) p_curr->nextmt;
	}
	if(p_curr == NULL){
       		//printf("Not found in list\n");
       		return(0);
       	}
        else{
		//found
 		for(x=0; x<6; x++){
                	enet_src[x] = p_curr->srcmac[x];
		}
		
		sip = (unsigned char *)&srcip;
		dip = (unsigned char *)&dstip;
		
		t = libnet_build_arp(
			ARPHRD_ETHER,
			ETHERTYPE_IP,
			6,
			4,
			ARPOP_REQUEST,
			enet_src,
			sip,
			enet_blank,	//dst mac
			dip,		//dst ip
			NULL,
			0,
			q,
			0);
		if(t == -1){
			printf("Opps: Can;t build arp packet as %s\n",libnet_geterror(q));
			exit(1);
		}
		
		
		t = libnet_build_ethernet(
				enet_dst,
				enet_src,
				ETHERTYPE_ARP,
				NULL,
				0,
				q,
				0);
		if(t == -1){
			printf("Opps: Can;t build ethernet header as %s\n",libnet_geterror(q));
			exit(1);
		}

		c = libnet_adv_cull_packet(q, &packet, &packet_s);
		if(c == -1){
			printf("Opps: cull error\n");
			exit(1);
		}
		c = libnet_write(q);
		if(c == -1){
		        printf("Opps: libnet_write error as %s\n", libnet_geterror(q));
                        libnet_clear_packet(q);
                }
		 
                libnet_stats(q, &gs);
                libnet_clear_packet(q);
                if(v)printf("\nsent arp request\n");
		return(0);
	}			
	return(0);
}

//libnets port list to linked list converter
void portlisttopll(void)
{
	u_short sport,eport, cport;
	u_short portpaircount;
	int flag = 0, h;
	portpaircount = 0; //init to 0
	
	plist_p = &plist;
	if(libnet_plist_chain_new(l, &plist_p, portlist) == -1){
		printf("Opps: Invalid port as %s\n",libnet_geterror(l));
		exit(1);
	}
	if(v)printf("Port list: %s\n", libnet_plist_chain_dump_string(plist_p));
	while(flag!=1){
		h = libnet_plist_chain_next_pair(plist_p, &sport, &eport);
		if(h != 1){
			if(h == 0){
				if(v>2)printf("No more port pairs... port pair count: %d\n\n", portpaircount);
				if(flag != 1){
					flag = 1;
				}
			}	
			if(h == -1){
				printf("Opps: libnet_plist_chain_next_pair error\n\n");
				exit(1);
			}
		}	
		else {
			portpaircount++;
			if(v>2)printf("pair %d: startport = %d endport = %d\n",portpaircount,sport, eport);
			while(!(sport > eport) && (sport != 0)){
				cport = sport++;
				if(addpt(cport) != 0){
					printf("Opps: add port to linked list error\n\n");
					exit(1);
				}
			}
	
		}
	}
	if(portpaircount == 0){
		printf("Opps: portpaircount error\n\n");
		exit(1);
	}
	if(v>2)printpll();
	if(libnet_plist_chain_free(plist_p) == -1){
		printf("Opps: libnet_plist_chain_free error\n\n");
		exit(1);
	}
}

void end_portscan(void)
{
	void cleanup(int sigio);
	PPT p_curr;

	if(endwait){
		printf("Port scan finished... waiting %d seconds for any more results\n", endwait);
		sleep(endwait);
	}
	else{
		printf("Port scan finished...\n");
		usleep(500);
	}

	//free ll
	if(!all){
		if(v>2)printf("freeing linked list of ports\n");
		while(ptpoint != NULL){
			p_curr = ptpoint;
			ptpoint = (PPT) ptpoint->nextpt;
			free(p_curr);
			//printf("freeing, "); 
		}
	}
	cleanup(0);
}

