/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//miscfuncs.c
#include "gobbler.h"
static pthread_once_t elock = PTHREAD_ONCE_INIT; //insures stats printed once 
extern int ipgobblecount;
extern int dhcpgobbling;
extern int dhcpgobbling;

void cleanup(int signo)
{
	void printstats(void);
	int i;
	for(i=0; i<MAXPACKHANDLER; i++){
		count += tptr[i].thread_count;
	}
	fflush(stdout);
	pthread_once(&elock, (void *)printstats);
}

void addstats(struct libnet_stats local)
{
	gs.packets_sent += local.packets_sent;
	gs.packet_errors += local.packet_errors;
	gs.bytes_written += local.bytes_written;
}


void printstats(void)
{
	void pr_cpu_time(void);
	struct pcap_stat stat;
	int scount;
	
	if(pcap_stats(pd, &stat)<0){
		printf("\nOpps: pcap_stats error as %s\n", pcap_geterr(pd));
		exit(1);
	}

	scount = (count) - (drop) - (stat.ps_drop);
	if(scount < 0) scount = count; //opps we dropped more packet than we handled
	

	printf("\n---Gobbler Stats---\n");
	printf("%d/%d packets handled from filter (using %d packet handling threads)\n",count, stat.ps_recv, MAXPACKHANDLER);
	printf("%d successfully decoded, %d packets dropped (kernel: %d gobbler: %d)\n", scount,stat.ps_drop + drop, stat.ps_drop, drop);
	printf("%d IP addresses gobbled, ", ipgobblecount);
	printf("%ld packets sent, %ld packet errors,  %ld bytes written\n", gs.packets_sent, gs.packet_errors, gs.bytes_written);
	pr_cpu_time();
	free(tptr);
	exit(0);
}

void egg()
{
	printf("\n\t\t\tShoutz\n\n"\
		"\tdotslash slider ryza sleepyhead andy\n"\
		"\t  everyone else at astalavista.net\n\n"\
		"\t\t  polotron + rootless\n"\
		"\tfor giving me a ickle job (cheers guys)\n\n"\
		"\t\tbassintro for hosting\n"\
		"\t\t   (www.clove.net)\n\n"\
		"\t\t     lee and stan\n"\
		"\t\tfor being lee and stan\n\n"\
		);
}

void pr_cpu_time(void)
{
        double user, sys;
	struct rusage myusage, childusage;
			 
	if(getrusage(RUSAGE_SELF, &myusage) < 0){
		printf("Opps: getrusage error\n");
		exit(1);
	}
				 
	if(getrusage(RUSAGE_CHILDREN, &childusage) < 0){
		printf("Opps: getrusage error\n");
		exit(1);
	}
				 
	user = (double) myusage.ru_utime.tv_sec + myusage.ru_utime.tv_usec /1000000.0;
	user += (double) childusage.ru_utime.tv_sec + childusage.ru_utime.tv_usec /1000000.0;
						 
	sys = (double) myusage.ru_utime.tv_sec + myusage.ru_utime.tv_usec /1000000.0;
	sys += (double) childusage.ru_utime.tv_sec + childusage.ru_utime.tv_usec /1000000.0;
									 
	if((gettimeofday(&endtime,NULL)) != 0){
		printf("Opps: gettimeofday error\n");
		exit(1);
	}
										 
	printf("running time: %ld seconds, user time = %g, sys time = %g\n", (endtime.tv_sec - inittime.tv_sec), user, sys);
}
 

void usage(char *progname)
{
	printf( "Scanning Options\n"\
		"-a detect IP addresses via spoofed ARP scan\n"\
		"-d detect dhcp service on network\n"\
                "-g gobble attack.... DoS DHCP server via IP exaution attack\n"\
		"-p <ip address> SYN scan using a gobbled IP address\n"\
		"-P <135-139,445> <ALL> <OSSTM> ports to be scanned\n"\
	/*	"-N <ip address> none spoofed SYN scan (TODO)\n"\*/
	/*	"-n <x> Number of spoofed source hosts used in -p scan (TODO)\n"\ */
		"-k <port> source port number\n"\
		"-s start sniffer\n"\
		"\nMisc\n"\
		"-v verbose (may be used 3 times for increased debugging info)\n"\
		"-V display linked list after every update (used when gobbling a IP address)\n"\
		"-i <eth0> interface for sniffer and packet injector\n"\
		"-T Tag mac addresses (each will end in 4e:50)\n"\
		"-S <x> sleep for x microseconds between each packet (per thread) (default 75000)\n"\
		"-E <x> sleep for x seconds at end of scan to wait for any more replies (default 5)\n"\
		"-A <x> sleep for x microseconds for 1st arp request to be answered from portscan (default 10000)\n"\
		"\nExamples\n"\
		"Simple Sniffer: %s -s -v -i eth0\n"\
		"Arp Scan: %s -a -i eth0\n"\
		"Spoofed portscan: %s -p192.168.1.1 -P OSSTM\n"\
		"Gobble DoS: %s -g \n\n"\
		"WARNING read README.1ST before running any scanning options\n\n", progname, progname, progname, progname);
	exit(1);
}

