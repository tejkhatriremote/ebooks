/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "gobbler.h"

//globals
pthread_mutex_t mlock = PTHREAD_MUTEX_INITIALIZER; //mutex lock to ensure different thread deals with each pack
pthread_mutex_t packetlock = PTHREAD_MUTEX_INITIALIZER; //packet lock used to control access to libnet
extern pthread_mutex_t listlock;
static pthread_once_t caddrlock = PTHREAD_ONCE_INIT; //count available addresses from netmask once n only once
static pthread_once_t p_once = PTHREAD_ONCE_INIT; //create key for thread specifc data once n only once
int arpscanstarted = 0; 
int dhcpdiscoverstarted = 0;
int dhcpdiscoverservice = 0;
int portscanstarted = 0;
int sniffer;
int dhcpdetected;
int dhcpgobblestarted = 0;
int dhcpgobbling = 0;
int ipgobblecount = 0;
int packid = 0;
int portscan = 0;
int nongportscan = 0;
int dhcpmitm = 0;
int arpcache = 0;
u_int16_t srcprt = 0;
u_int endwait = 0;
u_int maskcount;
int srcportoption = 0;
int fast = 0;
libnet_t *l;
libnet_t *q;
int noprintinfo;
extern int dhcpreplyinfo;
extern int dhcpmitmstarted;
u_char *hostname;
char *nongsrcip;
char *nongsrcmac;
mt *mtpoint;
pt *ptpoint;
port *portpoint;
macip *macippoint;

char *snifffilter;
int phosts;
char *portlist;
int portl;
int ng;
int arprecvcount;

//prototypes
static void p_destructor(void *ptr);
void startdhcpdiscover(void);
extern void set_rlimits(void);

int main(int argc, char *argv[])
{
	void startdhcpgobble(void);
	void startsniffer(int);
	void startarpscan(void);
	void startlibnet(void);
	void startportscan(char *);
	void startdhcpmitm(void);
	void egg();
	
	mtnode mt;
	struct in_addr sa;
	eth_t *e;
	struct intf_entry *ea; //HERE SORTING NON SPOOFED MAC ADDRESSES
	u_char *cp;
	int c;
	int gobble = 0;
	int mitm = 0;
	int arpscan = 0;
	int interactive = 0; //TODO menu based version
	int argcount =0;
	int ewaitflag = 0;
	int snifffilterflag = 0;
	int randmac;
	int nonspoofedmac;
	int k;
	int f;
	int t;
	char *p;
	char *b;
	long l;
	int n;
	
	phosts = 0; //number of hosts to use in portscan
	sniffer = 0;
	portl = 0;
	ng = 0;	
	
	if((gettimeofday(&inittime,NULL)) != 0){
		printf("Opps: gettimeofday error\n");
		exit(1);
	}
	
	signal(SIGTERM, cleanup);
	signal(SIGINT, cleanup);
	signal(SIGHUP, cleanup);

	set_rlimits(); //shrink core dump size
	printf("\nThe Gobbler (Alpha release 1.5) from networkpenetration.com\n");
	printf("-----------------------------------------------------------\n");

	opterr = 0;
	while((c=getopt(argc, argv, "adE:f:Fgi:Ik:p:P:mn:N:Q:sS:TvV")) != -1){
		switch(c){
			
			case 'a': 
				arpscan = 1;
				  argcount++;
				  break;
				  
			case 'd': dhcpdiscoverservice = 1;
				  argcount++;
				  break;

			case 'E': endwait = atoi(optarg);
				  ewaitflag = 1;
				  break;
				  
			case 'f': snifffilter = optarg; //TODO
				  snifffilterflag = 1;
				  break;
				  
			case 'F': fast = 1;
				  break;
				  
			case 'g': gobble = 1;
				  argcount++;
				  break;
			
			case 'i': device = optarg; //pcap device
				  break;
				  
			case 'v': v++;
				  break;

			case 'I': interactive = 1; //menu based version TODO
				  break;

			case 'k': srcprt = atoi(optarg);
				  srcportoption = 1;
				  break;

			case 'V': vll++;
				  break;
				  
			case 'p': portscan = 1;
				  argcount++;
				  hostname = optarg;
				  break;
			
			case 'P': portlist = optarg;
				  portl = 1;
				  break;				  

			case 'm': mitm = 1;
				  argcount++;
				  break;
	
			case 'n': phosts = atoi(optarg); 
				  if(phosts>MAXIPSOURCE){
					  printf("Opps: Number of source hosts has to be below %d\n\n", MAXIPSOURCE);
					  exit(1);
				  }
				  break;
				  
			case 'N': nongportscan = 1;
				  argcount++;
				  hostname = optarg;
				  break;
			
			case 'Q': randmac = 0;
				  nonspoofedmac = 0;
				  ng++;
				  if(!(cp = strrchr(optarg, '-'))){
					  printf("Opps: You need to specify a mac address\n\n");
					  exit(1);
				  }
				  *cp++ = 0;
				  
				  if(strncasecmp(cp, "R", sizeof(char)) == 0){
				  	//printf("u do rand rand rand, u do rand rand\n");
					randmac = 1;
				  }
				  else if(strncasecmp(cp, "N", sizeof(char)) == 0){
				  	//printf("non spoofed mac addr\n");
					nonspoofedmac = 1;
				  }
				  else {
					
					p = cp;
					//ba = cp;
					//printf("here\n");
					f =0;
						
					//check mac address
					while(((t = isxdigit(*p)) != 0)  && f<=12){
						//printf("hex %x\n",*p);
						
						p++;
						if((f == 1) || (f == 3) || (f == 5) || (f == 7) || (f == 9)){
							p++;
						}
						f++;
					}
					if((t != 0) || f<12){
						printf("Opps: Invalid mac address %s\n", cp);
						exit(1);
					}
					
					//else printf("dump mac\n");
					
					for(n = 0; n< ETH_ADDR_LEN; n++){
						//l = 0;
						l = strtol((char *)cp, &b, 16);
						if(b == (char *)cp || l <0 || l > 0xff){
							printf("Opps: strol error1\n");
							exit(1);
						}
						if(n < 5 && *b != ':'){
							printf("Opps: strol error2\n");
							exit(1);
						}
						//printf("l = %x\n", (u_char)l);
						mt.srcmac[n] = (u_char)l;
						cp = b + 1;
					}
											
				  }

				  if(randmac && nonspoofedmac){
					  printf("Opps: Please select either R/r or N/n\n\n");
					  exit(1);
				  }
				  if(randmac){
					  for(k=0;k<6;k++){
						if(k==0) mt.srcmac[k] = 0x0;
						else mt.srcmac[k] = libnet_get_prand(LIBNET_PR8);

						if(tag){
							if(k==4) mt.srcmac[k] = (u_int8_t)'N';
							if(k==5) mt.srcmac[k] = (u_int8_t)'P';
						}
					  }
					  if(v>2)printf("Src mac = %x:%x:%x:%x:%x:%x\n", mt.srcmac[0], mt.srcmac[1], mt.srcmac[2], mt.srcmac[3], mt.srcmac[4], mt.srcmac[5]);
				  }

				  if(nonspoofedmac){
					  
					  if(device == NULL){
						  printf("Opps: device = NULL\n\nYou need to select a interface and tagging (if required) before using -Q with a non spoofed mac address\nFor example -i eth0 -T -Q 1.2.3.4:n (NOT -Q1.2.3.4:n -i eth0 -T) (Need to fix, sorry)\n");
						  exit(1);
					  }
					  
					  e = eth_open(device);
					  if(e == NULL){
						  printf("Opps: eth_open error\n");
						  exit(1);
					  }
					  
					  if(eth_get(e, &ea->intf_link_addr.addr_eth) != 0){
						  printf("Opps: eth_get error\n");
						  exit(1);
					  }
					  
					  //verbose needs to be at start to show these src mac addresses
					  if(v>2)printf("src mac = %x:%x:%x:%x:%x:%x\n", ea->intf_link_addr.addr_data8[0],ea->intf_link_addr.addr_data8[1], ea->intf_link_addr.addr_data8[2],ea->intf_link_addr.addr_data8[3],ea->intf_link_addr.addr_data8[4],ea->intf_link_addr.addr_data8[5]);
					  eth_close(e);
					  
					  memcpy(&mt.srcmac, ea->intf_link_addr.addr_data8, sizeof(mt.srcmac));
					  if(tag){
						  mt.srcmac[4] = (u_int8_t)'N';
						  mt.srcmac[5] = (u_int8_t)'P';
					  }
				  
				  	  if(v>2)printf("Src mac = %x:%x:%x:%x:%x:%x\n", mt.srcmac[0], mt.srcmac[1], mt.srcmac[2], mt.srcmac[3], mt.srcmac[4], mt.srcmac[5]);
				  }
					
				  if(!inet_aton(optarg, &sa)){
					  printf("Opps: Invalid IP address %s\n\n",optarg);
					  exit(1);
				  }

				  mt.dhcptype = 0;
				  mt.transid = 0;
				  mt.serverip[0] = 0;
				  mt.serverip[1] = 0;
				  mt.serverip[2] = 0;
				  mt.serverip[3] = 0;
				  mt.ipaddress = sa.s_addr;
				  addll(mt);				  
				  break;
 
			case 's': sniffer = 1;
				  argcount++;
				  break;

			case 'T': tag = 1;
				  break;
				  
			case '?': usage(argv[0]);
				  
				  exit(0);

			default : usage(argv[0]);
				  exit(0);
		}
	}
	//check various args
	if((getuid()!=0)&&geteuid()!=0){
		printf("Opps: You need to be root\n\n");
		exit(1);
	}
	
	if(argcount > 1){
		printf("Opps: Please select only one scan option\n\n");
		exit(1);
	}
	
	if(v == EASTEREGG){
		egg();
		exit(0);
	}

	if(!argcount){
		usage(argv[0]);
	}

	if(portlist && ((!portscan) && (!nongportscan))){
		printf("Opps: port list is pointless without -p or -N\n\n");
		exit(1);
	}
	if(!portlist && portscan){
		printf("Opps: please select the ports you wish to scan with -P\n\n");
		exit(1);
	}

	
	if((nongportscan) && ((!ng) || (!portlist))){
		printf("Opps: please select a source IP address, source MAC address and port range\n\n");
		exit(1);
	}
	
	if(v > 3){
		printf("Opps: Too many -v's on command line\n\n");
		exit(1);
	}

	if(v && tag) printf("Tagging mac address with 4e:50\n");
	
	if(!ewaitflag)endwait = 5;
	
	if(dhcpdiscoverservice){
		dhcpdetected = 0; //init to 
		//startsniffer(DHCPMITMFILTER);
		startsniffer(NOFILTER);
		startlibnet();
		startdhcpdiscover();
	}
	
	if(gobble){
		//startsniffer(DHCPMITMFILTER);
		startsniffer(NOFILTER);
		startlibnet();
		startdhcpgobble();
	}
	
	if(arpscan){
		startlibnet();
		startsniffer(ARPSCANFILTER);
		startarpscan();
	}

	if(portscan){
		if(!phosts) phosts = 1;
		startlibnet();
		startsniffer(NOFILTER);
		startportscan(hostname);	
	}
	
	if(nongportscan){
		//if(phosts){
		//	printf("Opps: Only one host can be used in a non spoofed portscan (at the moment)\n");
		//	exit(1);
		//}
		startlibnet();
		startsniffer(NOFILTER);
		//startnonspoofed(hostname);
		//printf("TODO sorry\n");
		if(v>2)printf("Number of hosts: %d\n",ng);
		startportscan(hostname);
		//exit(1);
	}
	
	if(mitm){
		startlibnet();
		startsniffer(NOFILTER);
		startdhcpmitm();
	}
	
	if(sniffer){
		if(!snifffilterflag)startsniffer(NOFILTER);
		//TODO parse BPF filter from command line
	}

	for(;;) pause(); //everything handled by threads from now on;
}

void startsniffer(int filter)
{
	void thread_packhandle(int);
	void open_pcap(int);
	int i;
	
	tptr = calloc(MAXPACKHANDLER, sizeof(Thread));

	open_pcap(filter);

	for(i = 0; i < MAXPACKHANDLER; i++){
		thread_packhandle(i);
	}
}

void startlibnet(void)
{
	//initialise once 
	char errbuf[LIBNET_ERRBUF_SIZE];
	char errbuff[LIBNET_ERRBUF_SIZE];

	if((l = libnet_init(LIBNET_LINK, device, errbuf)) == NULL){
		printf("Opps: libnet_init error as %s\n", errbuf);
		exit(1);
	}
	
	if((q = libnet_init(LIBNET_LINK_ADV, device, errbuff)) == NULL){
		printf("Opps: libnet_init error as %s\n", errbuff);
		exit(1);
	}

	if(((libnet_seed_prand(l)) <0)){
		printf("Couldn't seed the random generator\n");
		exit(1);
	}
	
	if(((libnet_seed_prand(q)) <0)){
		printf("Couldn't seed the random generator\n");
		exit(1);
	}
}

void thread_packhandle(int i)
{
	void *packhandler(void *);
	if(pthread_create(&tptr[i].thread_tid, NULL, &packhandler, (void *) i) < 0){
		printf("Opps: pthread_create error\n");
		exit(1);
	}
}


void* packhandler(void *tnum)
{ 	
	void processpacket(int);
	void next_pcap(int *, int );
	int len;

	if(pthread_detach(pthread_self()) <0){
		printf("Opps: pthread_detach error\n");
		pthread_exit(&status);
	}

	if(v>2) printf("Packet handler started on thread(%ld)\n", pthread_self());
	for(;;){
		next_pcap(&len, (int)tnum);
		processpacket((int)tnum); //packet stored in tsd
	}	
	pthread_exit(&status);	

}

void next_pcap(int *len, int tnum)
{
	char *ptr;
	Packet *tsd; //thread data
	struct pcap_pkthdr hdr;
	static void getpacket_once(void);
	
	//create key
	if(pthread_once(&p_once, getpacket_once) !=0){
		printf("Opps: pthread_once error\n");
		exit(1);
	}

	//if no tsd make some space
	if((tsd = pthread_getspecific(p_key)) == NULL){
		tsd = calloc(1, sizeof(Packet)); //init to 0
		if(tsd == NULL){
			printf("Opps: Calloc error\n");
			exit(1);
		}
		if(pthread_setspecific(p_key, tsd) != 0){
			printf("Opps: pthread_setspecific error\n");
			exit(1);
		}
	}
	
	pthread_mutex_lock(&mlock);
	while((ptr = (char *)pcap_next(pd, &hdr)) == NULL);
	pthread_mutex_unlock(&mlock);
	
	memcpy(tsd->pkt, ptr, hdr.caplen);
	
	tsd->ppkt = tsd->pkt;
	tsd->caplen = hdr.caplen;
	*len = hdr.caplen;
	tptr[(int)tnum].thread_count++;
	
	if(v>1)	printf("<<<<Captured %d of %d bytes by thread %d (tid %ld) total for thread %ld>>>>\n",hdr.caplen, hdr.len, tnum, tptr[tnum].thread_tid, tptr[tnum].thread_count);
}

static void getpacket_once(void)
{
	//create key to tsd data
	if(pthread_key_create(&p_key, p_destructor) != 0){
		printf("Opps: pthread_key_create error\n");
		exit(1);
	}
}

static void p_destructor(void *ptr)
{
	free(ptr);
}

static void countaddresses_once(void)
{
	//count the number of IP addresses from the netmask :)

	unsigned char *nbytes;
        int temp, a;
        
	maskcount = 0;
        
        nbytes = (unsigned char *)&netmask;
        for(a=0; a<4; a++){
               	temp = (256 - (nbytes[a]));
                if(temp){
                	if(!maskcount){
                        	maskcount = temp;
                        }
                	else maskcount *= temp;
		}
          
	}
	//maskcount--;                                                                                                                        
        if(v>1)printf("IP Address count from netmask: %u\n", maskcount); //TODO  deducted 1 b4 here
	//addrcount = maskcount;
}

//possibly pass cmd to open_pcap to indicate what to sniff
void open_pcap(int filter) 
{
	static void countaddresses_once(void);
	char errbuf[PCAP_ERRBUF_SIZE],  str1[INET_ADDRSTRLEN],str2[INET_ADDRSTRLEN];
	struct bpf_program fcode; 
	char cmd[MAXLINE]; 
#if HAVE_BPF	
	int one;
#endif
	if(pthread_detach(pthread_self()) <0){
		printf("pthread_detach error\n");
		pthread_exit(0);
	}
	
	if(v>1) printf("Sniffer is being configured\n");
	if(v>1) printf("---------------------------\n");
	if(device == NULL){
		if((device = pcap_lookupdev(errbuf)) == NULL){
			printf("Opps: pcap_lookup error as %s\n", errbuf);
			exit(1);
		}
	}
	if(v>1) printf("Libpcap device: %s\n", device);

		//promisc = 1, to_ms = 1000 same as tcpdump
	if((pd = pcap_open_live(device, SNAPLEN, 1, 0, errbuf)) == NULL){
		printf("Opps: pcap_open_live error as %s\n", errbuf);
		exit(1);
	}
	
	
#if HAVE_BPF
	one = 1;
	if(ioctl(pcap_fileno(pd), BIOCIMMEDIATE, &one) <0){
		printf("Opps: ioctl error as %s\n",strerror(errno)); //may cause problems
		exit(1);
	}
#endif
	
	if(pcap_lookupnet(device, &localnet, &netmask, errbuf) <0){
		printf("Opps: pcap_lookupnet error as %s\n", errbuf);
		exit(1);
	}
	if(v>1){
		printf("Localnet: %s\nNetmask: %s\n", inet_ntop(AF_INET, &localnet, str1, sizeof(str1)), inet_ntop(AF_INET, &netmask, str2, sizeof(str2)));
	}
	pthread_once(&caddrlock, countaddresses_once);
	//filter = 0;// TODO
	if(filter){
		//if(filter == DHCPDETECTFILTER) snprintf(cmd, sizeof(cmd), DHCPDETECTSTRING, 68);
		if(filter == ARPSCANFILTER) snprintf(cmd, sizeof(cmd), ARPSCANSTRING);
		//if(filter == DHCPMITMFILTER) snprintf(cmd, sizeof(cmd), DHCPMITMSTRING, 67, 68);
	
		if(v > 1) printf("CMD = %s\n",cmd);
		if(pcap_compile(pd, &fcode, cmd, 0, netmask) <0){
			printf("Opps: pcap_compile error as %s\n", pcap_geterr(pd));
			exit(1);
		}
		if(pcap_setfilter(pd, &fcode) < 0){
			printf("Opps: pcap_setfiler error as %s\n", pcap_geterr(pd));
			exit(1);
		}
		//SIDE NOTE pcap_freecode(pf) should free the filter
	}

	if((datalink = pcap_datalink(pd)) < 0){
		printf("Opps: pcap_datalink errror as %s", pcap_geterr(pd));
		exit(1);
	}	

	if(v>1) printf("---------------------------\n");

	if(!v && sniffer)printf("\nSniffer Started (if u expect output use -s -v)\n\n");
	if(sniffer && v) printf("\nSniffer Started\n");

}


void processpacket(int tnum)
{
	//core function for decoding packets
	
	u_int16_t type, arpop;
	u_int8_t iptype, dhcptype, icmptype, tcptype;
	struct udp_ports udpports;
	Packet *tsd;

	u_int16_t handle_ETHERNET(int);
	u_int16_t handle_ARP(int);
	u_int8_t handle_ICMP(int);
	u_int8_t handle_DHCP(int);
	u_int8_t handle_IP(int);
	u_int8_t handle_TCP(int);
	
	struct udp_ports handle_UDP(int);
	int handle_ARPrequest(int);
	int handle_ARPreply(int);
	int handle_DHCPdiscover(int);
	int handle_DHCPoffer(int);
	int handle_DHCPrequest(int);
	int handle_DHCPdecline(int);
	int handle_DHCPack(int);
	int handle_DHCPnack(int);
	int handle_DHCPrelease(int);
	int handle_DHCPinform(int);
	int handle_ICMPECHOREQUEST(int);
	int handle_ICMPECHOREPLY(int);

	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	type = handle_ETHERNET(tnum);
	if(v>1)printf("\n");
	

	//recode as switch should be quicker than if else
	if(ntohs(type) == ETHERTYPE_IP){
		iptype = handle_IP(tnum);
		switch(iptype){
			case IPTYPE_TCP: tcptype = handle_TCP(tnum);
					 if(tcptype != 0){
						 printf("Opps: tcptype error\n");
						 exit(1);
					 }
					 goto END;
			
			case IPTYPE_UDP: udpports = handle_UDP(tnum);
					if(udpports.err == 1){
						printf("UDP packet error... packet dropped\n"); //goto end or someting
						goto END;
				
					}
					if((udpports.src == 67 || udpports.src == 68) && (udpports.dst == 67 || udpports.dst == 68)){
						dhcptype = handle_DHCP(tnum);
						if(dhcptype == 255){
							printf("DHCP packet error... packet dropped\n");
							goto END;
						}
						switch(dhcptype){
							case DHCPDISCOVER: if(handle_DHCPdiscover(tnum) !=0){
										   printf("Opps: dhcpdiscover error\n");
									   }
									   goto END;
	
							case DHCPOFFER:	if(handle_DHCPoffer(tnum) != 0){
										printf("Opps: dhcpoffer error\n");
									}
									goto END;
	
							case DHCPREQUEST: if(handle_DHCPrequest(tnum) != 0){
										  printf("Opps: dhcprequest error\n");
									  }
									  goto END;

							case DHCPDECLINE: if(handle_DHCPdecline(tnum) != 0){
										  printf("Opps: dhcpdecline error\n");
									  }
									  goto END;

							case DHCPACK:	if(handle_DHCPack(tnum) !=0){
										printf("Opps: dhcpack error\n");
									}
									  goto END;
	
							case DHCPNACK: 	if(handle_DHCPnack(tnum) !=0){
									       printf("Opps: dhcpnack error\n");
								       	}
									goto END;

							case DHCPRELEASE: if(handle_DHCPrelease(tnum) !=0){
										  printf("Opps: dhcprelease error\n");
									  }
									  goto END;

							case DHCPINFORM: if(handle_DHCPinform(tnum) != 0){
										 printf("Opps: dhcpinform error\n");
									 }
									 goto END;

							default: printf("Unknown DHCP type %d\n",dhcptype);
								 goto END;
						}
						goto END;
					}
				
					else if((udpports.src == 53) || (udpports.dst == 53)){
						if(v)printf("DNS packet\n");
						goto END;
					}
			
					else {
						//printf("Unknown UDP packet type\n");
						goto END;
					}
			
			case IPTYPE_ICMP: icmptype = handle_ICMP(tnum);
				  	switch(icmptype){
						case ICMP_ECHOREPLY: if(handle_ICMPECHOREPLY(tnum) !=0){
									     printf("Opps: icmp echo reply error\n");
								     }
								     goto END;

						case ICMP_UNREACH: printf("icmp unreach\n");
								   goto END;

						case ICMP_SOURCEQUENCH: printf("icmp source quence\n");
									goto END;

						case ICMP_REDIRECT: printf("icmp redirect\n");
								    goto END;

						case ICMP_ECHO: if(handle_ICMPECHOREQUEST(tnum) !=0){
									printf("Opps: icmp echo request error\n");
								}
								goto END;

						case ICMP_TIMEEXCEED: printf("icmp time exceed\n");
								      goto END;

						case ICMP_PARAMPROB: printf("icmp param prob\n");
								     goto END;

						case ICMP_TIMESTAMP: printf("icmp time stamp\n");
								     goto END;

						case ICMP_TIMESTAMPREPLY: printf("icmp time stamp reply\n");
									  goto END;
	
						case ICMP_INFOREQUEST: printf("icmp info request\n");
								       goto END;

						case ICMP_INFOREPLY: printf("icmp info reply\n");
								     goto END;

						case 255: printf("Opps: ICMP packet decode error\n");
							  goto END;
							  
						default: printf("icmp unknown type 0x%x\n", icmptype);
							 goto END;
					  }
			default: if(v>1) printf("Unknown IP type 0x%x\n",(int)iptype);
					 goto END;
		}
	}
	
	if(ntohs(type) == ETHERTYPE_ARP){
	 	arpop = handle_ARP(tnum);
		switch(arpop){
			case ARPOP_REQUEST: 	/*request to resolve address */
						handle_ARPrequest(tnum);
						if(v)printf("\n");
						goto END;
	       	
			case ARPOP_REPLY: 	/* response to previous request */
						if(handle_ARPreply(tnum) != 0){
							printf("Opps: handle_ARPreply error\n");
						}
						if(v)printf("\n");
						goto END;
		
			case ARPOP_REVREQUEST:
						printf(" ARP request protocol\n");/* request protocol address given hardware */
						goto END;
		
			case ARPOP_REVREPLY:
						printf(" ARP response protocol\n");/* response giving protocol address */
						goto END;
			
			case ARPOP_INVREQUEST:
						printf(" ARP request identify peer\n");/* request to identify peer */
						goto END;
		
			case ARPOP_INVREPLY:
						printf(" ARP response identifying peer\n");/* response identifying peer */
						goto END;
		
			default:		if(v>1) printf(" Unknown ARP Optype 0x%x\n",(int)arpop);
						goto END;
		}
	}
		
	if(ntohs(type) == ETHERTYPE_REVARP){
		if(v>1)printf("Decode Reverse ARP\n");
		goto END;
	}
	
	END:
	//end of packet gap
	if(v==2)printf("\n");
}


u_int16_t handle_ETHERNET(int tnum)
{

	struct ether_header *eptr;
		Packet *tsd;

	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	eptr = (struct ether_header *) tsd->pkt;

	if(v>1)printf("ETHER src: %s" ,ether_ntoa(eptr->ether_shost));
      	if(v>1)printf(" dst: %s " ,ether_ntoa(eptr->ether_dhost));
	
	if (ntohs (eptr->ether_type) == ETHERTYPE_IP){
	if(v>1)	printf("Type H:0x%x D:%d (IP)", ntohs(eptr->ether_type), ntohs(eptr->ether_type));
	}
	
	else  if (ntohs (eptr->ether_type) == ETHERTYPE_ARP){
	if(v>1)	printf("Type H:0x%x D:%d (ARP)", ntohs(eptr->ether_type), ntohs(eptr->ether_type));
	}
	
	else  if (ntohs (eptr->ether_type) == ETHERTYPE_REVARP){
	if(v>1)	printf("Type H:0x%x D:%d (RARP)",ntohs(eptr->ether_type), ntohs(eptr->ether_type));
	}
	
	else {
	if(v>1)	printf("Type H:0x%x D:%d (?)",ntohs(eptr->ether_type), ntohs(eptr->ether_type));
	}
	
	return(eptr->ether_type);
}

u_int16_t handle_ARP(int tnum)
{
	struct my_arp *arp;
	struct ether_header *eptr;
	u_int length = 0;
	Packet *tsd;
	unsigned char *sbytes, *dbytes;
	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	eptr = (struct ether_header *) tsd->pkt;
	
	sbytes = (unsigned char *)&(eptr->ether_shost);
	dbytes = (unsigned char *)&(eptr->ether_dhost);

	arp = (struct my_arp*)(tsd->pkt + sizeof(struct ether_header));
	length -= sizeof(struct ether_header);

	//check length of packet
	if(length < sizeof(struct my_arp)){
		if(v>1)printf("Opps: Truncated ARP packet %d.... packet dropped\n", length);
		drop++;
		return(-1);//255 might have problems
	}
	
	if(v==1)printf("%x:%x:%x:%x:%x:%x -> %x:%x:%x:%x:%x:%x ARP Opcode: %x ", sbytes[0], sbytes[1], sbytes[2], sbytes[3], sbytes[4], sbytes[5], dbytes[0], dbytes[1], dbytes[2], dbytes[3], dbytes[4], dbytes[5], ntohs(arp->arp_opcode));
	if(v>1)printf("ARP HWtype: %d, Proto: %d, Hsize: %d, Psize: %d Opcode: %d", ntohs(arp->arp_type), arp->arp_proto, arp->arp_hsize, arp->arp_psize, ntohs(arp->arp_opcode));

	return(ntohs(arp->arp_opcode));
}

int handle_ARPrequest(int tnum)
{
	unsigned int convert32(char *, int, int, int , int); 
	int startARPreply(unsigned int);
	Packet *tsd; 
	struct my_arpops *arpo;
	unsigned int rip;
	PMT p_curr;

	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	arpo = (struct my_arpops*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_arp));

	if(v)printf(" ARP request for %d.%d.%d.%d's MAC addr from %d.%d.%d.%d", arpo->ar_tpa[0], arpo->ar_tpa[1], arpo->ar_tpa[2], arpo->ar_tpa[3], arpo->ar_spa[0], arpo->ar_spa[1], arpo->ar_spa[2], arpo->ar_spa[3]); //target MAC addr

	rip = convert32(arpo->ar_tpa, 0, 1,2,3);
	
	p_curr = mtpoint;
	if(p_curr == NULL){
		//linked list empty so no need to reply
		return(0);
	}
	
	while((p_curr != NULL) && (p_curr->ipaddress != ntohl(rip))){
		//printf("no match MAC loop\n");
		p_curr = (PMT) p_curr->nextmt;
	}
		
	if(p_curr == NULL){
		//printf("no match found ARP request discarded\n");
		return(0);
	}
	else{
		if(v)printf("MAC compare passed sending arp reply\n");
		if(startARPreply(rip) != 0){
			printf("Opps: startarpreply error\n");
			exit(1);
		}
		return(0);
	}

}

int handle_ARPreply(int tnum)
{
	unsigned int convert32(char *, int, int, int, int);
	Packet *tsd;
	struct my_arpops *arpo; 
	PMT p_curr;
		
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	arpo = (struct my_arpops*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_arp));
	
	if(arpscanstarted) {
		printf("%d.%d.%d.%d has %x:%x:%x:%x:%x:%x", arpo->ar_spa[0], arpo->ar_spa[1], arpo->ar_spa[2], arpo->ar_spa[3], arpo->ar_sha[0], arpo->ar_sha[1], arpo->ar_sha[2], arpo->ar_sha[3], arpo->ar_sha[4], arpo->ar_sha[5]);
		arprecvcount++;
	}
	if(v) printf(" ARP reply from %d.%d.%d.%d to %d.%d.%d.%d",arpo->ar_spa[0], arpo->ar_spa[1], arpo->ar_spa[2], arpo->ar_spa[3], arpo->ar_tpa[0], arpo->ar_tpa[1], arpo->ar_tpa[2], arpo->ar_tpa[3]); //src IP to dst ip
	if(arpscanstarted){
		printf("\n");
		return(0);
	}
	if(!portscanstarted){
		p_curr = mtpoint;
		if(p_curr == NULL){
			//linked list empty
			return(0);
		}
	
		while((p_curr != NULL)  && (p_curr->srcmac[0] != arpo->ar_tha[0]) && (p_curr->srcmac[1] != arpo->ar_tha[1]) && (p_curr->srcmac[2] != arpo->ar_tha[2]) && (p_curr->srcmac[3] != arpo->ar_tha[3]) && (p_curr->srcmac[4] != arpo->ar_tha[4]) && (p_curr->srcmac[5] != arpo->ar_tha[5])){
			//printf("no match MAC loop\n");
			p_curr = (PMT) p_curr->nextmt;
		}

		if(p_curr == NULL){
			printf("no match found ARP reply discarded\n");
			return(0);
		}
		else{
			if(v)printf("\nMAC compare passed adding entry into arp cache\n");
			if((arpo->ar_spa[0] == 0) && (arpo->ar_spa[1] == 0) && (arpo->ar_spa[2] == 0) && (arpo->ar_spa[3] == 0))			{
				printf("Opps: arp source protocol addr error\n");
				return(0);
			}
			if((arpo->ar_sha[0] == 0) && (arpo->ar_sha[1] == 0) && (arpo->ar_sha[2] == 0) && (arpo->ar_sha[3] == 0) && (arpo->ar_sha[4] == 0) && (arpo->ar_sha[5] == 0)){
				printf("Opps: arp source hardware addr error\n");
				return(0);
			}

			if(addmacip(convert32(arpo->ar_spa, 0,1,2,3), arpo->ar_sha)!=0){
				printf("Opps: addmacip error\n");
				exit(1);
			}
			printf("arp cache updated\n");
			arpcache = 1;
			return(0);
		}
		return(0);
	}
	return(0);
}

u_int8_t handle_ICMP(int tnum)
{
	Packet *tsd;
	struct my_icmp *icmp;
	u_int length = 0;
	u_int8_t type;
	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	icmp = (struct my_icmp*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip));
		length -= (sizeof(struct ether_header) + sizeof(struct my_ip));
	if(length <sizeof(struct my_icmp)){
		if(v>1)printf("Opps: Truncated ICMP %d.... packet dropped\n", length);
		drop++;
		return(-1);
	}

	type = icmp->type;
	//check checksum b4 returning
	
	return(type);
}
	
int handle_ICMPECHOREPLY(int tnum)
{
	Packet *tsd;
	struct my_icmpecho *iecho;
	struct my_ip *ip;
	u_int length = 0;
	u_char *d, *s;
	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}
	ip = (struct my_ip*)(tsd->pkt + sizeof(struct ether_header));

	s = (unsigned char *)&(ip->ip_src);
	d = (unsigned char *)&(ip->ip_dst);

	iecho = (struct my_icmpecho*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_icmp));
	length -= (sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_icmp));
	if(length <sizeof(struct my_icmpecho)){
		if(v>1)printf("Opps: Truncated ICMP %d.... packet dropped\n", length);
		drop++;
		return(-1);
	}
	//rip out ip addrs for full packet detail
	if(v)printf("%d.%d.%d.%d -> %d.%d.%d.%d echo reply id: %d seq: %d\n", s[0], s[1], s[2], s[3], d[0], d[1], d[2], d[3], iecho->id, iecho->seq);
	return(0);
}

int handle_ICMPECHOREQUEST(int tnum)
{
	Packet *tsd;
	struct my_icmpecho *iecho;
	struct my_ip *ip;
	u_int length = 0;
	PMT p_curr;
	u_char *d, *s;

	int startICMPECHOREPLY(void);
	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}
	
	ip = (struct my_ip*)(tsd->pkt + sizeof(struct ether_header));

	s = (unsigned char *)&(ip->ip_src);
	d = (unsigned char *)&(ip->ip_dst);

	iecho = (struct my_icmpecho*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_icmp));
	length -= (sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_icmp));
	if(length <sizeof(struct my_icmpecho)){
		if(v>1)printf("Opps: Truncated ICMP %d.... packet dropped\n", length);
		drop++;
		return(-1);
	}
	
	if(v)printf("%d.%d.%d.%d -> %d.%d.%d.%d echo request id: %d seq: %d\n", s[0], s[1], s[2], s[3], d[0], d[1], d[2], d[3], iecho->id, iecho->seq);

	
	p_curr = mtpoint; //set p_curr to top of ll

	if(p_curr == NULL){
		//linked list empty so no need to reply
		return(0);
	}
	
	
	while((p_curr != NULL) && (p_curr->ipaddress != ip->ip_dst)){
		//printf("no match IP loop\n");
		p_curr = (PMT) p_curr->nextmt;
	}
		
	if(p_curr == NULL){
		//printf("no match found echo request discarded\n");
		return(0);
	}
	else{
		printf("Echo request for %d.%d.%d.%d from %d.%d.%d.%d sending echo reply\n", d[0],d[1],d[2],d[3],s[0],s[1],s[2],s[3]); //still need to sort mac lookup + decide if ip local or if gateway needed
		if((startICMPECHOREPLY()) != 0){
			printf("Opps: start icmp echo reply error\n");
			exit(1);
		}
		return(0);
	}
	return(0);
}



u_int8_t handle_IP(int tnum)
{
	struct my_ip* ip;
	u_int length = 0, hlen, off, version;
	int iplen;
	Packet *tsd;
	unsigned char *sbytes, *dbytes;
	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

		ip = (struct my_ip*)(tsd->pkt + sizeof(struct ether_header));
length -= sizeof(struct ether_header);

	//check length of packet
	if(length < sizeof(struct my_ip)){
		if(v>1)printf("Opps: Truncated IP %d.... packet dropped\n", length);
		drop++;
		return(-1);//255 might have problems
	}

	iplen = ntohs(ip->ip_len);
	hlen = IP_HL(ip);
	version = IP_V(ip);

	if(version != 0x4){
		if(v>1)printf("Opps: IPv%x reported.... only IPv4 supported.... packet dropped\n",version);
		drop++;
		return(-1);
	}
	
	if(hlen<5){
		if(v>1)printf("Opps: hlen: %d .... too small.... packet dropped\n",hlen);
		drop++;
		return(-1);
	}
	if(length < iplen){
		if(v>1)printf("Opps: Truncated IP - %d bytes missing.... packet dropped\n", iplen - length);
		drop++;
		return(-1);
	}

	off = ntohs(ip->ip_off);
	if((off & 0x1fff) == 0){
			sbytes = (unsigned char *)&(ip->ip_src);
		dbytes = (unsigned char *)&(ip->ip_dst);
	if(v>1)printf("IP Src: %d.%d.%d.%d IP Dst: %d.%d.%d.%d Hlen: %d Ver: %d Len: %d ID: %d TTL: %d chksum: %d proto: %d\n", sbytes[0], sbytes[1], sbytes[2], sbytes[3], dbytes[0], dbytes[1], dbytes[2], dbytes[3], hlen, version, iplen, ip->ip_id, ip->ip_ttl, ip->ip_sum, ip->ip_p);
	}
	return(ip->ip_p);
}

struct udp_ports handle_UDP(tnum)
{
	const struct my_ip *ip;
	const struct my_udp *udp;
	struct udp_ports udpports;
	unsigned char *sbytes, *dbytes;
	u_int length = 0;
	Packet *tsd;

	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	ip = (struct my_ip*)(tsd->pkt + sizeof(struct ether_header)); 
 
	sbytes = (unsigned char *)&(ip->ip_src);
	dbytes = (unsigned char *)&(ip->ip_dst);

	udp = (struct my_udp*)(tsd->pkt +sizeof(struct ether_header) + sizeof(struct my_ip));
	length -= (sizeof(struct ether_header) + sizeof(struct my_ip));
	
	udpports.src = ntohs(udp->src_port);
	udpports.dst = ntohs(udp->dst_port);
	udpports.err = 0;
	if(length < sizeof(struct my_udp)){
		if(v)printf("Opps: Truncated UDP length: %d\n", length);
		drop++;
		udpports.err = 1;
		return(udpports);
	}
	if(v==1)printf("\n%d.%d.%d.%d -> %d.%d.%d.%d UDP Src port: %d Dst port: %d ", sbytes[0], sbytes[1], sbytes[2], sbytes[3], dbytes[0], dbytes[1], dbytes[2], dbytes[3], ntohs(udp->src_port), ntohs(udp->dst_port));
	if(v>1)printf("UDP Src port: %d Dst port: %d, ", ntohs(udp->src_port), ntohs(udp->dst_port));
	return(udpports);
}
	
u_int8_t handle_TCP(int tnum)
{
	struct my_tcp *tcp;
	struct my_ip *ip;
	unsigned char *sbytes, *dbytes;
	u_int8_t checkip(int);
	u_int length = 0;
	u_int syn, ack, fin, rst;
	Packet *tsd;


	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

 	ip = (struct my_ip*)(tsd->pkt + sizeof(struct ether_header)); 

	sbytes = (unsigned char *)&(ip->ip_src);
	dbytes = (unsigned char *)&(ip->ip_dst);
	
	tcp = (struct my_tcp*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip));
	length -= (sizeof(struct ether_header) + sizeof(struct my_ip));

	if(length < sizeof(struct my_tcp)){
		if(v)printf("Opps: Truncated TCP length: %d\n",length);
		drop++;
		return(0);
	}

	if((tcp->th_flags & TH_SYN) >> 1 ) {
		syn = 1;
	}
	else syn = 0;
	
	if((tcp->th_flags & TH_ACK) >>1) {
		ack = 1;
	}
	else ack = 0;
	
	if((tcp->th_flags & TH_FIN) >>1){
		fin = 1;
	}
	else fin = 0;
	
	if((tcp->th_flags & TH_RST) >>1) {
		rst = 1;
	}
	else rst = 0;
	
	if(v==1)printf("%d.%d.%d.%d -> %d.%d.%d.%d Src port: %d Dst port: %d Seq: %u Ack: %u Syn: %d Ack: %d fin: %d rst: %d\n", sbytes[0], sbytes[1], sbytes[2], sbytes[3], dbytes[0], dbytes[1], dbytes[2], dbytes[3], ntohs(tcp->th_sport), ntohs(tcp->th_dport), ntohl(tcp->th_seq), ntohl(tcp->th_ack), syn, ack, fin, rst);
	if(v>1)printf("TCP ");
	if(v>1)printf("Src port: %d Dst port: %d Seq: %u Ack: %u Syn: %d Ack: %d fin: %d rst: %d\n", ntohs(tcp->th_sport), ntohs(tcp->th_dport), ntohl(tcp->th_seq), ntohl(tcp->th_ack), syn, ack, fin, rst);
	if(syn && ack && (portscan || nongportscan)){
		if(checkip(tnum) != 0){
			printf("Opps: checkip returned error\n");
		}
		//send reset to keep connections to a minimum on target host
	}
	
	return(0);
}

u_int8_t checkip(int tnum)
{
	u_int8_t sendrst(int tnum);
	Packet *tsd;
	struct my_ip *ip;
	struct my_tcp *tcp;
	u_char *srcip, *dstip, *hname;
	struct in_addr host;
	int i;
	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	ip = (struct my_ip*)(tsd->pkt + sizeof(struct ether_header));
	tcp = (struct my_tcp*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip));
	srcip = (u_char *)&(ip->ip_src);
	dstip = (u_char *)&(ip->ip_dst);
	
	if(!inet_aton(hostname, &host)){
		printf("Opps: invalid ip\n");
		return(-1);
	}
	
	hname = (u_char *)&(host.s_addr);

	for(i=0;i<4;i++){
		if(srcip[i] != hname[i]){
			if(v>2)printf("Opps: syn ack doesn;t match target srcip %d target %d\n", srcip[i], hname[i]);
			return(0);
		}
	}
	
	if(v)printf("%d.%d.%d.%d %d port open (%d.%d.%d.%d)\n", srcip[0], srcip[1], srcip[2], srcip[3], ntohs(tcp->th_sport), dstip[0], dstip[1], dstip[2], dstip[3]);
	if(addport(ntohs(tcp->th_sport), srcip, dstip) != 0){
		printf("Opps: port add failed\n");
	}
	if(vll)printportll();
	if(sendrst(tnum) != 0){
		printf("Opps: sendrst failed\n");
	}
	return(0);
}

	
u_int8_t handle_DHCP(int tnum)
{
	struct my_dhcp *dhcp;
	struct my_ip *ip;
	struct ether_header *eptr;
	unsigned char *bytes, *srcip, *yaddr, *macsrc;
	unsigned int convert32(char *ptr, int anum, int bnum, int cnum, int dnum);
	unsigned int convert16(char *ptr, int anum, int bnum);
	u_int8_t subneta = 0, subnetb = 0, subnetc = 0, subnetd = 0, gatewaya = 0, gatewayb = 0, gatewayc = 0, gatewayd = 0, dnsa = 0, dnsb = 0, dnsc = 0, dnsd = 0;
	u_int length = 0;
	Packet *tsd;
	int len, t, loop, padcount, type;
	char *pbuf = dhcp->buf; //ponter to buffer for convert
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}
t = 0;
	padcount = 0;
	type = 0;
	
	eptr = (struct ether_header *)&(tsd->pkt);
	macsrc = (unsigned char *)&(eptr->ether_shost);
		
	ip = (struct my_ip*)(tsd->pkt + sizeof(struct ether_header));
	srcip = (unsigned char *)&(ip->ip_src);

	dhcp = (struct my_dhcp*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_udp));
	length -= (sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_udp));

	if(length < sizeof(struct my_dhcp)){
		printf("Opps: Truncated DHCP packet length: %d\n",length);
		drop++;
		return(-1); //255 but who cares were only returning the dhcp packet type
	}
	if(dhcp->opcode == 1){
		if(v>1)printf("DHCP opcode = 1 boot request, ");
	}
	else if(dhcp->opcode == 2){
		if(v>1)printf("DHCP opcode = 2 boot reply, ");
	}
	else {
		printf("Opps: Unknown opcode type\n");
		drop++;
		return(-1);
	}
	
	if(dhcp->type == 1){
		if(v>1)printf("H_type = 10mb Enet, ");
	}
	else {
		if(v)printf("Opps: Unsupported hardware type 0x%x\n", dhcp->type);
		drop++;
		exit(1);
	}

	if(v>1) printf("Hops %d, ", dhcp->hops);
	if(v>1) printf("Transaction ID 0x%x, ", ntohl(dhcp->trans_id));
	if(v>1) printf("Elapsed time %d, ", dhcp->t_elapsed);
	
	if(dhcp->flags == 0x80){
		if(v>1)printf("flags 0x%x (bcast), ", dhcp->flags);
	}
	else{
		if(v>1) printf("flags 0x%x, ",dhcp->flags);
	}

	bytes = (unsigned char *)&(dhcp->cliaddr);
	if(v>1)printf("cliaddr %d.%d.%d.%d, ", bytes[0], bytes[1], bytes[2], bytes[3]);
	
	yaddr = (unsigned char *)&(dhcp->yaddr);
	if(v>1)printf("your cliaddr %d.%d.%d.%d, ", yaddr[0], yaddr[1], yaddr[2], yaddr[3]);
	
	bytes = (unsigned char *)&(dhcp->siaddr);
	if(v>1)printf("next dhcp server %d.%d.%d.%d, ", bytes[0], bytes[1], bytes[2], bytes[3]);
	
	bytes = (unsigned char *)&(dhcp->giaddr);
	if(v>1)printf("gateway ip %d.%d.%d.%d, ", bytes[0], bytes[1], bytes[2], bytes[3]);

	if(v>1)printf("cli hw addr %x:%x:%x:%x:%x:%x, ",  dhcp->clihwaddr[0], dhcp->clihwaddr[1], dhcp->clihwaddr[2], dhcp->clihwaddr[3], dhcp->clihwaddr[4], dhcp->clihwaddr[5]);
	
	//random gap.... guessing for larger mac addr without checkin the rfc
	//only enet MAC allowed at the moment
	
	if(v>2)printf("serv hostname %s,", dhcp->sname);
	if(v>2)printf("bootfile %s, ",dhcp->bname);
	
	
	bytes = (unsigned char *)&(dhcp->magic);
	if((bytes[0] == 0x63) && (bytes[1] == 0x82) && (bytes[2] == 0x53) &&(bytes[3] == 0x63)){
		if(v>2)printf("magic cookie %x.%x.%x.%x ",bytes[0], bytes[1], bytes[2], bytes[3]); //problems
	}
	else {
		printf("Opps: invalid DHCP magic cookie %x.%x.%x.%x should be 63.83.53.63 packet dropped\n",bytes[0], bytes[1], bytes[2], bytes[3]);
		drop++;
		return(-1);
		//return error
	}
	
	//start of misc options
	while(t<length){
		len = 0;
	 	switch (dhcp->buf[t]) {
			//start of switch for option tag
			//255 different tags.... not all supported

			case 1: //subnet address
				len = dhcp->buf[t+1];
				subneta = dhcp->buf[t+2];
      				subnetb = dhcp->buf[t+3];
      				subnetc = dhcp->buf[t+4];
      				subnetd = dhcp->buf[t+5];
      				if(v>1){
					printf("Subnet Mask: ");
	      				for(loop = 0; loop <len; loop++){
      						printf("%d ", (u_int8_t)dhcp->buf[t+loop+2]);
      					}
					
					printf(", ");
				}
				t = t+len+2;
      				break;
				
				
      			case 3: //router option (default gateway)
      				len = dhcp->buf[t+1];
      				gatewaya = dhcp->buf[t+2];
      			       	gatewayb = dhcp->buf[t+3];
      			       	gatewayc = dhcp->buf[t+4];
      			       	gatewayd = dhcp->buf[t+5];
      				if(v>1) printf("Router / gateway: %d.%d.%d.%d, ",(u_int8_t)dhcp->buf[t+2], (u_int8_t)dhcp->buf[t+3], (u_int8_t)dhcp->buf[t+4], (u_int8_t)dhcp->buf[t+5]);
      				t = t+len+2;
      				if(dhcp->buf[t] == -1){
      				 	t++; //end of list
      				}
      				
				else {
					if(v>2)printf("Opps: possible end of list missing, rest of packet may be jibberish, ");
                                }
                                break;
                                                                                 
                        case 6: //domain name server
                              	len = dhcp->buf[t+1];
                              	dnsa = dhcp->buf[t+2];
                              	dnsb = dhcp->buf[t+3];
                              	dnsc = dhcp->buf[t+4];
                              	dnsd = dhcp->buf[t+5];
                              	//still need to sort 2nd dns server
                              	if(v>1) {
					printf("Domain name server IP: ");
	                             	for(loop = 0; loop <len; loop++){
						printf("%d ", (u_int8_t)dhcp->buf[t+loop+2]);
					}
					printf(", ");
				}
				t = t+len+2;
				if(dhcp->buf[t] == -1){
					t++; //end of list
				}
				else {
					if(v>2)printf("Opps: possible end of list missing, rest of packet may be jibberish ");
				}
				break;
																														 
			case 12: //hostname
		        	len = dhcp->buf[t+1];
			        if(v>1){
					printf("Hostname: ");
					for(loop = 0; loop <len; loop++){
						printf("%c",(char)dhcp->buf[t+loop+2]);
					}
					printf(", ");
				}
				t = t+len+2;
				break;
			
			case 50://request IP address
				len = dhcp->buf[t+1];
		                //reqipa = convert8(heada->buf, (t+2));
				//reqipb = convert8(heada->buf, (t+3));
			        //reqipc = convert8(heada->buf, (t+4));
				//reqipd = convert8(heada->buf, (t+5));
			        if(v>1)printf("Request IP address: %d.%d.%d.%d, ",(u_int8_t)dhcp->buf[t+2], (u_int8_t)dhcp->buf[t+3], (u_int8_t)dhcp->buf[t+4], (u_int8_t)dhcp->buf[t+5]);
				t = t+len+2;
				if(dhcp->buf[t] == -1){
					t++; //end of list 0xff
				}
				else {
					if(v>2) printf("Opps: possible end of list missing, rest of the packet may be jibberish, ");
				}
				break;
			
			case 51: //IP address lease time
				len = dhcp->buf[t+1];
			        //leasea = convert8(heada->buf, (t+2));
				//leaseb = convert8(heada->buf, (t+3));
				//leasec = convert8(heada->buf, (t+4));
				//leased = convert8(heada->buf, (t+5));
				if(v>1) printf("IP address lease time: ");
				if(len == 4){
					if(v>1)printf("%d secs", (u_int32_t)convert32(pbuf, (t+2), (t+2+1), (t+2+2), (t+2+3)));
				}
				if(v>1)printf(", ");
				t = t+len+2;
				break;
											  
			 case 53: //Message Type
				len = dhcp->buf[t+1];
				if(v>1) printf("TYPE: %d ", dhcp->buf[t+len+1]);
				if((dhcp->buf[t+len+1]) == 1){
					if(v>1)printf("DHCP Discover, ");
					t = t+len+2;
					type = DHCPDISCOVER;
					break;
				}
				else if((dhcp->buf[t+len+1]) == 2){
					if(v>1)printf("DHCP Offer, ");
					t = t+len+2;
					type = DHCPOFFER;
					break;
				}
				else if((dhcp->buf[t+len+1]) == 3){
					if(v>1)printf("DHCP Request, ");
					t = t+len+2;
					type = DHCPREQUEST;
					break;
				}
				
				else if((dhcp->buf[t+len+1]) == 4){
					if(v>1)printf("DHCP Decline, ");
					t = t+len+2;
					type = DHCPDECLINE;
					break;
				}
				else if((dhcp->buf[t+len+1]) == 5){
					if(v>1)printf("DHCP Ack, ");
					t = t+len+2;
					type = DHCPACK;
					break;
				}
				
				else if((dhcp->buf[t+len+1]) == 6){
					if(v>1)printf("DHCP Nack, ");
					t = t+len+2;
					type = DHCPNACK;
					break;
				}
				
				else if((dhcp->buf[t+len+1]) == 7){
					if(v>1)printf("DHCP Release, ");
					t = t+len+2;
					type = DHCPRELEASE;
					break;
				}
				
				else if((dhcp->buf[t+len+1]) == 8){
					if(v>1)printf("DHCP Inform, ");
					t = t+len+2;
					type = DHCPINFORM;
					break;
				}

				break; //shouldn't reach here
			
		   
			   case 54: //server IP
				len = dhcp->buf[t+1];
				if(v>1)printf("Server IP: ");
				for(loop = 0; loop <len; loop++){
					if(v>1)printf("%d ",(u_int8_t)dhcp->buf[t+loop+2]);
				}
				if(v>1)printf(", ");
				t = t+len+2;
				if(dhcp->buf[t] == -1){
					//if(verbose) printf("End of Server IP parameter list\n");
					t++;
				}
				else {
					if(v>2) printf("Opps: possible end of list missing, rest of the packet may be jibberish, ");
				}
				
				break;
		
			 case 55: //request list
				len = dhcp->buf[t+1];
				if(v>1)printf("Request parameters list: ");
				for(loop = 0; loop <len; loop++){
					if((dhcp->buf[t+loop+2]) == 1){
						if(v>1)printf("subnet_mask ");
					}
				
					else if((dhcp->buf[t+loop+2]) == 2){
						if(v>1)printf("time_offset ");
					}
				
					else if((dhcp->buf[t+loop+2]) == 3){
						if(v>1)printf("router ");
					}
					
					else if((dhcp->buf[t+loop+2]) == 6){
						if(v>1)printf("domain_srv ");
					}
					
					else if((dhcp->buf[t+loop+2]) == 12){
						if(v>1)printf("hostname ");
					}
					
					else if((dhcp->buf[t+loop+2]) == 15){
						if(v>1)printf("domain_name ");
					}
					
					else if((dhcp->buf[t+loop+2]) == 28){
						if(v>1)printf("bcast_addr ");
					}
					
					else {
						if(v>1)printf("unknown 0x%x ",dhcp->buf[t+loop+2]);
					}
					
				}
				if(v>1)printf(", ");
				t = t+len+2;
				if(dhcp->buf[t] == -1){
					t++; //end of list
				}
				else {
					if(v>2)printf("Opps: possible end of list missing (rest of packet may be jibberish), ");
				}
				break;
		
			 case 57: //MAX DCHP message size
				len = dhcp->buf[t+1];
				if(v>1)printf("Max DHCP message size: %d\n", convert16(pbuf, (t+2), (t+3)));
				t = t+len+2;
				break;

			 case 58: //renewal (T1) time value
				len = dhcp->buf[t+1];
				if(v>1)printf("Renewal (T1) time: ");
				//renewala = convert8(heada->buf, (t+2));
                                //renewalb = convert8(heada->buf, (t+3));
				//renewalc = convert8(heada->buf, (t+4));
				//renewald = convert8(heada->buf, (t+5));
				if(len == 4){
					if(v>1)printf("%u secs", (u_int32_t)convert32(pbuf, (t+2), (t+3), (t+4), (t+5)));
				}
				if(v>1)printf(", ");
				t = t+len+2;
				break;
			 
			 case 59: //Rebinding (T2) time value
				len = dhcp->buf[t+1];
			        //rebinda = convert8(heada->buf, (t+2));
				//rebindb = convert8(heada->buf, (t+3));
				//rebindc = convert8(heada->buf, (t+4));
				//rebindd = convert8(heada->buf, (t+5));
				if(v>1)printf("Rebinding (T2) time: ");
				if(len == 4){
					if(v>1)printf("%d secs", convert32(pbuf, (t+2), (t+3), (t+4), (t+5)));
				}
			
				if(v>1)printf(", ");
				t = t+len+2;
				break;
			
			 case 60: //class ID
				len = dhcp->buf[t+1];
				if(v>1)printf("Class ID: ");
				for(loop = 0; loop <len; loop++){
					if(v>1)printf("%c",(char)dhcp->buf[t+loop+2]);
				}
				if(v>1)printf(", ");
				t = t+len+2;
				break;
			
			 case 61: //client identfier
				len = dhcp->buf[t+1];
				if(v>1)printf("Client Identifier: ");
				for(loop = 0; loop <len; loop++){
					if(v>1)printf("%x ",dhcp->buf[t+loop+2]);
				}
				if(v>1)printf(", ");
				t = t+len+2;
				break;
	
			 default:
				if((dhcp->buf[t]) == 0) {
					if(v>1)printf("pad ");
					padcount++;
					t++;
					break;
				}
				else{
					len = dhcp->buf[t+1];
					if(v>1)printf("Unknown option 0x%x len: %d data: ", len, dhcp->buf[t]);
					for(loop = 0; loop < len; loop++){
						//if(v>1)printf("%x ",dhcp->buf[t+loop+2]);
					}
					if(v>1)printf(", ");
					t = t+len+2;
					if(dhcp->buf[t] == -1){
						t++; //end of random list
					}
					break;
				}
		} //end of switch
		
		if(padcount > 5) {
			//save's dumping lots of pads
			if(v>1)printf("padding......");
			break;
		}
	}//end of while
	if(v>1)printf("\n");
	if(dhcpdiscoverstarted && (type == DHCPOFFER)){
		yaddr = (unsigned char *)&(dhcp->yaddr);
		if(dhcpreplyinfo){
			if(!noprintinfo)printf("DHCP server at mac: %x:%x:%x:%x:%x:%x srcip: %d.%d.%d.%d\n",(u_int)macsrc[0], (u_int)macsrc[1], (u_int)macsrc[2], (u_int)macsrc[3],(u_int)macsrc[4], (u_int)macsrc[5], (u_int8_t)srcip[0], (u_int8_t)srcip[1], (u_int8_t)srcip[2], (u_int8_t)srcip[3]);
			if(!noprintinfo)printf("offering %d.%d.%d.%d subnet mask %d.%d.%d.%d gateway %d.%d.%d.%d DNS %d.%d.%d.%d\n",  yaddr[0], yaddr[1], yaddr[2], yaddr[3], subneta, subnetb, subnetc, subnetd, gatewaya, gatewayb, gatewayc, gatewayd, dnsa, dnsb, dnsc, dnsd);
		}
		dhcpdetected++;
		return(type);
	}
	return(type);
}

int handle_DHCPdiscover(int tnum)
{
	//printf("DHCP discover\n");
	return(0);
}


int handle_DHCPoffer(int tnum)
{
	int startDHCPrequest(u_int32_t);
	struct my_dhcp *dhcp;
	Packet *tsd;
	mtnode mt;
	int len, t, loop;
	u_int length = 0;
	PMT p_curr, p_top;
	p_top = p_curr = mtpoint;

	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	dhcp = (struct my_dhcp*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_udp));
	length -= (sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_udp));
	if(dhcpgobbling){
		
		mt.transid = ntohl(dhcp->trans_id);
		mt.ipaddress = dhcp->yaddr;
		mt.dhcptype = OFFERREC;

		len = 0;
		t = 0;
		
		while(t < length){
			switch(dhcp->buf[t]){
				case 54:
					len = dhcp->buf[t+1];
					//printf("Server IP: ");
					for(loop = 0; loop <len; loop++){
						//printf("%d ",(u_int8_t)dhcp->buf[t+loop+2]);
						mt.serverip[loop] = (u_char)dhcp->buf[t+loop+2];
					}
					t = length;
					break;

				default: 
					//finding server ip option; 
					len = dhcp->buf[t+1];
					t = t+len+2;
					break;
			}
		}

		if(p_curr == NULL){
			//printf("ll is empty offer discarded\n");
			return(0);
		}

		while((p_curr != NULL) && (p_curr->transid != mt.transid)){
			//printf("no match in loop\n");
			p_curr = (PMT) p_curr->nextmt;
		}
		
		if(p_curr == NULL){
			//printf("no match found offer discarded\n");
			return(0);
		}
		else{
			//printf("transid for sniffer offer found in ll\n");
			updatell(mt);
			if(startDHCPrequest(mt.transid) != 0){
				printf("Opps: startDHCPrequest error\n");
			}
			return(0);
		}	
	}
	return(0);
}

int handle_DHCPrequest(int tnum)
{
	//printf("DHCP request\n");
	return(0);
}

int handle_DHCPdecline(int tnum)
{
	printf("DHCP decline\n");
	return(0);
}

int handle_DHCPack(int tnum)
{
	struct my_dhcp *dhcp;
	Packet *tsd;
	PMT p_curr, p_top;
	mtnode mt;
	
	p_top = p_curr = mtpoint;

	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}
  
	dhcp = (struct my_dhcp*)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_udp));
	
	mt.transid = ntohl(dhcp->trans_id);
	mt.dhcptype = ACKREC;
	
	if(dhcpgobbling){
		
		if(p_curr == NULL){
			return(0);
		}

		while((p_curr != NULL) && (p_curr->transid != mt.transid)){
			//printf("no match in loop\n");
			p_curr = (PMT) p_curr->nextmt;
		}
		
		if(p_curr == NULL){
			//printf("no match found ack discarded\n");
			return(0);
		}
		else{
			//printf("transid for sniffed offer found in ll\n");
			updatell(mt);
			//if(vll)
		}
		return(0);
	}
	return(0); //shouldn;t reach here
}

int handle_DHCPnack(int tnum)
{
	printf("DHCP nack\n");
	return(0);
}

int handle_DHCPrelease(int tnum)
{
	if(v>1)printf("DHCP release\n");
	return(0);
}

int handle_DHCPinform(int tnum)
{
	if(v>1)printf("DHCP inform\n");
	return(0);
}

u_int8_t sendrst(int tnum)
{
	
	Packet *tsd;
	struct ether_header *ether;
	struct my_ip *ip;
	struct my_tcp *tcp;
	libnet_ptag_t t;
	int c;
	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	ether = (struct ether_header *)(tsd->pkt);
	ip = (struct my_ip *)(tsd->pkt + sizeof(struct ether_header));
	tcp = (struct my_tcp *)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip));
				
	if(pthread_mutex_lock(&packetlock) != 0){
		printf("Opps: pthread_mutex_lock (send rst) error\n");
		exit(1);
	}
	t = libnet_build_tcp(
			ntohs(tcp->th_dport),	//srcport
			ntohs(tcp->th_sport), 	//dstport
			ntohl(tcp->th_ack),	//seq number
			0,	//ack number
			TH_RST,		//rst flag
			0,		//window size
			0,		//checksum
			0,		//urg pointer
			LIBNET_TCP_H,	//packet size
			NULL,		//payload
			0,
			l,
			0);
	if(t == -1){
		printf("Opps: libnet_build_tcp error as %s\n\n", libnet_geterror(l));
		exit(1);
	}

	t = libnet_build_ipv4(
			LIBNET_TCP_H + LIBNET_IPV4_H, //length
			0,	//tos
			0,	//ip->ip_id,	//id
			0,	//ip frag
			64,	//TTL
			IPPROTO_TCP, //protocol
			0,	//checksum
			ip->ip_dst,	//srcip
			ip->ip_src,	//dstip
			NULL,	//payload
			0,	//payload size
			l,	//libnet handle
			0);	//libnet_id
		if(t == -1){
		printf("Opps: libnet_build_ipv4 error as %s\n\n", libnet_geterror(l));
		exit(1);
	}

	t = libnet_build_ethernet(
			ether->ether_shost,	//dst mac
			ether->ether_dhost,	//src mac
			ETHERTYPE_IP,
			NULL,
			0,
			l,
			0);
	if(t == -1){
		printf("Opps: libnet_build_ethernet as %s\n\n", libnet_geterror(l));
		exit(1);
	}

	c = libnet_write(l);
	if(c == -1){
		printf("Opps: libnet_write error (send rst) as %s\n", libnet_geterror(l));
		exit(1);
	}
	libnet_stats(l, &gs);
	libnet_clear_packet(l);

	if(pthread_mutex_unlock(&packetlock) != 0){
		printf("Opps: pthread_mutex_unlock (send rst) error\n");
		exit(1);
	}

	//if(v>3)printf("Sent RST\n");
	return(0);
}

int startARPreply(const unsigned int rip)
{
	void addstats(struct libnet_stats);

	libnet_ptag_t t;
	u_char enet_src[6];
	u_char enet_dst[6];
	u_char dstip[4];
	unsigned int riptemp;
	unsigned char *sip;
	PMT p_curr, p_top;
	struct my_arpops *arpo;
	struct my_arp *arp;
	Packet *tsd;
	int c,x,y,z;
	u_char *packet;
	u_long packet_s;

	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}

	arp = (struct my_arp *)(tsd->pkt + sizeof(struct ether_header));
	arpo = (struct my_arpops *)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_arp));
	
	riptemp = ntohl(rip);

	if(pthread_mutex_lock(&listlock) != 0){
			printf("Opps: pthread_mutex_lock (arp reply ll) error\n");
			exit(1);
		}

	p_curr = p_top = mtpoint;
	if(p_curr == NULL){
		//printf("LL empty\n");
			if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (arp reply ll) error\n");
			exit(1);
		}
	return(0);
	}
	while((p_curr != NULL) && (p_curr->ipaddress != riptemp)){
		p_curr = (PMT) p_curr->nextmt;
	}
	if(p_curr == NULL){
		//printf("Not found in list\n");
		if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (arp reply ll) error\n");
			exit(1);
		}
		return(0);
	}
	else{
		//found
		for(x=0; x<6; x++){
			enet_src[x] = p_curr->srcmac[x];
			
		}
		for(y=0; y<6; y++){
			enet_dst[y] = arpo->ar_sha[y];
		}
		for(z=0; z<4; z++){
			dstip[z] = arpo->ar_spa[z];
		}
		if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (arp reply ll) error\n");
			exit(1);
		}

		sip = (unsigned char *)&arpo->ar_tpa;//->ipaddress;//riptemp;
		
		if(pthread_mutex_lock(&packetlock) != 0){
			printf("Opps: pthread_mutex_lock (arp reply) error\n");
			exit(1);
		}

		t = libnet_build_arp(
				ARPHRD_ETHER, 	//HWTYPE
				ETHERTYPE_IP, 	//Proto
				6,		//Hsize
				4,		//Psize
				ARPOP_REPLY,	//opcode
				enet_src,	//send src mac
				sip,		//sender src ip
				enet_dst,	//dst mac
				dstip,		//dst ip
				NULL,		//payload
				0,		//sizeof payload
				q,		//libnet handle
				0);		//libnet id;
		if(t == -1){
			printf("Opps: Can't build ARP header as %s\n\n", libnet_geterror(q));
			libnet_clear_packet(q);
			exit(1);
		
		}
	
		t = libnet_build_ethernet(
				enet_dst,       //enet dst
				enet_src,       //enet src
				ETHERTYPE_ARP,  //proto addr
				NULL,           //payload
				0,              //payload size
				q,              //libnet handle
				0);             //libnet id
		if(t == -1){
			printf("Opps: Can;t build ethernet header as %s\n\n", libnet_geterror(q));
			libnet_clear_packet(q);
			exit(1);
		}
		
		
		c = libnet_adv_cull_packet(q, &packet, &packet_s);
		if(c == -1){
			printf("Opps: libnet_adv_cull error as %s\n",libnet_geterror(q));
		//	free(sip);
			exit(1);
		}
			
		
		c = libnet_write(q);
		if(c == -1){
			printf("Opps: libnet_write error (arp reply) as %s\n", libnet_geterror(q));
			libnet_clear_packet(q);
		}

		libnet_stats(q, &gs);
		libnet_clear_packet(q);
		if(pthread_mutex_unlock(&packetlock) != 0){
			printf("Opps: pthread_mutex_unlock (arp reply) error\n");
			exit(1);
		}
	if(v)printf("\nsent arp reply\n");
		return(0);
	}
	return(0); //shouldn't reach here
}
	

int startDHCPrequest(u_int32_t transactionid)
{
	void addstats(struct libnet_stats);
	
	libnet_ptag_t t;
	libnet_ptag_t ip;
	libnet_ptag_t udp;
	libnet_ptag_t dhcp;
	u_char enet_src[6];
	u_char enet_dst[6] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	int x, i;
	u_int32_t transid;
	u_char *options;
	u_long options_len;
	PMT p_curr, p_top;
	mtnode mt;
	unsigned char *ipa;
	
	
	if(pthread_mutex_lock(&listlock) != 0){
		printf("Opps: pthread_mutex_lock (dhcp request ll) error\n");
		exit(1);
	}

	p_top = p_curr = mtpoint;
	//printf("Sending DHCP request\n");
	
	if(p_curr == NULL){
		//printf("ll is empty\n");
		if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (dhcp request ll) error\n");
			exit(1);
		}
	return 0;
	}
	
	while((p_curr != NULL) && (p_curr->transid != transactionid)){
		//printf("no match in loop\n");
		p_curr = (PMT) p_curr->nextmt;
	}
		
	if(p_curr == NULL){
		//printf("no match found ack discarded\n");
			if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (dhcp request ll) error\n");
			exit(1);
		}
	return 0;
	}
	else{
		//printf("transid for sniffer offer found in ll\n");
		for(x=0; x<6; x++){
			enet_src[x] = p_curr->srcmac[x];
		}

		transid = p_curr->transid;
		if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (dhcp request ll) error\n");
			exit(1);
		}

		i = 0;
	
		options = malloc(15);
		options[i++] = LIBNET_DHCP_MESSAGETYPE;
		options[i++] = 1;
		options[i++] = 0x03; //LIBNET_DHCP_REQUEST;

		options[i++] = 0x32; //Request IP
		options[i++] = 0x04; //size of ip address
		ipa = (unsigned char *)&(p_curr->ipaddress);
		options[i++] = (u_int8_t) ipa[0]; //offered ip address
		options[i++] = (u_int8_t) ipa[1];
		options[i++] = (u_int8_t) ipa[2];
		options[i++] = (u_int8_t) ipa[3];

		options[i++] = 0x36; //server ip identifier
		options[i++] = 0x04; //sizeof ip
		options[i++] = p_curr->serverip[0]; //offered ip address
		options[i++] = p_curr->serverip[1];
		options[i++] = p_curr->serverip[2];
		options[i++] = p_curr->serverip[3];

		options_len = i; //that should work :)
		if(pthread_mutex_lock(&packetlock) != 0){
			printf("Opps: pthread_mutex_lock (dhcp request) error\n");
			exit(1);
		}

		dhcp = libnet_build_dhcpv4(
			LIBNET_DHCP_REQUEST,
			1,
			6,
			0,
			transid,
			0,
			0x8000,
			0,
			0,
			0,
			0,
			enet_src,
			NULL,
			NULL,
			options,
			options_len,
			l,
			0);
		if(dhcp == -1){
			printf("Opps: DHCP build error as %s\n", libnet_geterror(l));
		}

		 udp = libnet_build_udp(
	                 68,                     //source port
			 67,                     //dst port
			 LIBNET_UDP_H + LIBNET_DHCPV4_H + options_len, //packetsize
			 0,                      //checksum
			 NULL,                   //payload
			 0,                      //payload length
			 l,                      //libnet handle
			 0);                     //libnet id
		if(udp == -1){
			printf("Opps: Couldn't build udp packet as %s\n", libnet_geterror(l));
			exit(1);
		}
  
        	ip = libnet_build_ipv4(
			LIBNET_IPV4_H + LIBNET_UDP_H + LIBNET_DHCPV4_H + options_len, //length
			0x10,                   //tos
			0,                      //IP ID
			0,                      //IP Frag
			16,                     //TTL
			IPPROTO_UDP,            //protocol
			0,                      //checksum
			0,                      //source ip 0.0.0.0
			-1,                     //inet_addr("255.255.255.255") //dest ip
			NULL,                   //payload
			0,                      //length of payload
			l,                      //libnet handle
			0);                     //libnet id
		if(ip == -1){
			printf("Opps: Couldn't build ip packet as %s\n", libnet_geterror(l));
			exit(1);
		}
				  
		t = libnet_build_ethernet(
			enet_dst,               //enet_dst
			enet_src,               //ethaddr.ether_addr_octet, //enet_src
			ETHERTYPE_IP,           //protocol type
			NULL,                   //payload
			0,                      //payload length
			l,                      //libnet handle
			0);                     //libnet id
		if(t == -1){
			printf("Opps: Couldn't build ethernet frame as %s\n", libnet_geterror(l));
			exit(1);
		}
						  
		if(libnet_write(l) == -1){
			printf("Opps: libnet_write error (dhcp request) as %s\n", libnet_geterror(l));
			exit(1);
		}
		
		free(options);
		libnet_stats(l, &gs);
		libnet_clear_packet(l);
		if(pthread_mutex_unlock(&packetlock) != 0){
			printf("Opps: pthread_mutex_unlock (dhcp request) error\n");
			exit(1);
		}
		mt.transid = transactionid;
		mt.dhcptype = REQUESTSENT;
		updatell(mt);
		//printf("send dhcp request\n");
		return(0);
	}
	return 0;
}

int startICMPECHOREPLY(void)
{
	PMT p_curr, p_top;
	Packet *tsd;
	struct my_icmpecho *iecho;
	struct my_ip *mip;
	struct ether_header *ether;
	libnet_ptag_t t;
	libnet_ptag_t ip;
	libnet_ptag_t icmp;
	u_char enet_src[6];
	u_char *payload;
	u_int payloadtsize;
	u_int psize;
	
	int c,a;
	payloadtsize = 0;
	psize = 0;
	if(v)printf("start ICMP echo reply\n\n");
	
	if((tsd = (pthread_getspecific(p_key))) == NULL){
		printf("Opps: pthread_getspecific error\n");
		exit(1);
	}
	
	ether = (struct ether_header *)tsd->pkt;
	mip = (struct my_ip*)(tsd->pkt + sizeof(struct ether_header));
	iecho = (struct my_icmpecho *)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_icmp));
	payloadtsize -= (sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_icmp) + sizeof(struct my_icmpecho));
	payload = (u_char *)(tsd->pkt + sizeof(struct ether_header) + sizeof(struct my_ip) + sizeof(struct my_icmp) + sizeof(struct my_icmpecho)); 

	psize = tsd->caplen + payloadtsize;
	//printf("paytload size: %d caplen = %d = payload = %d\n", payloadtsize, tsd->caplen, psize);
	
	if(pthread_mutex_lock(&listlock) != 0){
		printf("Opps: pthread_mutex_lock (icmp reply ll) error\n");
		exit(1);
	}

	p_curr = p_top = mtpoint;
	
	if(p_curr == NULL){
		//printf("LL empty\n");
		if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (icmp reply ll) error\n");
			exit(1);
		}
	return(0);
	}
	while((p_curr != NULL) && (p_curr->ipaddress != mip->ip_dst)){
		p_curr = (PMT) p_curr->nextmt;
	}
	if(p_curr == NULL){
		//printf("Not found in list\n");
		if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (icmp reply ll) error\n");
			exit(1);
		}
	return(0);
	}
	else{
		//found
		for(a=0; a<6; a++){
			 enet_src[a] = p_curr->srcmac[a];
		}
		if(pthread_mutex_unlock(&listlock) != 0){
			printf("Opps: pthread_mutex_unlock (icmp reply ll) error\n");
			exit(1);
		}
			if(pthread_mutex_lock(&packetlock) != 0){
			printf("Opps: pthread_mutex_lock (icmp echo reply) error\n");
			exit(1);
		}

		icmp = libnet_build_icmpv4_echo(
				0,	//type reply
				0,	//code
				0,	//checksum
				iecho->id,
				iecho->seq,
				payload, 
				psize,	//payload size
				l,	//libnet handle
				0);
		if(icmp == -1){
			printf("Opps: libnet_build_icmpv4_echo error as %s\n",libnet_geterror(l));
			return(0);
		}
	
		ip = libnet_build_ipv4(
				LIBNET_IPV4_H + LIBNET_ICMPV4_ECHO_H + psize,
				0,	//TOS
				0,	//id
				0,	//frag
				64,	//TTL
				IPPROTO_ICMP, //proto
				0,
				mip->ip_dst, //ip src.....ip->ip_dst is the requests dst which is our src 
				mip->ip_src, //ip dst
				NULL,	//payload
				0,	//payload size
				l,	//libnet handle
				0);	//libnet ptag
		if(ip == -1){
			printf("Opps: libnet_build_ipv4 error as %s\n", libnet_geterror(l));
			return(0);
		}

		t = libnet_build_ethernet(
				ether->ether_shost,	//DEST  XXX NEED TO SORT IF PING NOT FROM SUBNET
				enet_src,		//src
				ETHERTYPE_IP,
				NULL,
				0,
				l,
				0);
		if(t == -1){
			printf("Opps: libnet_build_ethernet error as %s\n", libnet_geterror(l));
			return(0);
		}	

		c = libnet_write(l);
		if(c == -1){
			printf("Opps: libnet_write error (icmp echo reply) as %s\n", libnet_geterror(l));
			return(0);
		}
		if(v)printf("echo returned\n");	
		libnet_stats(l, &gs);
		libnet_clear_packet(l);
		if(pthread_mutex_unlock(&packetlock) != 0){
			printf("Opps: pthread_mutex_unlock (icmp echo reply) error\n");
			exit(1);
		}
	}
	
	return(0);
		
}

