/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

pthread_mutex_t maclistlock = PTHREAD_MUTEX_INITIALIZER;

int addmacip(u_int32_t ipaddr, u_char *macaddr)
{
	macip * macippointer = macippoint;
	int i,j;
	u_char *srcip;
	
	srcip = (u_char *)&ipaddr;
	
	if(v>2)printf("Adding to macip target linked list ip %d.%d.%d.%d mac %x:%x:%x:%x:%x:%x macippoint: 0x%x\n" , srcip[3], srcip[2], srcip[1], srcip[0], macaddr[0], macaddr[1], macaddr[2], macaddr[3], macaddr[4], macaddr[5], (u_int) &macippoint);

	pthread_mutex_lock(&maclistlock);
	if(macippointer != NULL){ //not 1st entry 
		if(v>2)printf("not 1st mac ip dst to be added\n");
		while(macippointer->nextmi != NULL){
			if(macippointer->ipaddr == ipaddr){
				if(v>2)printf("Opps: IP already in list\n");
				pthread_mutex_unlock(&maclistlock);
				return(0);
			}
			
			macippointer = (PMI) macippointer->nextmi;
			
			if(macippointer->ipaddr == ipaddr){
				printf("Opps: IP already in list checking mac address\n");
				for(j=0;j<6;j++){
					if(macippointer->srcmac[j] != macaddr[j]){
						printf("Mac's dont match may need to update ll\n"); 
						//may need to update ll with mac
						//depends on stuff n things
					}
					else {
						if(j==5)printf("Mac's match no need to update\n");
					}
				}
				pthread_mutex_unlock(&maclistlock);
				return(0);
			}
		}

		macippointer->nextmi = calloc(sizeof(macip), 1);
		if(macippointer->nextmi == NULL){
			printf("Opps: Malloc error not 1st\n");
			exit(1);
		}

		macippointer = (PMI) macippointer->nextmi;
		macippointer->nextmi = NULL;
		macippointer->ipaddr = ipaddr;
		for(i=0;i<6;i++){
			macippointer->srcmac[i] = macaddr[i];
		}
		pthread_mutex_unlock(&maclistlock);
		if(vll)printmacipll(macippointer);
		return(0);
	}
		
	else {
		
		//1st entry
		if(v>2)printf("1st mac ip dst entry\n");
		macippoint = (PMI) calloc(sizeof(macip), 1);
		macippoint->nextmi = NULL;
		macippoint->ipaddr = ipaddr;
		for(i=0;i<6;i++){
			macippoint->srcmac[i] = macaddr[i];
		}
		pthread_mutex_unlock(&maclistlock);
		if(vll) printmacipll(macippoint);
		return(0);
	}

	//shouldn;t reach here
	return(0);
}

void printmacipll(macip * macippoint)
{
	PMI p_curr;
	//u_char *ipaddr;
	p_curr = macippoint;

	printf("Mac-IP Target Linked List 0x%x\n", (u_int)&macippoint);
	
	if(macippoint == NULL) printf("No IP - MAC's found\n");
	else{
		printf("Opps: TODO MAC-IP linked list\n");
		while(p_curr != NULL){
		//	printf("123\n");
		//	ipaddr = (u_char *)p_curr->ipaddr;
		//	printf("IP %d.%d.%d.%d has MAC address %x:%x:%x:%x:%x:%x dg: %d\n", ipaddr[0], ipaddr[1], ipaddr[2], ipaddr[3], p_curr->srcmac[0], p_curr->srcmac[1], p_curr->srcmac[2], p_curr->srcmac[3], p_curr->srcmac[4], p_curr->srcmac[5], p_curr->dg);
			printf("%x:%x:%x:%x:%x:%x has ip\n", p_curr->srcmac[0], p_curr->srcmac[1], p_curr->srcmac[2], p_curr->srcmac[3], p_curr->srcmac[4], p_curr->srcmac[5]);
			p_curr = (PMI) p_curr->nextmi;
		}
	}
}

void freemacipll(macip * macippoint)
{
	PMI p_curr;
	
	if(v>2)printf("\nFreeing mac ip list\n");
	while(macippoint != NULL){
		p_curr = macippoint;
		macippoint = (PMI) macippoint->nextmi;
		free(p_curr);
	}
}
	
