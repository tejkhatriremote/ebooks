/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

pthread_mutex_t portlistlock = PTHREAD_MUTEX_INITIALIZER;
extern int vll;

//linked list of ports that are open
//where srcip is the packets source IP eg the target we are scanning, dst ip being the ip we scanned it with
int addport(u_short num, u_char *srcip, u_char *dstip)
{
	port * portpointer;
	int i;

	//printf("port %d to be added with src %d.%d.%d.%d\n", num, srcip[0], srcip[1], srcip[2], srcip[3]);
	
	pthread_mutex_lock(&portlistlock);
	portpointer = portpoint;
	if(portpointer != NULL){ //not 1st entry
		while(portpointer->nextport != NULL){
			if(portpointer->num == num){
				if(v>1)printf("Opps: Port already in list llport %d openport %d before %d.%d.%d.%d\n",portpointer->num, num, dstip[0], dstip[1], dstip[2], dstip[3]);
				pthread_mutex_unlock(&portlistlock);
				return(0);
			}
			
			portpointer = (POPT) portpointer->nextport;
			
			if(portpointer->num == num){
				if(v>1)printf("Opps: Port already in list llport %d openport %d after ip %d.%d.%d.%d\n", portpointer->num, num, dstip[0], dstip[1], dstip[2], dstip[3]);
				pthread_mutex_unlock(&portlistlock);
				return(0);
			}
		}

		portpointer->nextport = (struct port *) malloc(sizeof(port));
		if(portpointer->nextport == NULL){
			printf("Opps: Malloc error not 1st\n");
			exit(1);
		}

		portpointer = (POPT) portpointer->nextport;
		portpointer->nextport = NULL;
		portpointer->num = num;
		for(i=0;i<4;i++){
			portpointer->ipaddr[i] = srcip[i];
		}
		for(i=0;i<4;i++){
			portpointer->uipaddr[i] = dstip[i];
		}
		if(vll)printportll();
		pthread_mutex_unlock(&portlistlock);
		return(0);
	}
		
	else {
		
		//1st entry
		portpoint = (POPT) calloc(sizeof(port), 1);
		portpoint->nextport = NULL;
		portpoint->num = num;
		for(i=0;i<4;i++){
			portpoint->ipaddr[i] = srcip[i];
		}
		for(i=0;i<4;i++){
			portpoint->uipaddr[i] = dstip[i];
		}
		if(vll)printportll();
		pthread_mutex_unlock(&portlistlock);
		return(0);
	}

	//shouldn;t reach here
	return(0);
}

int portllcount(void)
{
	POPT p_curr;
	int c = 0;
	p_curr = portpoint;

	if(portpoint == NULL) return(0);
	else {
		while(p_curr != NULL){
			c++;
			p_curr = (POPT)p_curr->nextport;
		}
	}
	return(c);
}
			

void printportll(void)
{
	POPT p_curr;

	p_curr = portpoint;

	printf("Gobbler portscan results\n");
	
	if(portpoint == NULL) printf("No open ports found\n");
	else{
		while(p_curr != NULL){
			printf("%d.%d.%d.%d port %d open (%d.%d.%d.%d)\n", p_curr->ipaddr[0], p_curr->ipaddr[1], p_curr->ipaddr[2], p_curr->ipaddr[3], p_curr->num, p_curr->uipaddr[0], p_curr->uipaddr[1], p_curr->uipaddr[2], p_curr->uipaddr[3]);
			p_curr = (POPT) p_curr->nextport;
		}
	}
}

void freeportll(void)
{
	POPT p_curr;
	
	if(v>2)printf("\nFreeing open ports list\n");
	while(portpoint != NULL){
		p_curr = portpoint;
		portpoint = (POPT) portpoint->nextport;
		free(p_curr);
	}
}
	
