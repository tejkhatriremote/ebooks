/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

void startdhcpdiscover(void); 
extern int dhcpdiscoverstarted;
extern int dhcpdetected;
extern int dhcpdiscoverservice;
extern int dhcpgobblestarted;

pthread_mutex_t dhcpdiscoverlock = PTHREAD_MUTEX_INITIALIZER;

extern int dhcpgobbling;
extern void* status;
extern libnet_t *l;
extern int dhcpreplyinfo;

void startdhcpdiscover(void)
{
	void thread_dhcpdiscover(int);
	int i,z;
	
	if(!dhcpgobblestarted) printf("Discovering DHCP service\n");
	
	dptr = calloc(MAXDHCPDETECTHANDLER, sizeof(dthread));
	if(dptr == NULL){
		printf("Opps: Calloc error startdhcpdiscover\n");
		exit(1);
	}
	//else printf("not oops\n");
	for(i=0; i<MAXDHCPDETECTHANDLER; i++){
		thread_dhcpdiscover(i);
	}
 	
	if(dhcpdiscoverservice) dhcpreplyinfo = 1;
	
	//lame 
	if((dhcpreplyinfo)){
		for(z=0; z<10; z++){
			if(dhcpdetected){
				if(dhcpdiscoverservice) sleep(5);
				break;
			}
			else sleep(1);
		}
	}
			
	if(dhcpdetected){
		if(!dhcpgobblestarted) printf("\n");
		if(!dhcpgobblestarted) cleanup(0);
		if(dhcpdiscoverservice){
			cleanup(0);
		}
	}

	else {
		printf("Opps: No reply... NO DHCP service on this network\n");
		free(dptr);
		cleanup(0);
	}
}

void thread_dhcpdiscover(int i)
{
	void *dhcpdiscover(void *);
	dhcpdiscoverstarted = 1;
	

	if(pthread_create(&dptr[i].thread_tid, NULL, &dhcpdiscover, (void * )i) < 0){
		printf("Opps: pthread_create error as %s\n", strerror(errno));
		exit(1);
	}
}

void* dhcpdiscover(void *tnum)
{
//send discover packet
//TODO resend if no packets returned / start 5 threads each 5 secs apart and get replies and check dif any differences

	void addstats(struct libnet_stats);
	libnet_ptag_t t;
	libnet_ptag_t ip;
	libnet_ptag_t udp;
	libnet_ptag_t dhcp;
        u_long options_len;
        int i, x,a;
	u_int32_t transid;
        u_char *options;
	u_char enet_src[6];
	u_char enet_dst[6] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff}; //ethernet broadcast
	mtnode mt;
		
	if(pthread_detach(pthread_self())!=0){
		printf("Opps: pthread_detach error\n");
		exit(1);
	}
	
	if((v>2) && (!dhcpgobbling))printf("Detecting DHCP service on thread(%ld)\n", pthread_self());
	
	for(x=0; x<6; x++){
		if(x==0){
                	enet_src[x] = 0x00;
                }
                else{
                	enet_src[x] = libnet_get_prand(LIBNET_PR8);
                }
		if(tag){
			if(x==4) enet_src[x] = (u_int8_t)'N';//0x4e
			if(x==5) enet_src[x] = (u_int8_t)'P';//0x50 
		}
		mt.srcmac[x] = enet_src[x];
		if(!dhcpdiscoverservice){
			if(!dhcpgobblestarted) printf("%x", enet_src[x]);
		        if((x != 5) && (!dhcpgobblestarted)) printf(":");
		}
	}
	if(!dhcpgobblestarted)printf("\n\n");
  
        i = 0;	  
	transid = libnet_get_prand(LIBNET_PRu32);
	if(dhcpgobbling) mt.transid = transid;
	
	options = malloc(12);
	options[i++] = LIBNET_DHCP_MESSAGETYPE;
	options[i++] = 1;
	options[i++] = LIBNET_DHCP_MSGDISCOVER;
	mt.dhcptype = DHCPDISCOVER;

	
	options[i++] = LIBNET_DHCP_PARAMREQUEST;
	options[i++] = 7;
	options[i++] = 0x01;
	options[i++] = 0x1c;
	options[i++] = 0x02;
	options[i++] = 0x03;
	options[i++] = 0x0f;
	options[i++] = 0x06;
	options[i++] = 0x0c; 
	
	options_len = i;	
	
	if(pthread_mutex_lock(&dhcpdiscoverlock) != 0){
		printf("Opps: pthread_mutex_lock error\n");
		exit(1);
	}
	
        dhcp = libnet_build_dhcpv4(
		LIBNET_DHCP_REQUEST,    //opcode
                1,                      //hardware type
                6,                      //hardware address len
                0,                      //hop count
                transid,                //transactionid
                0,                      //seconds since boot
		0x8000,                 //flag (broadcast)
		0,                      //client IP
		0,                      //your ip
		0,                      //server ip
		0,                      //gateway ip
		enet_src,               //client hardware addr
		NULL,                   //server host name
		NULL,                   //boot file
		options,                //payload
		options_len,            //payload length
		l,                      //libnet handle
		0);                     //libnet id
        if(dhcp == -1){
		printf("Opps: Couldn't build dhcp packet as %s\n", libnet_geterror(l));
		exit(1);
	}
	
	udp = libnet_build_udp(
		68,                     //source port
		67,                     //dst port
		LIBNET_UDP_H + LIBNET_DHCPV4_H + options_len, //packetsize
		0,                      //checksum
		NULL,                   //payload
		0,                      //payload length
		l,                      //libnet handle
	        0);                     //libnet id
	if(udp == -1){
		printf("Opps: Couldn't build udp packet as %s\n", libnet_geterror(l));
	        exit(1);
	}

        ip = libnet_build_ipv4(
		LIBNET_IPV4_H + LIBNET_UDP_H + LIBNET_DHCPV4_H + options_len, //length
	        0x10,                   //tos
	        0,                      //IP ID
	        0,                      //IP Frag
	        16,                     //TTL
	        IPPROTO_UDP,            //protocol
	        0,                      //checksum
	        0,                      //source ip 0.0.0.0
	        -1,                     //inet_addr("255.255.255.255") //dest ip
	        NULL,                   //payload
	        0,                      //length of payload
	        l,                      //libnet handle
	        0);                     //libnet id
	
	if(ip == -1){
		printf("Opps: Couldn't build ip packet as %s\n", libnet_geterror(l));
		exit(1);
	
	} 
	t = libnet_build_ethernet(
		enet_dst,               //enet_dst
		enet_src,               //ethaddr.ether_addr_octet, //enet_src
		ETHERTYPE_IP,           //protocol type
		NULL,                   //payload
		0,                      //payload length
		l,                      //libnet handle
		0);                     //libnet id
	if(t == -1){
		printf("Opps: Couldn't build ethernet frame as %s\n", libnet_geterror(l));
		exit(1);
	}
	
	a = libnet_write(l);
	if(a == -1){
		printf("Opps: libnet_write error (DHCP discover) as %s\n", libnet_geterror(l));//strerror(errno));
		exit(1);
	}
	
	addll(mt); //adds mac + trans to ll
	free(options);
	libnet_stats(l, &gs);
	libnet_clear_packet(l);
	if(pthread_mutex_unlock(&dhcpdiscoverlock) != 0){
		printf("Opps: pthread_mutex_unlock error\n");
		exit(1);
	}
	pthread_exit(&status);
}

