/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "gobbler.h"

static pthread_once_t endarpscanlock = PTHREAD_ONCE_INIT;
extern int arpscanstarted;
int acount;
extern libnet_t *l;
extern u_int endwait;
extern u_int maskcount;
extern pthread_mutex_t packetlock;
pthread_mutex_t arplock = PTHREAD_MUTEX_INITIALIZER; //lock to ensure arp scan increments by one each time

void startarpscan(void)
{
	void thread_arpscan(int);
	int i, tcount;
	
	acount = 0;
	printf("Detecting IP addresses via spoofed broadcast ARP scan using %d threads\n\n", MAXARPSCANHANDLER);
	aptr = calloc(MAXARPSCANHANDLER, sizeof(athread));
	
	if(maskcount < MAXARPSCANHANDLER){
		tcount = maskcount + 1;
	}
	else tcount = MAXARPSCANHANDLER;
	
	for(i=0; i<tcount; i++){
		thread_arpscan(i);
	}
}
 
void thread_arpscan(int i)
{
	void *arpscan(void *);
	arpscanstarted = 1;
	if(pthread_create(&aptr[i].thread_tid, NULL, &arpscan, (void *) i) < 0){
		printf("Opps: pthread_create error\n");
		exit(1);
	}
}

void arpscan(void *tnum)
{
	void addstats(struct libnet_stats);
        void end_arpscan(void);
        libnet_ptag_t t;
        u_long i,j; //src + dst ip addresses
        int c;
	
        u_char enet_src[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
        u_char enet_dst[6] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
         
        if(pthread_detach(pthread_self()) <0){
        	printf("Opps: pthread_detach error\n");
                pthread_exit(&status);
        }
                                                
	if(v>2)printf("Arp scan started on thread(%ld)\n", pthread_self());
 	
	while(acount <= maskcount){
		usleep(1);
		pthread_mutex_lock(&arplock);
		acount++;
	        j = (localnet + htonl(acount));
		pthread_mutex_unlock(&arplock);
        		
		i = -1; //Source IP 255.255.255.255.... corrisponding to MAC addr ff:ff:ff:ff:ff:ff :)
		
		if(acount >= maskcount){
			pthread_once(&endarpscanlock, end_arpscan);
			pthread_exit(&status);
		}
		if(pthread_mutex_lock(&packetlock) !=0){
			printf("Opps: pthread_mutex_lock (arpscan)\n");
			exit(1);
		}
		t = libnet_build_arp(
			ARPHRD_ETHER,   //HW type
			ETHERTYPE_IP,   //Proto
		        6,              //Hsize
		        4,              //psize
	        	ARPOP_REQUEST,  //opcode
		        enet_src,       //sender HW address
		        (u_char *)&i,   //sender proto address
	        	enet_dst,       //receiver HW address
			(u_char *)&j,   //receiver proto address
		        NULL,           //payload
	        	0,              //payload size
		        l,              //libnet handle
		       	0);             //libnet id
		                                                                                                                                                if(t == -1){
			printf("Opps: Can;t build ARP header as %s\n\n", libnet_geterror(l));
			libnet_clear_packet(l);
			exit(1);
		}
		t = libnet_build_ethernet(
			enet_src,       //enet source
	        	enet_dst,       //enet dest
		        ETHERTYPE_ARP,  //proto addr
			NULL,           //payload
	        	0,              //payload size
		        l,              //libnet handle
		        0);             //libnet id
	
		if(t == -1){
			printf("Opps: Can;t build ethernet header as %s\n\n", libnet_geterror(l));
	       		libnet_clear_packet(l);
		        exit(1);
		}
	
		 if((c = libnet_write(l)) == -1){
			printf("Opps: libnet_write error (arp scan) as %s\n", libnet_geterror(l));
			exit(1);
		}
	  
		libnet_stats(l, &gs);
		libnet_clear_packet(l);
		if(pthread_mutex_unlock(&packetlock) !=0){
			printf("Opps: pthread_mutex_unlock (arpscan)\n");
			exit(1);
		}
	}
       	pthread_once(&endarpscanlock, end_arpscan);
	pthread_exit(&status);
}
 
 
void end_arpscan(void)
{
	void cleanup(int sigio);
	if(endwait) printf("Arp scan finished... waiting for %d seconds for any more replies\n", endwait);
	else printf("Arp scan finished...\n");
	//libnet_destroy(l);
	sleep(endwait);
	cleanup(0);
}
