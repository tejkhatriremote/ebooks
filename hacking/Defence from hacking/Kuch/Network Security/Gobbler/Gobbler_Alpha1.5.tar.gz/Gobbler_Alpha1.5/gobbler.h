/*The Gobbler - A tool to audit DHCP networks
 *Copyright (C) 2002 Steven Jones root@networkpenetration.com
 *www.networkpenetration.com
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <dnet.h>
#include <stdlib.h>
#include <stdio.h>
#include <pcap.h>
#include <libnet.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <net/route.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/ether.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <ctype.h>

//defines
#define MAXPACKHANDLER  20//30number of threads for packet handling
#define MAXGOBHANDLER  1  //100 number of threads for gobbling
#define MAXDHCPDETECTHANDLER 1 //number of threads detecting DHCP service
#define MAXARPSCANHANDLER 150 //number of threads used for ARP scan
#define MAXPORTSCANHANDLER 15 //15 threads for portscan 
#define MAXDHCPMITMHANDLER 1 
#define MAXIPSOURCE 30


#define IPTYPE_TCP 0x0006
#define IPTYPE_UDP 0x0011
#define IPTYPE_ICMP 0x0001
  
#define SNAPLEN 65535
#define MAXLINE 2048
   
#define NOFILTER 0
#define DHCPDETECTFILTER 1
#define DHCPMITMFILTER 2
#define ARPSCANFILTER 3
   
#define EASTEREGG 5   
#define DHCPDETECTSTRING "udp and dst port %d" //68
#define DHCPMITMSTRING  "arp or udp or src port %d or src port %d" //67 68
#define ARPSCANSTRING "arp"

#define DHCPDISCOVER 1
#define DHCPOFFER 2
#define DHCPREQUEST 3
#define DHCPDECLINE 4
#define DHCPACK 5
#define DHCPNACK 6
#define DHCPRELEASE 7
#define DHCPINFORM 8
 
#define DHCPDETECTED 1


typedef struct {
        char pkt[SNAPLEN];
        char *ppkt;
	int caplen;
}Packet;
 
typedef struct {
        pthread_t thread_tid;
        long thread_count;
}Thread; //packet handling threads

typedef struct {
        pthread_t thread_tid;   	
	long gobble_count;
}gthread; //gobble threads
 

typedef struct {
        pthread_t thread_tid;
        long dhcp_count;
}dthread; //detect DHCP server threads
 

typedef struct {
        pthread_t thread_tid;
        long arp_count;
}athread; //arp scan threads
 
typedef struct{
	pthread_t thread_tid;
	long port_count;
}portthread; //port scan thread

typedef struct{
	pthread_t thread_tid;
	int mitm_count;
}mitmthread; 


struct my_ip{
        u_int8_t ip_vhl; //header length n version
#define IP_V(ip) (((ip)->ip_vhl & 0xf0) >> 4)
#define IP_HL(ip) ((ip)->ip_vhl & 0x0f)
        u_int8_t ip_tos; /*type of service*/
        u_int16_t ip_len; /* total length */
        u_int16_t ip_id;  /* identification */
        u_int16_t ip_off; /* fragment offset field */
#define IP_DF 0x4000    /* dont fragment flag */
#define IP_MF 0x2000    /* more fragments flag */
#define IP_OFFMASK 0x1fff /* mask for fragmenting bits */
        u_int8_t ip_ttl; /* time to live */
        u_int8_t ip_p;  /* protocol */
        u_int16_t ip_sum; /* checksum */
        u_int32_t ip_src;
        u_int32_t ip_dst; /* source and dest address */
};

struct my_udp{
        u_int16_t src_port;
        u_int16_t dst_port;
        u_int16_t udp_length;
        u_int16_t chksum;
};
 
struct my_tcp{
        u_int16_t th_sport;
        u_int16_t th_dport;
        u_int32_t th_seq;
        u_int32_t th_ack;
        u_int8_t th_offx2; //data offset rsvd
#define TH_OFF(th)      (((th)->th_offx2 & 0xf0) >> 4)
	u_int8_t        th_flags;
#define TH_FIN  0x01
#define TH_SYN  0x02
#define TH_RST  0x04
#define TH_PUSH 0x08
#define TH_ACK  0x10
#define TH_URG  0x20
#define TH_ECNECHO 0x40 /* ECN Echo */
#define TH_CWR 0x80 /* ECN Cwnd Reduced */
	u_int16_t th_win; /* window */
	u_int16_t th_sum; /* checksum */
	u_int16_t th_urp; /* urgent pointer */
};
 
struct my_arp{
	u_int16_t arp_type;
#define ARPHRD_ETHER    1       /* ethernet hardware format */
#define ARPHRD_IEEE802  6       /* token-ring hardware format */
#define ARPHRD_ARCNET   7       /* arcnet hardware format */
#define ARPHRD_FRELAY   15      /* frame relay hardware format */
#define ARPHRD_STRIP    23      /* Ricochet Starmode Radio hardware format */
#define ARPHRD_IEEE1394 24      /* IEEE 1394 (FireWire) hardware format */
	u_int16_t arp_proto;
	u_int8_t arp_hsize;
	u_int8_t arp_psize;
	u_int16_t arp_opcode;
#define ARPOP_REQUEST   1       /* request to resolve address */
#define ARPOP_REPLY     2       /* response to previous request */
#define ARPOP_REVREQUEST 3      /* request protocol address given hardware */
#define ARPOP_REVREPLY  4       /* response giving protocol address */
#define ARPOP_INVREQUEST 8      /* request to identify peer */
#define ARPOP_INVREPLY  9       /* response identifying peer */
};

struct my_arpops{
//should be variable length depending on arp_hsize and arp_psize TODO
	u_char  ar_sha[6];       /* sender hardware address */
	u_char  ar_spa[4];       /* sender protocol address */
	u_char  ar_tha[6];       /* target hardware address */
	u_char  ar_tpa[4];       /* target protocol address */
};

struct my_icmp{
	u_int8_t type;
	u_int8_t code;
	u_int16_t checksum;
};

struct my_icmpecho{
	u_int16_t id;
	u_int16_t seq;
}; //+ data
		

#define ICMP_ECHOREPLY 0
#define ICMP_UNREACH 3
#define ICMP_SOURCEQUENCH 4
#define ICMP_REDIRECT 5
#define ICMP_ECHO 8
#define ICMP_TIMEEXCEED 11
#define ICMP_PARAMPROB 12
#define ICMP_TIMESTAMP 13
#define ICMP_TIMESTAMPREPLY 14
#define ICMP_INFOREQUEST 15
#define ICMP_INFOREPLY 16

struct my_dhcp{
	u_int8_t opcode; 	//1 boot request, 2boot reply
	u_int8_t type; 		//1 = 10mb ethernet
	u_int8_t h_len; 	//hardware length
	u_int8_t hops; 		//number of hops
	u_int32_t trans_id;	//transaction id
	u_int16_t t_elapsed;	//time elapsed since boot
	u_int16_t flags;	//0x800 is broadcast the rest zero
	u_int32_t cliaddr;	//client ip address
	u_int32_t yaddr;	//you client addr
	u_int32_t siaddr;	//next dhcp server ip address
	u_int32_t giaddr;	//gateway addr / relay agents IP
	u_char clihwaddr[6];    //clients hardware address
	u_int8_t randgap[10];	//random gap
	u_int8_t sname[64];	//server hostname
	u_int8_t bname[128];	//boot file name
	u_int32_t magic;	//magic number
	char buf[500];	//need to check size of buffer
};  
		                                 
struct udp_ports{
        u_int16_t src;
        u_int16_t dst;
	int err;
};

typedef struct{
	u_char srcmac[6];
	u_int32_t transid;
	u_int32_t ipaddress;
	u_char serverip[4];
	u_int8_t lastdhcptype; //if type = ACKREC address gobbled
	u_int8_t type; //portscantype
	struct mt *nextmt;
}mt; 
//linked list struct

//temp struct
typedef struct{
	u_char srcmac[6];
	u_int32_t transid;
	u_int32_t ipaddress;
	u_char serverip[4];
	u_int8_t dhcptype;
}mtnode;

int addmt(mtnode);
int updatell(mtnode);
int addll(mtnode);
void printll(void);
typedef mt * PMT; //pointer to mac struct
extern PMT mthead; //head of linked list
extern mt *mtpoint; 

typedef struct{
	u_int32_t ipaddr;
	u_char srcmac[6];
	//add time of day do something about timing out arp entry.... maybe maybe not
	struct macnode *nextmi;
}macip;

typedef macip * PMI; //pointer to mac ip struct
extern PMI maciphead;
extern macip* macippoint;

int addmacip(u_int32_t ipaddr, u_char *macaddr);
void printmacipll(macip * macippoint);


//ll for portnumbers
typedef struct{
	u_short num; //portnumber
	u_int8_t done; //if port scanned (randomise order TODO)
	struct pt *nextpt;
}pt;

typedef pt * PPT;
extern PPT pthead;
extern pt *ptpoint;
int addpt(u_short);
int updatepll(pt);
int checkpll(u_short);
void printpll(void);

typedef struct{
	u_short num; //portnumber
	u_char ipaddr[4]; 
	u_char uipaddr[4]; //ip addr used to scan
	struct port *nextport;
}port;

typedef port * POPT;
extern POPT porthead;
extern port *portpoint;
int addport(u_short, u_char *, u_char *);
void printportll(void);
void freeportll(void);

//last dhcp packet type
#define DISCOVERSENT 1
#define OFFERREC 2
#define REQUESTSENT 3
#define ACKREC 4 //start replying to arp request at this point.... incoming arp checks node srcmac if match check status + reply

//types
#define GOB 1 //gobbled state
#define MITM 2 //dished out in mitm attack
#define PORTSCANNINGSOURCE 3 //todo
#define DHCPSERVER 11 //todo
//other ideas gateway, dns sever, webserver


char *device; //for libpcap and libnet libdnet
pcap_t *pd;
int fddipad;
int datalink;
int v;
int vll;
int drop;
int tag;
void *status;
int count;
uint32_t localnet, netmask;
 
Thread *tptr; //packhandler thread pointer
gthread *gptr; //gobbler thread pointer
dthread *dptr; //detect dhcp thread pointer
athread *aptr; //detect arp thread pointer
portthread *pptr; //portscan thread pointer
mitmthread *mptr; //mitm thread pointer
 
struct libnet_stats gs; //global stats for libnet
struct timeval inittime;
struct timeval endtime;
extern void usage(char *progname);
extern void cleanup(int sigio);
static pthread_key_t p_key;
