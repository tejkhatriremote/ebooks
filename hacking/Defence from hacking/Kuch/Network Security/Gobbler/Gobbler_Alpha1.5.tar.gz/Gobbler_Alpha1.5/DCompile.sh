#!/bin/bash
#debugging compile -g ggdb
gcc `libnet-config --defines --cflags` arpscan.c convert.c dhcpgobble.c dhcpdiscover.c portscan.c miscfuncs.c dhcpmitm.c ll.c pll.c portll.c macll.c main.c /usr/local/lib/libdnet.a /usr/lib/libpcap.a -lpthread -Wall -D_REENTRANT -g -ggdb -o Gobbler `libnet-config --libs`
exit
