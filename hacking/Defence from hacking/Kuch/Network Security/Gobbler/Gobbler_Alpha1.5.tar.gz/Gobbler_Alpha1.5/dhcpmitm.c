#include "gobbler.h"


extern int dhcpmitmstarted;
extern int dhcpgobbling;
extern int dhcpgobblestarted;
extern int dhcpreplyinfo;

extern void startdhcpmitm(void);
extern void* status;

#define GOBBLERAMOUNT 2 //1 for dhcp server 1 for rogue client

int dhcpmitmstarted;

void startdhcpmitm(void)
{
	void thread_dhcpmitm(int);
	void startdhcpdiscover(void);
	int i, j;

	
	printf("MITM attack still need todo\n");
	exit(1);
	
	mptr = calloc(MAXDHCPMITMHANDLER, sizeof(mitmthread));
		
	dhcpgobbling = 1;
	dhcpgobblestarted = 1;
	dhcpreplyinfo = 1;
	
	for(j = 0; j<GOBBLERAMOUNT; j++){
		startdhcpdiscover(); //get ip and mac for dhcp server
	}

	dhcpgobbling = 0;
	dhcpgobblestarted = 0;
	dhcpreplyinfo = 0;
	//for(i = 0; i < 1; i++){
	//i = 0;
	thread_dhcpmitm(i);
	//}
}
	
void thread_dhcpmitm(int i)
{
	void *mitm(void *);

	dhcpmitmstarted = 1;
	if(pthread_create(&pptr[i].thread_tid, NULL, &mitm, (void *)i)<0){
		printf("Opps: pthread_create error as %s\n\n", strerror(errno));
		exit(1);
	}
}

void mitm(void *tnum)
{
	
	pthread_detach(pthread_self());
	printf("MITM started waiting for DHCP client to send dhcp discover\n");
	for(;;) //printf(".");
		sleep(1);
	//exit(1);
}
