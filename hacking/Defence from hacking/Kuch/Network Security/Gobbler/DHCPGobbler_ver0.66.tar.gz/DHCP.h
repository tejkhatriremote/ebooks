//DHCP gobbler header file

//includes
#include <stdio.h>
#include <netinet/udp.h>
#include <netinet/ip.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <getopt.h>
#include <arpa/inet.h>
#include <string.h>
#include <signal.h>
#include <net/if.h>
#include <netinet/if_ether.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <libnet.h>
#include <pcap.h>
//#include <errno.h>
#include <setjmp.h>
//defines
#define SA struct sockaddr
#define SPORT 67
#define CPORT 68
#define VER "0.66"
#define MAXLINE 4096
#define MAX_PAYLOAD_SIZE 1025
#define CMD "udp and dst port %d" //gobbling
#define CMD2 "udp and src port %d or src port %d" //mitm
#define CMD3 "ether dst ffffffff" //arpsniff

//variables
extern int verbose;
extern int datalink;
extern char *device;
extern int fddipad;
extern pcap_t *pd;
extern int snaplen;
extern char buf;
extern int count;
extern int middle;
extern int ackit;
extern int requestit;
extern int samemac;
extern int nackit;
extern int offerit;
extern unsigned int reqipa, reqipb, reqipc, reqipd, sentipa, sentipb, sentipc, sentipd, subneta, subnetb, subnetc, subnetd, dnsa, dnsb, dnsc, dnsd, dnse, dnsf,dnsg, dnsh, gatewaya, gatewayb, gatewayc, gatewayd, renewa, renewb, renewc, renewd, rebinda, rebindb, rebindc, rebindd, renewala, renewalb, renewalc, renewald, rebinda, rebindb, rebindc, rebindd, leasea, leaseb, leasec, leased;
extern u_char storedmac[6];
extern int storedpackid;
extern int nonewips;
extern int gipnum;
extern int arpsniff;

//structs
struct header{
	struct iphdr ip; //ip header
	struct udphdr udp; //udp header
	char buf[548]; //DHCP header
};

struct arpheader{
	struct libnet_arp_hdr arp;
};

struct gobbledIPs{
	unsigned int address[4];
	unsigned int ethernet[7];
};

//prototypes
void usage(char *progname);
struct header  *opensniff(u_char comp1, u_char comp2, u_char comp3, u_char comp4);
void open_pcap(void);
struct header *udp_check(char *ptr, int len);
struct header *udpread(void);
char *next_pcap(int *len);
unsigned short in_chksum(unsigned short *pts, int nbytes);
void cleanup(int sigio);
struct header *gobble(void);
char *next_pcap(int *);
void open_pacp(void);
void mitm(void);
void sig_alrm(int sigio);
void sniffedattack(struct header *heada);
void trickery(void);
void getgatewaymac();
void gatewayarpsniff();
//convert.c prototypes
unsigned int convert32(char *ptr, int anum, int bnum, int cnum, int dnum);
unsigned int convert16(char *ptr, int anum, int bnum);
unsigned int convert8(char *ptr, int num);

//libnet stuff
extern u_char *netdevice;

