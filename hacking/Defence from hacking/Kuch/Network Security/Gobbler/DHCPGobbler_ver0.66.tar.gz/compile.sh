#!/bin/bash
gcc `libnet-config --defines --cflags` *.c /usr/lib/libpcap.a -Wall -o Gobbler `libnet-config --libs`
exit
