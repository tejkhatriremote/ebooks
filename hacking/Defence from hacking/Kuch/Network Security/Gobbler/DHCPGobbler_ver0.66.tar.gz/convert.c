#include "DHCP.h"
//start of convert functions
unsigned int convert32(char *ptr, int anum, int bnum, int cnum, int dnum)
{
	register unsigned int seq_num = 0;
	register unsigned char octet;

	octet = ptr[anum];
	seq_num = (seq_num + octet) << 8;

	seq_num = seq_num & 0x0000ff00;
	octet = ptr[bnum];
	seq_num = (seq_num + octet) << 8;

	seq_num = seq_num & 0x00ffff00;
	octet = ptr[cnum];
	seq_num = (seq_num + octet) << 8;

	seq_num = seq_num & 0xffffff00;
	octet = ptr[dnum];
	seq_num = (seq_num + octet);

	return seq_num;
}


unsigned int convert16(char *ptr, int anum, int bnum)
{
	register unsigned int suma = 0;
	register unsigned int sumb = 0;
	register unsigned int ans = 0;
	register int q = 0;
	register int p = 0;
	for(q=128;q>0;q=q/2){
				if(q &ptr[anum])
				{
				if((q=128 &ptr[anum])) suma+=32768;
				if((q=64 &ptr[anum])) suma+=16384;
				if((q=32 &ptr[anum])) suma+=8192;
				if((q=16 &ptr[anum])) suma+=4096;
				if((q=8 &ptr[anum])) suma+=2048;
				if((q=4 &ptr[anum])) suma+=1024;
				if((q=2 &ptr[anum])) suma+=512;
				if((q=1 &ptr[anum])) suma+=256;			
				}
				}
	
	for(p=128;p>0;p=p/2){
				if(p &ptr[bnum])
				{
					sumb +=p;
				}
				}
		
		ans = (suma + sumb);
		return(ans);
}


unsigned int convert8(char *ptr, int num)
{
register unsigned int sum = 0;
register int q = 0;
	for(q=128; q>0; q=q/2)
	{
	if(q &ptr[num]) sum += q;
	}
	return(sum);
}
//end of convert functions

