/**
   @version 1.21 2004-05-11
   @author Cay Horstmann
*/

import javax.swing.*;

public class BuggyButtonTest
{
  public static void main(String[] args)
  {
    BuggyButtonFrame frame = new BuggyButtonFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }
}

